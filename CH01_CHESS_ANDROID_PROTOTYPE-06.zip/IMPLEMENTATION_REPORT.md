# گزارش پیاده‌سازی معماری محتوای ترتیبی و آماده‌سازی اتصال ترجمه — فصل اول (نسخه ۰۶)

- **عنوان رسمی کتاب:** *How to Win at Chess*
- **عنوان فصل اول:** *How to (Literally) Win at Chess*

این گزارش مستندات کامل نسخه `-06` نمونه اولیه فصل اول را ارائه می‌دهد. در این مرحله، بدون هیچ‌گونه تغییر در `ChessEngine`، `ChessRulesAdapter`، قوانین `FEN` و `PGN`، تمرین `BD-032`، وضعیت `BD-027`، طراحی ظاهری، معماری `MVVM` یا تست‌های تأییدشده قبلی، اصلاح معماری محتوای ترتیبی برای اتصال دقیق ترجمه‌های فارسی انجام شد.

---

## ۱. طراحی مدل محتوای ترتیبی (`ChapterModels.kt`)

برای حفظ ترتیب دقیق متن و نمودارهای کتاب (که در صفحات به‌صورت متوالی و درهم‌تنیده قرار گرفته‌اند)، سلسله‌مراتب `SectionContentBlock` طراحی و به `TranslationSlot` متصل شد:

1. **`SectionContentBlock.ParagraphBlock(blockId, textFa, showPlaceholderWhenEmpty)`:**
   - نمایش پاراگراف متنی ترجمه‌شده در موقعیت دقیق خود (قبل، بعد یا میان نمودارها).
   - در صورت خالی بودن متن ترجمه و فعال بودن `showPlaceholderWhenEmpty`، پیام آماده‌سازی بخش نمایش داده می‌شود؛ و در صورت `showPlaceholderWhenEmpty = false`، بلوک می‌تواند بدون نمایش پیام و بدون تأثیر بر سایر بلوک‌ها خالی بماند.
2. **`SectionContentBlock.HeadingBlock(blockId, textFa, level, showPlaceholderWhenEmpty)`:**
   - نمایش عنوان فرعی ترجمه‌شده در هر نقطه از بخش.
3. **`SectionContentBlock.DiagramBlock(blockId, diagramId)`:**
   - رندر کارت نمودار شطرنج (`BD-025` تا `BD-034`) در موقعیت دقیق ثبت‌شده در فهرست بلوک‌ها.
4. **`SectionContentBlock.ExerciseBlock(blockId, diagramId)`:**
   - رندر تمرین تعاملی (`BD-032`) در موقعیت دقیق ثبت‌شده.
5. **`SectionContentBlock.FootnoteBlock(blockId, textFa, showPlaceholderWhenEmpty)`:**
   - نمایش پانویس یا توضیح کوتاه در ترتیب اصلی بخش.
6. **`SectionContentBlock.ExternalReferenceBlock(blockId, titleFa, url, isAuthorizedAndEnabled)`:**
   - جایگاه ارجاع خارجی کتاب که تا زمان تعیین مقصد مجاز غیرفعال (`isAuthorizedAndEnabled = false`) است.

---

## ۲. حفظ جایگاه `TranslationSlot` و ۶ شناسه اصلی بخش‌ها (`ChapterModels.kt` و `ChapterRepository.kt`)

- هر ۶ شناسه اصلی `TranslationSlot` بدون تغییر حفظ شده‌اند:
  - `SEC_CH01_01_OPENING`
  - `SEC_CH01_02_CHECKMATE`
  - `SEC_CH01_03_RESIGNATION`
  - `SEC_CH01_04_TIMING_OUT`
  - `SEC_CH01_05_ABANDONMENT`
  - `SEC_CH01_06_SUMMARY`
- کلاس `TranslationSlot` دارای فیلدهای زیر است:
  - `sectionId: String`
  - `orderedContentBlocks: List<SectionContentBlock>`
  - `placeholderNotice: String = "محتوای این بخش در حال آماده‌سازی است."`
  - `translationStatus: TranslationStatus` (`PENDING`، `PARTIAL`، `COMPLETE`) و `isPending: Boolean`
  - `translationsByBlockId: Map<String, String>` و متدهای `resolveBlockText` / `withBlockTranslations` برای اتصال متن ترجمه‌شده به هر `blockId` مستقل از ترتیب بلوک‌ها.
- اعتبارسنج `ContentBlockValidator` موارد زیر را بررسی می‌کند:
  - عدم وجود شناسه تکراری (`blockId`) در میان بلوک‌های هر بخش و کل فصل (`findDuplicateBlockIds`).
  - معتبر بودن تمامی `diagramId`های ارجاع‌شده در `DiagramBlock` و `ExerciseBlock` (`findInvalidDiagramBlocks`).
  - حضور و تطابق هر ۶ شناسه اصلی `TranslationSlot` (`validateSectionsAndBlocks`).

---

## ۳. اصلاح رندر ترتیبی در `ReaderScreen.kt` و حذف تکرار پیام آماده‌سازی زیر نمودارها

1. **رندر ترتیبی بلوک‌ها (`SectionContentBlockItem`):**
   - کامپوننت `ReaderScreen` دیگر تمام پاراگراف‌ها را در ابتدای بخش و پیش از تمام نمودارها جمع نمی‌کند، بلکه فهرست `currentSection.translationSlot.orderedContentBlocks` را دقیقاً به ترتیب ثبت‌شده پیمایش و رندر می‌کند (برای نمونه: `Paragraph 001 -> Diagram BD-026 -> Paragraph 002 -> Diagram BD-027 -> ...`).
2. **رفع تکرار پیام «محتوای این بخش در حال آماده‌سازی است.» در `DiagramCard`:**
   - متن تکراری `"محتوای این بخش در حال آماده‌سازی است."` که پیش‌تر در داخل هر `DiagramCard` قرار داشت، حذف شد.
   - اکنون تا زمان تحویل ترجمه یک بخش، پیام **«محتوای این بخش در حال آماده‌سازی است.»** فقط **یک‌بار** در جایگاه محتوای متنی ترجمه‌نشده همان بخش نمایش داده می‌شود و هرگز زیر تک‌تک نمودارها تکرار نمی‌شود.

---

## ۴. گزارش اجرای ۴۱ تست خودکار (شامل ۹ تست جدید معماری محتوای ترتیبی)

تمامی **۴۱ تست خودکار** پروژه (شامل ۳۲ تست قبلی + ۹ تست جدید) با دستور `gradle :app:testDebugUnitTest --rerun-tasks --console=plain` اجرا و با موفقیت کامل (`0 failures, 0 errors`) تأیید شدند:

### فهرست ۹ تست جدید اضافه‌شده در `ExampleRobolectricTest.kt`:
1. `test 1 - preserve interleaved block order during rendering`: حفظ ترتیب درهم‌تنیده بلوک‌ها (`P001 -> D026 -> P002 -> D027`) هنگام رندر در Compose UI.
2. `test 2 - render paragraph before diagram`: نمایش پاراگراف متنی پیش از نمودار (`P001` بالاتر از `BD-025`).
3. `test 3 - render paragraph after diagram`: نمایش پاراگراف متنی پس از نمودار (`P002` پایین‌تر از `BD-025`).
4. `test 4 - render multiple diagrams in a section in exact registered order`: نمایش چند نمودار در یک بخش (`BD-026` تا `BD-030`) با ترتیب دقیق ثبت‌شده.
5. `test 5 - detect duplicate blockIds across blocks`: شناسایی شناسه‌های تکراری بلوک‌ها توسط `ContentBlockValidator`.
6. `test 6 - detect DiagramBlock with invalid diagramId`: شناسایی `DiagramBlock` و `ExerciseBlock` با شناسه نمودار نامعتبر (`BD-999` یا خالی).
7. `test 7 - preserve the 6 primary TranslationSlot sectionIds`: حفظ و اعتبارسنجی هر ۶ شناسه اصلی `TranslationSlot`.
8. `test 8 - placeholder notice is not repeated under diagrams`: تأیید نمایش تنها یک‌بار پیام «محتوای این بخش در حال آماده‌سازی است.» در بخش ۲ (دارای ۵ نمودار) و عدم تکرار آن زیر نمودارها.
9. `test 9 - empty block does not affect other blocks`: امکان خالی ماندن یک بلوک (`showPlaceholderWhenEmpty = false`) بدون نمایش پیام اضافی و بدون تأثیر بر رندر و ترتیب سایر بلوک‌ها.

| کلاس تست | فایل گزارش XML | تعداد `@Test` | وضعیت |
|---|---|---|---|
| `com.example.ChessChapterOneTest` | `TEST-com.example.ChessChapterOneTest.xml` | **23** | **PASS (23/23)** |
| `com.example.ExampleRobolectricTest` | `TEST-com.example.ExampleRobolectricTest.xml` | **17** | **PASS (17/17)** |
| `com.example.ExampleUnitTest` | `TEST-com.example.ExampleUnitTest.xml` | **1** | **PASS (1/1)** |
| **مجموع کل** | — | **41** | **PASS (41/41)** |
