# اطلاعیه مجوزهای شخص ثالث و دارایی‌ها (THIRD_PARTY_NOTICES)

این سند شامل مجوزها و شرایط استفاده از کتابخانه‌ها، فونت‌ها، گلیف‌ها و بسته‌های منبع باز استفاده‌شده در این پروژه است.

---

## ۱. کتابخانه‌های زمان اجرا (Runtime Dependencies)

### Android Jetpack Libraries & Compose
- **ناشر:** Google LLC / Android Open Source Project
- **مجوز:** Apache License, Version 2.0
- **ماژول‌های فعال:**
  - `androidx.compose.ui`
  - `androidx.compose.material3`
  - `androidx.compose.material:material-icons-core` & `material-icons-extended`
  - `androidx.activity:activity-compose`
  - `androidx.lifecycle:lifecycle-runtime-ktx`, `lifecycle-runtime-compose`, `lifecycle-viewmodel-compose`
  - `androidx.core:core-ktx`

### Kotlin Standard Library & Coroutines
- **ناشر:** JetBrains s.r.o.
- **مجوز:** Apache License, Version 2.0
- **ماژول‌های فعال:**
  - `org.jetbrains.kotlinx:kotlinx-coroutines-core`
  - `org.jetbrains.kotlinx:kotlinx-coroutines-android`

---

## ۲. کتابخانه‌های تست و ممیزی (Test & Audit Dependencies)

### JUnit 4 & Robolectric & AndroidX Test
- **مجوز:** Eclipse Public License 1.0 / MIT License / Apache License 2.0
- **کاربرد:** اجرای تست‌های واحد JVM و تست‌های کانتکست اندروید (`testDebugUnitTest`).

### chess.js (فقط در محیط اسکریپت ممیزی مرحله صفر)
- **ناشر:** Jeff Hlywa
- **مجوز:** BSD-2-Clause License
- **توضیحات:** صرفاً در مرحله صفر ممیزی داده‌ها مورد استفاده قرار گرفت و داخل فایل APK نهایی بسته‌بندی نشده است (موتور شطرنج زمان اجرا ۱۰۰٪ به زبان Kotlin در پکیج `com.example.chess` پیاده‌سازی شده است).

---

## ۳. گلیف‌ها و دارایی‌های تصویری (Assets & Glyphs)

### گلیف‌های بین‌المللی شطرنج (Unicode Standard Chess Glyphs)
- **کدهای یونیکد:** U+2654 تا U+265F (♚ ♛ ♜ ♝ ♞ ♟ ♔ ♕ ♖ ♗ ♘ ♙)
- **مجوز:** استاندارد کنسرسیوم یونیکد (Unicode Consortium Data Files and Software License) / رندر شده با قلم پیش‌فرض سیستم اندروید.
- **توضیحات:** هیچ تصویر یا اسکرین‌شات دارای حق نشری از کتاب اصلی در رابط کاربری استفاده نشده و صفحه شطرنج مستقیماً از رشته FEN رندر می‌شود.

### آیکون برنامه و بردارها (Vector & Adaptive Icon)
- **مجوز:** Creative Commons Zero (CC0) / طراحی اختصاصی برداری در محیط پروژه بدون وابستگی شخص ثالث.
