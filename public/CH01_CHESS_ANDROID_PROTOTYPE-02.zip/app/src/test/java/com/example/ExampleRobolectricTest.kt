package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.ChapterRepository
import com.example.data.UserPreferencesManager
import com.example.ui.ChapterViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("آموزش شطرنج", appName)
    }

    @Test
    fun `verify chapter repository loads 10 diagrams and 6 sections with fixed ids`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = ChapterRepository(context)
        val diagrams = repo.getDiagrams()
        val sections = repo.getSections()

        assertEquals(10, diagrams.size)
        assertEquals(6, sections.size)
        assertEquals("BD-025", diagrams.first().diagramId)
        assertEquals("BD-034", diagrams.last().diagramId)

        assertEquals("SEC_CH01_01_OPENING", sections[0].sectionId)
        assertEquals("SEC_CH01_02_CHECKMATE", sections[1].sectionId)
        assertEquals("SEC_CH01_03_RESIGNATION", sections[2].sectionId)
        assertEquals("SEC_CH01_04_TIMING_OUT", sections[3].sectionId)
        assertEquals("SEC_CH01_05_ABANDONMENT", sections[4].sectionId)
        assertEquals("SEC_CH01_06_SUMMARY", sections[5].sectionId)

        sections.forEach { section ->
            assertTrue(section.translationSlot.isPending)
            assertEquals(section.sectionId, section.translationSlot.sectionId)
        }
    }

    @Test
    fun `verify all PGN and exercise references in repository are valid with no dangling refs`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = ChapterRepository(context)
        val diagrams = repo.getDiagrams()

        val bd032 = diagrams.first { it.diagramId == "BD-032" }
        assertNull("BD-032 single pgnRef must be null", bd032.pgnRef)
        assertEquals(
            "BD-032 solutionPgnRefs must contain both verified mate solutions",
            listOf("BD032_MATE_QH8", "BD032_MATE_QH2"),
            bd032.solutionPgnRefs
        )

        // Verify all PGN references and precomputed sequences across all 10 diagrams
        assertTrue(
            "All diagram PGN references, solution references, and precomputed replay steps must be valid",
            repo.validateAllReferencesAndReplays()
        )
    }

    @Test
    fun `verify BD032 does not reveal solutions before solving and supports retry without reset`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val prefs = UserPreferencesManager(app)
        prefs.setBd032Solved(false)

        val viewModel = ChapterViewModel(app)
        val initialFen = "8/8/1p6/1k2q1P1/7K/8/8/6r1 b - - 0 1"

        // 1. Before solving, no solution or target coordinates are revealed
        val state0 = viewModel.uiState.value.bd032State
        assertFalse(state0.isSolved)
        assertNull(state0.solutionPlayed)
        assertNull(state0.feedbackMessage)
        assertEquals(initialFen, state0.currentFen)

        // 2. Select Queen at e5 (file 4, rank 4)
        viewModel.onBd032SquareClicked(4, 4)
        val stateSelected = viewModel.uiState.value.bd032State
        assertEquals("e5", stateSelected.selectedSquare)
        // Selection feedback must NOT leak 'h8' or 'h2'
        assertFalse(stateSelected.feedbackMessage?.contains("h8") == true)
        assertFalse(stateSelected.feedbackMessage?.contains("h2") == true)

        // 3. Play legal non-mating move: e5 -> e8 (file 4, rank 7)
        viewModel.onBd032SquareClicked(4, 7)
        val stateAfterWrong = viewModel.uiState.value.bd032State
        assertFalse("Qe8 is not checkmate, so exercise must remain unsolved", stateAfterWrong.isSolved)
        assertFalse(stateAfterWrong.feedbackIsSuccess)
        assertEquals("Board must automatically revert to initial FEN after non-mating move", initialFen, stateAfterWrong.currentFen)
        assertNull("Selection must be cleared", stateAfterWrong.selectedSquare)

        // 4. Retry immediately WITHOUT pressing Reset: select Queen at e5 (4, 4) -> move to h2 (7, 1)
        viewModel.onBd032SquareClicked(4, 4)
        assertEquals("e5", viewModel.uiState.value.bd032State.selectedSquare)
        viewModel.onBd032SquareClicked(7, 1) // Qh2#

        val stateSolved = viewModel.uiState.value.bd032State
        assertTrue("Qh2# must mark exercise as solved", stateSolved.isSolved)
        assertTrue(stateSolved.feedbackIsSuccess)
        assertEquals("Qh2#", stateSolved.solutionPlayed)
        assertEquals("8/8/1p6/1k4P1/7K/8/7q/6r1 w - - 1 2", stateSolved.currentFen)

        // 5. Once solved, further clicks on the board must be ignored until Reset
        val solvedFen = stateSolved.currentFen
        viewModel.onBd032SquareClicked(6, 0) // click rook at g1
        assertEquals(solvedFen, viewModel.uiState.value.bd032State.currentFen)
        assertNull(viewModel.uiState.value.bd032State.selectedSquare)
    }

    @Test
    fun `verify BD032 reset clears persisted solved status across app restart`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val prefs = UserPreferencesManager(app)
        val viewModel = ChapterViewModel(app)

        // Solve BD-032 with Qh8# (e5 -> h8)
        viewModel.onBd032SquareClicked(4, 4)
        viewModel.onBd032SquareClicked(7, 7)
        assertTrue(viewModel.uiState.value.bd032State.isSolved)
        assertTrue(prefs.isBd032Solved())

        // Call Reset
        viewModel.resetBd032()
        assertFalse("UI state must be unsolved after reset", viewModel.uiState.value.bd032State.isSolved)
        assertFalse("Persisted preference must be false after reset", prefs.isBd032Solved())

        // Simulate closing and reopening the app by creating a new ViewModel instance
        val restartedViewModel = ChapterViewModel(app)
        assertFalse(
            "After app restart following reset, exercise must still be unsolved",
            restartedViewModel.uiState.value.bd032State.isSolved
        )
    }
}
