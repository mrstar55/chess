# گزارش پیاده‌سازی، کنترل کیفیت و بهینه‌سازی فنی — فصل اول

این گزارش مستندات کامل مرحله کنترل کیفیت، ارزیابی مجدد `KChessLib`، تکمیل اعتبارسنجی موتور شطرنج، اصلاح گزارش تست‌ها و بهینه‌سازی حجم APK را بر اساس نتایج واقعی اجرای Gradle ارائه می‌دهد.

---

## ۱. گزارش ارزیابی تجربی `io.github.cvb941:kchesslib:1.0.5` در برابر `ChessEngine`

### ۱.۱ مشخصات کتابخانه در Maven Central
- **شناسه Maven:** `io.github.cvb941:kchesslib:1.0.5`
- **مخزن:** منتشرشده در Maven Central (`https://central.sonatype.com/artifact/io.github.cvb941/kchesslib/1.0.5`)
- **مجوز:** **Apache License 2.0** (مجاز برای استفاده تجاری)
- **معماری:** فورک Kotlin Multiplatform از `bhlangonijr/chesslib` (توسط Lukas Kusik / `cvb941`)

### ۱.۲ بررسی سازگاری با Android، KGP 2.2.10 و وابستگی‌های انتقالی
در آزمایش مستقل، وابستگی `implementation("io.github.cvb941:kchesslib:1.0.5")` به `app/build.gradle.kts` اضافه شد و دستور `gradle :app:dependencies --configuration debugRuntimeClasspath assembleDebug` اجرا گردید:
- **درخت وابستگی‌های انتقالی واقعی:**
  - `io.github.cvb941:kchesslib-jvm:1.0.5`
  - `org.jetbrains.kotlin:kotlin-stdlib:2.2.21` (ارتقای اجباری `kotlin-stdlib` از نسخه `2.2.10` پروژه به `2.2.21`)
  - `org.jetbrains.kotlinx:kotlinx-datetime-jvm:0.7.1`
  - `org.jetbrains.kotlinx:kotlinx-io-core-jvm:0.8.2` و `kotlinx-io-bytestring-jvm:0.8.2`
- **بررسی بایت‌کد (`javap -v`):**
  - کلاس‌های `kchesslib-jvm-1.0.5.jar` با **Java 21 (`major version: 65`)** و متادیتای کاتلین `mv=[2,2,0]` کامپایل شده‌اند.
  - اگرچه روی JDK 21 به کمک Desugaring در D8 کامپایل می‌شود، اما **روی JDK 17 (که حداقل JDK رسمی پروژه و AGP 9.1.1 است) با خطای `UnsupportedClassVersionError` (نسخه کلاس 65.0 در برابر 61.0) مواجه می‌شود**.
- **تأثیر بر حجم APK:**
  - فایل `kchesslib-jvm-1.0.5.jar` علاوه بر کدهای موتور و وابستگی‌های `kotlinx-datetime` و `kotlinx-io`، یک فایل دیتابیس گشایش `eco.pgn` به حجم **۳۵۸,۸۸۰ بایت** (فشرده‌نشده) را داخل ریشه APK قرار می‌دهد.

### ۱.۳ آزمایش مستقیم عملکردی (`KChessLib` در برابر `ChessEngine` اختصاصی)
در تست مستقیم روی کلاس `com.github.bhlangonijr.chesslib.Board`:
1. **موارد موفق در `KChessLib`:** تولید حرکات قانونی در وضعیت‌های معتبر (`20` حرکت شروع، `42` حرکت در `BD-032`)، تشخیص کیش و مات (`Qh8#` و `Qh2#` در `BD-032`)، تشخیص غیرمات بودن `BD-027` (`1...Kg8`)، تشخیص پات (`isStaleMate`)، حذف پیاده در آن‌پاسان و ارتقای پیاده.
2. **موارد شکست در `KChessLib` نسبت به الزامات پروژه:**
   - **شکست در تست قلعه بدون رخ (`testCastlingWithoutRookRejected`):** در `MoveGenerator.generateCastleMoves` و `Board.loadFromFen`، کتابخانه `KChessLib` حضور واقعی رخ در خانه‌های `a1, h1, a8, h8` را بررسی نمی‌کند! در نتیجه برای FEN `4k3/8/8/8/8/8/8/4K3 w KQ - 0 1`، علی‌رغم خالی بودن خانه‌های `a1` و `h1`، حرکات غیرقانونی قلعه `e1g1` و `e1c1` را به‌عنوان حرکت قانونی تولید می‌کند.
   - **شکست در اعتبارسنجی FEN (`testStrictFenValidation_RejectsInvalidFen`):** متد `Board.loadFromFen(fen)` در `KChessLib` بدون پرتاب خطا، FENهای نامعتبر زیر را می‌پذیرد:
     - ردیف‌های با کمتر از ۸ خانه (`.../RNBQKBN w KQkq - 0 1`)
     - ارقام متوالی در یک ردیف (`44/8/...`)
     - وجود پیاده در عرض ۱ یا ۸ (`.../RNBQKBNP w KQkq - 0 1`)
     - شاه‌های مجاور (`8/8/8/4k3/4K3/8/8/8 w - - 0 1`)
     - نبود شاه روی صفحه (که هنگام فراخوانی `isMated` باعث `ArrayIndexOutOfBoundsException` می‌شود)

### ۱.۴ نتیجه‌گیری و پیشنهاد مهندسی
با توجه به باگ تولید قلعه بدون رخ در `KChessLib 1.0.5`، نبود اعتبارسنجی ساختار FEN در `loadFromFen`، ناسازگاری بایت‌کد Java 21 (`major version: 65`) با JDK 17 و تحمیل وابستگی‌های انتقالی اضافی (`kotlin-stdlib:2.2.21`، `kotlinx-datetime`، `kotlinx-io` و `eco.pgn`)، **حفظ موتور اختصاصی پروژه (`ChessEngine`) در پشت لایه `ChessRulesAdapter` تصمیم فنی دقیق‌تر، ایمن‌تر و قابل نگهداری‌تر است**.

---

## ۲. تکمیل اعتبارسنجی موتور اختصاصی و سامانه Replay

### ۲.۱ اصلاح `PgnSequence.validateIntegrity` (`PgnReplayer.kt` و `chapter_01_pgn_steps.json`)
- در متد `PgnSequence.validateIntegrity` بررسی برابری فیلد **`enPassant`** (`actualNext.enPassant == expectedNextState.enPassant`) به بررسی‌های `board`، `activeColor`، `castling`، `halfMove` و `fullMove` اضافه شد.
- در فایل `chapter_01_pgn_steps.json` نیز خانه‌های هدف آن‌پاسان در گام‌های میانی پس از حرکت دوخانه‌ای پیاده (`e3`, `e6`, `g3`, `d3`, `g6`, `c3`, `a6`, `a3`, `f3`, `d6`) مطابق استاندارد ۶ فیلدی FEN اصلاح شدند (بدون هیچ تغییری در FENهای ۱۰ نمودار فصل اول در `chapter_01_diagram_data.json`).

### ۲.۲ اصلاح و تفکیک `ChessEngine.parseFen` (`ChessEngine.kt`)
- **تفکیک FEN استاندارد ۶ فیلدی از FEN ناقص:**
  - `ChessEngine.parseFen(fen)` فقط رشته‌های استاندارد **دقیقاً ۶ فیلدی** را می‌پذیرد.
  - `ChessEngine.parseIncompleteFen(fen)` به‌صورت مجزا برای ورودی‌های ۲ تا ۵ فیلدی تعریف شده است.
- **قواعد اعتبارسنجی اضافه‌شده به `parseFen`:**
  1. رد **ارقام متوالی در یک ردیف** (مانند `44` یا `17` که جمعشان ۸ است اما ساختار FEN آن‌ها نامعتبر است).
  2. رد **شاه‌های مجاور و غیرقانونی** (`abs(wkFile - bkFile) <= 1 && abs(wkRank - bkRank) <= 1`).
  3. بررسی **اعتبار حقوق قلعه (`K, Q, k, q`) نسبت به محل واقعی شاه و رخ**: وجود `K` یا `Q` مستلزم حضور شاه سفید در `e1` و رخ سفید در `h1`/`a1` است و وجود `k` یا `q` مستلزم حضور شاه سیاه در `e8` و رخ سیاه در `h8`/`a8` است.
  4. بررسی **اعتبار خانه `enPassant` نسبت به نوبت حرکت و موقعیت پیاده‌ها**:
     - در نوبت سفید (`w`)، خانه آن‌پاسان فقط می‌تواند در عرض `6` باشد، خانه‌های عرض `6` و `7` آن ستون باید خالی باشند و پیاده سیاه باید در عرض `5` همان ستون حضور داشته باشد.
     - در نوبت سیاه (`b`)، خانه آن‌پاسان فقط می‌تواند در عرض `3` باشد، خانه‌های عرض `3` و `2` آن ستون باید خالی باشند و پیاده سفید باید در عرض `4` همان ستون حضور داشته باشد.

---

## ۳. گزارش واقعی اجرای تست‌ها (تعداد دقیق `@Test` و خروجی JUnit)

تمامی **۲۹ تست** موجود در سورس با دستور `gradle testDebugUnitTest` اجرا شده و با **۰ خطا و ۰ شکست** (`failures="0" errors="0"`) 통과 شدند:

| کلاس تست | تعداد `@Test` | زمان اجرا | وضعیت |
|---|---|---|---|
| `com.example.ChessChapterOneTest` | **22** | `0.841s` | **PASS (22/22)** |
| `com.example.ExampleRobolectricTest` | **6** | `12.126s` | **PASS (6/6)** |
| `com.example.ExampleUnitTest` | **1** | `0.000s` | **PASS (1/1)** |
| **مجموع کل** | **29** | `12.967s` | **PASS (29/29)** |

### جزئیات تست‌های حرکتی، Perft و رابط کاربری RTL:
1. **`testPerft_StandardInitialPositionDepths1To4`:**
   - `Perft(1) = 20` | `Perft(2) = 400` | `Perft(3) = 8902` | `Perft(4) = 197281`
2. **`testPerft_ComplexPositions_KiwipeteAndEnPassantAndPromotions`:**
   - **Kiwipete** (`r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1`): `Perft(1) = 48`، `Perft(2) = 2039`، `Perft(3) = 97862`
   - **CPW Position 3** (`8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1`): `Perft(1) = 14`، `Perft(2) = 191`، `Perft(3) = 2812`، `Perft(4) = 43238`
   - **CPW Position 4** (`r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1`): `Perft(1) = 6`، `Perft(2) = 264`، `Perft(3) = 9467`
3. **`testAllChapterOneDiagrams_Bd025ToBd034_FenAndEngineValidation`:**
   - بررسی هر ۱۰ دیاگرام `BD-025` تا `BD-034` (تأیید مات بودن `BD-026`, `BD-028`, `BD-029`, `BD-030`؛ در کیش اما غیرمات بودن `BD-027` و `BD-034`؛ و عدم کیش/مات در `BD-025`, `BD-031`, `BD-032`, `BD-033`).
4. **`verify ChessBoardView composable renders files a to h LTR and ranks 8 to 1 top to bottom inside RTL layout` (`ExampleRobolectricTest`):**
   - رندر واقعی کامپوننت `ChessBoardView` در داخل کانتینر فارسی `LayoutDirection.Rtl` با استفاده از `createComposeRule()` و بررسی مختصات پیکسلی واقعی (`boundsInRoot`) خانه‌های `square_a1` تا `square_h1` (افزایش اکید مختصات افقی `left` از چپ به راست) و خانه‌های `square_a8` تا `square_a1` (افزایش اکید مختصات عمودی `top` از بالا به پایین).

---

## ۴. گزارش کاهش حجم APK (قبل و بعد از بهینه‌سازی)

### علت حجم بالای قبلی
کتابخانه `androidx.compose.material:material-icons-extended` حدود **۳۲.۴ مگابایت** کد DEX فشرده‌نشده به پروژه اضافه می‌کرد، در حالی که تنها **۹ آیکون** از آن در پروژه استفاده شده بود (`FastRewind`, `FastForward`, `Shield`, `FormatSize`, `PendingActions`, `Bookmark`, `BookmarkBorder`, `AutoStories`, `ChevronLeft`).

### اقدام انجام‌شده
- ساخت فایل سبک `AppIcons.kt` شامل بردارهای استاندارد ۲۴×۲۴ همان ۹ آیکون و حذف وابستگی `material-icons-extended` از `app/build.gradle.kts`.
- فعال‌سازی `isMinifyEnabled = true`، `isShrinkResources = true` و `isCrunchPngs = true` برای بیلد `release`.

### مقایسه عددی حجم پیش و پس از بهینه‌سازی

| شاخص اندازه‌گیری | پیش از بهینه‌سازی | پس از بهینه‌سازی | میزان کاهش |
|---|---|---|---|
| **حجم فایل `app-debug.apk`** | `22,329,140` بایت (**21.29 MiB / 22.3 MB**) | `9,715,055` بایت (**9.26 MiB / 9.7 MB**) | **56.5% کاهش (-12.6 MB)** |
| **مجموع DEX در Debug (فشرده‌نشده)** | `56,600,216` بایت (**53.98 MiB**) | `24,185,644` بایت (**23.06 MiB**) | **57.3% کاهش (-32.4 MB)** |
| **مجموع DEX در Debug (فشرده در APK)** | `16,089,288` بایت (**15.34 MiB**) | `9,133,439` بایت (**8.71 MiB**) | **43.2% کاهش (-7.0 MB)** |
| **کد DEX نسخه Release با R8 (`minifyReleaseWithR8`)** | بدون R8: `56,600,216` بایت | با R8: `1,606,576` بایت (**1.53 MiB** فشرده‌نشده / **0.76 MiB** فشرده) | **97.2% کاهش حجم DEX** |
