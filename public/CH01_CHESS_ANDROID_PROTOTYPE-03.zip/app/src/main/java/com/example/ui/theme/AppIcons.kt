package com.example.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Lightweight Material Design 24x24 vector icons for the 9 icons previously
 * imported from material-icons-extended, eliminating ~20 MB of unused icon DEX bloat
 * while keeping the UI appearance 100% identical.
 */
object AppIcons {

    val FastRewind: ImageVector by lazy {
        ImageVector.Builder(
            name = "FastRewind",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).path(fill = SolidColor(Color.Black)) {
            moveTo(11f, 18f)
            verticalLineTo(6f)
            lineToRelative(-8.5f, 6f)
            lineToRelative(8.5f, 6f)
            close()
            moveTo(11.5f, 12f)
            lineToRelative(8.5f, 6f)
            verticalLineTo(6f)
            lineToRelative(-8.5f, 6f)
            close()
        }.build()
    }

    val FastForward: ImageVector by lazy {
        ImageVector.Builder(
            name = "FastForward",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).path(fill = SolidColor(Color.Black)) {
            moveTo(4f, 18f)
            lineToRelative(8.5f, -6f)
            lineTo(4f, 6f)
            verticalLineToRelative(12f)
            close()
            moveTo(13f, 6f)
            verticalLineToRelative(12f)
            lineToRelative(8.5f, -6f)
            lineTo(13f, 6f)
            close()
        }.build()
    }

    val Shield: ImageVector by lazy {
        ImageVector.Builder(
            name = "Shield",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).path(fill = SolidColor(Color.Black)) {
            moveTo(12f, 1f)
            lineTo(3f, 5f)
            verticalLineToRelative(6f)
            curveToRelative(0f, 5.55f, 3.84f, 10.74f, 9f, 12f)
            curveToRelative(5.16f, -1.26f, 9f, -6.45f, 9f, -12f)
            verticalLineTo(5f)
            lineToRelative(-9f, -4f)
            close()
        }.build()
    }

    val FormatSize: ImageVector by lazy {
        ImageVector.Builder(
            name = "FormatSize",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).path(fill = SolidColor(Color.Black)) {
            moveTo(9f, 4f)
            verticalLineToRelative(3f)
            horizontalLineToRelative(5f)
            verticalLineToRelative(12f)
            horizontalLineToRelative(3f)
            verticalLineTo(7f)
            horizontalLineToRelative(5f)
            verticalLineTo(4f)
            horizontalLineTo(9f)
            close()
            moveTo(3f, 12f)
            horizontalLineToRelative(3f)
            verticalLineToRelative(7f)
            horizontalLineToRelative(3f)
            verticalLineToRelative(-7f)
            horizontalLineToRelative(3f)
            verticalLineTo(9f)
            horizontalLineTo(3f)
            verticalLineToRelative(3f)
            close()
        }.build()
    }

    val PendingActions: ImageVector by lazy {
        ImageVector.Builder(
            name = "PendingActions",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).path(fill = SolidColor(Color.Black)) {
            moveTo(17f, 12f)
            curveToRelative(-2.76f, 0f, -5f, 2.24f, -5f, 5f)
            reflectiveCurveToRelative(2.24f, 5f, 5f, 5f)
            curveToRelative(2.76f, 0f, 5f, -2.24f, 5f, -5f)
            reflectiveCurveTo(19.76f, 12f, 17f, 12f)
            close()
            moveTo(18.65f, 19.35f)
            lineTo(16.5f, 17.2f)
            verticalLineTo(14f)
            horizontalLineToRelative(1f)
            verticalLineToRelative(2.79f)
            lineToRelative(1.85f, 1.85f)
            lineTo(18.65f, 19.35f)
            close()
            moveTo(18f, 3f)
            horizontalLineToRelative(-3.18f)
            curveTo(14.4f, 1.84f, 13.3f, 1f, 12f, 1f)
            reflectiveCurveTo(9.6f, 1.84f, 9.18f, 3f)
            horizontalLineTo(6f)
            curveTo(4.9f, 3f, 4f, 3.9f, 4f, 5f)
            verticalLineToRelative(15f)
            curveToRelative(0f, 1.1f, 0.9f, 2f, 2f, 2f)
            horizontalLineToRelative(6.11f)
            curveToRelative(-0.59f, -0.57f, -1.07f, -1.25f, -1.42f, -2f)
            horizontalLineTo(6f)
            verticalLineTo(5f)
            horizontalLineToRelative(2f)
            verticalLineToRelative(3f)
            horizontalLineToRelative(8f)
            verticalLineTo(5f)
            horizontalLineToRelative(2f)
            verticalLineToRelative(5.08f)
            curveToRelative(0.71f, 0.1f, 1.38f, 0.31f, 2f, 0.6f)
            verticalLineTo(5f)
            curveTo(20f, 3.9f, 19.1f, 3f, 18f, 3f)
            close()
            moveTo(12f, 5f)
            curveToRelative(-0.55f, 0f, -1f, -0.45f, -1f, -1f)
            curveToRelative(0f, -0.55f, 0.45f, -1f, 1f, -1f)
            curveToRelative(0.55f, 0f, 1f, 0.45f, 1f, 1f)
            curveTo(13f, 4.55f, 12.55f, 5f, 12f, 5f)
            close()
        }.build()
    }

    val Bookmark: ImageVector by lazy {
        ImageVector.Builder(
            name = "Bookmark",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).path(fill = SolidColor(Color.Black)) {
            moveTo(17f, 3f)
            horizontalLineTo(7f)
            curveToRelative(-1.1f, 0f, -1.99f, 0.9f, -1.99f, 2f)
            lineTo(5f, 21f)
            lineToRelative(7f, -3f)
            lineToRelative(7f, 3f)
            verticalLineTo(5f)
            curveToRelative(0f, -1.1f, -0.9f, -2f, -2f, -2f)
            close()
        }.build()
    }

    val BookmarkBorder: ImageVector by lazy {
        ImageVector.Builder(
            name = "BookmarkBorder",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).path(fill = SolidColor(Color.Black)) {
            moveTo(17f, 3f)
            horizontalLineTo(7f)
            curveToRelative(-1.1f, 0f, -1.99f, 0.9f, -1.99f, 2f)
            lineTo(5f, 21f)
            lineToRelative(7f, -3f)
            lineToRelative(7f, 3f)
            verticalLineTo(5f)
            curveToRelative(0f, -1.1f, -0.9f, -2f, -2f, -2f)
            close()
            moveTo(17f, 18f)
            lineToRelative(-5f, -2.18f)
            lineTo(7f, 18f)
            verticalLineTo(5f)
            horizontalLineToRelative(10f)
            verticalLineToRelative(13f)
            close()
        }.build()
    }

    val AutoStories: ImageVector by lazy {
        ImageVector.Builder(
            name = "AutoStories",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).path(
            fill = SolidColor(Color.Black),
            pathFillType = PathFillType.NonZero,
            strokeLineCap = StrokeCap.Butt,
            strokeLineJoin = StrokeJoin.Miter
        ) {
            moveTo(19f, 1f)
            lineToRelative(-5f, 5f)
            verticalLineToRelative(11f)
            lineToRelative(5f, -4.5f)
            verticalLineTo(1f)
            close()
            moveTo(1f, 6f)
            verticalLineToRelative(14.65f)
            curveToRelative(0f, 0.25f, 0.25f, 0.5f, 0.5f, 0.5f)
            curveToRelative(0.1f, 0f, 0.15f, -0.05f, 0.25f, -0.05f)
            curveTo(3.1f, 20.45f, 5.05f, 20f, 6.5f, 20f)
            curveToRelative(1.95f, 0f, 4.05f, 0.4f, 5.5f, 1.5f)
            verticalLineTo(6f)
            curveToRelative(-1.45f, -1.1f, -3.55f, -1.5f, -5.5f, -1.5f)
            reflectiveCurveTo(2.45f, 4.9f, 1f, 6f)
            close()
            moveTo(23f, 19.5f)
            verticalLineTo(6f)
            curveToRelative(-0.6f, -0.45f, -1.25f, -0.75f, -2f, -1f)
            verticalLineToRelative(13.5f)
            curveToRelative(-1.1f, -0.35f, -2.3f, -0.5f, -3.5f, -0.5f)
            curveToRelative(-1.7f, 0f, -4.15f, 0.65f, -5.5f, 1.5f)
            verticalLineToRelative(2f)
            curveToRelative(1.35f, -0.85f, 3.8f, -1.5f, 5.5f, -1.5f)
            curveToRelative(1.65f, 0f, 3.35f, 0.3f, 4.75f, 1.05f)
            curveToRelative(0.1f, 0.05f, 0.15f, 0.05f, 0.25f, 0.05f)
            curveToRelative(0.25f, 0f, 0.5f, -0.25f, 0.5f, -0.5f)
            verticalLineTo(19.5f)
            close()
        }.build()
    }

    val ChevronLeft: ImageVector by lazy {
        ImageVector.Builder(
            name = "ChevronLeft",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).path(fill = SolidColor(Color.Black)) {
            moveTo(15.41f, 7.41f)
            lineTo(14f, 6f)
            lineToRelative(-6f, 6f)
            lineToRelative(6f, 6f)
            lineToRelative(1.41f, -1.41f)
            lineTo(10.83f, 12f)
            close()
        }.build()
    }
}
