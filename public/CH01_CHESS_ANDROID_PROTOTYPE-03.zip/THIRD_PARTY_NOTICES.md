# Third-Party Notices & Chess Engine Library Evaluation

## 1. Empirical Evaluation of `io.github.cvb941:kchesslib:1.0.5` vs Custom `ChessEngine`

During this quality control phase, we conducted a direct empirical evaluation of **`io.github.cvb941:kchesslib:1.0.5`** from Maven Central alongside our project's **`ChessEngine`**.

### 1.1 Artifact & License Verification
- **Maven Coordinate:** `io.github.cvb941:kchesslib:1.0.5` (published on Maven Central: `https://central.sonatype.com/artifact/io.github.cvb941/kchesslib/1.0.5`)
- **Author / Origin:** Lukas Kusik (`cvb941`) — Kotlin Multiplatform port of `bhlangonijr/chesslib`
- **License:** **Apache License 2.0** (permissive; allows commercial use, modification, and distribution)

### 1.2 Build, Bytecode & Transitive Dependency Analysis
When added to `app/build.gradle.kts` (`implementation("io.github.cvb941:kchesslib:1.0.5")`), Gradle resolved the following dependency subtree on `debugRuntimeClasspath`:
```text
\--- io.github.cvb941:kchesslib:1.0.5
     \--- io.github.cvb941:kchesslib-jvm:1.0.5
          +--- org.jetbrains.kotlin:kotlin-stdlib:2.2.21
          +--- org.jetbrains.kotlinx:kotlinx-datetime:0.7.1
          |    \--- org.jetbrains.kotlinx:kotlinx-datetime-jvm:0.7.1
          \--- org.jetbrains.kotlinx:kotlinx-io-core:0.8.2
               \--- org.jetbrains.kotlinx:kotlinx-io-core-jvm:0.8.2
                    \--- org.jetbrains.kotlinx:kotlinx-io-bytestring-jvm:0.8.2
```
- **Kotlin Version Skew:** The project uses Kotlin Gradle Plugin **`2.2.10`**, whereas `kchesslib:1.0.5` requires `kotlin-stdlib:2.2.21` (compiled with Kotlin `2.2.21`, metadata version `2.2.0`).
- **Java 21 Bytecode (`major version: 65`) Issue:** Inspection of `kchesslib-jvm-1.0.5.jar` via `javap -v` confirmed that its class files (`com/github/bhlangonijr/chesslib/Board.class`) are compiled with **Java 21 bytecode (`major version: 65`)**. While the build succeeds when running Gradle on JDK 21 (because D8 desugars the bytecode for Android), **running Gradle on JDK 17 (the minimum required JDK for AGP 9.1.1) fails with `UnsupportedClassVersionError` (class file version 65.0 vs 61.0)**.
- **Embedded Resource Overhead:** `kchesslib-jvm-1.0.5.jar` bundles an uncompressed `358,880`-byte `eco.pgn` opening database inside the APK root alongside `kotlinx-datetime` and `kotlinx-io-core`.

### 1.3 Functional & Test Suite Comparison (`KChessLib 1.0.5` vs `ChessEngine`)

| Test / Capability | `io.github.cvb941:kchesslib:1.0.5` | Project `ChessEngine` (`ChessRulesAdapter`) |
|---|---|---|
| Standard Legal Moves & Perft(1..4) | PASS (`20, 400, 8902, 197281`) | PASS (`20, 400, 8902, 197281`) |
| Complex Perft (Kiwipete, Pos 3, Pos 4) | PASS | PASS (`97862`, `43238`, `9467`) |
| `BD-032` Mate-in-1 (`Qh8#`, `Qh2#`) | PASS | PASS |
| `BD-027` Escapable Check (`1...Kg8`) | PASS | PASS |
| En Passant Capture & Pawn Removal | PASS | PASS |
| Promotion to `Q, R, B, N` | PASS | PASS |
| Castling Rights Removed on Rook Capture | PASS | PASS |
| **Castling Without Rook on Board (`4k3/8/8/8/8/8/8/4K3 w KQ - 0 1`)** | **FAIL** (`generateCastleMoves` generates `e1g1` & `e1c1` without checking if rooks exist on `a1`/`h1`) | **PASS** (Rejected both in `parseFen` and in `generateKingMoves`) |
| **Strict FEN Validation (7-square rank, `44` consecutive digits, pawn on rank 1/8, missing king, adjacent kings, invalid en-passant)** | **FAIL** (`loadFromFen` silently accepts malformed ranks, pawns on rank 1, and adjacent kings without throwing) | **PASS** (Strictly validated in `parseFen` with `IllegalArgumentException`) |
| **JDK 17 Compatibility** | **FAIL** (`major version: 65` requires JDK 21) | **PASS** (`JavaVersion.VERSION_11` compatible with JDK 17+) |

**Conclusion & Recommendation:**
Because `io.github.cvb941:kchesslib:1.0.5` (1) contains a bug allowing castling when the FEN castling flag is set even if no rook is present on `a1/h1/a8/h8`, (2) lacks strict FEN validation in `loadFromFen()`, and (3) ships Java 21 (`major version: 65`) bytecode that breaks JDK 17 builds and upgrades `kotlin-stdlib` to `2.2.21`, **retaining the project's `ChessEngine` behind `ChessRulesAdapter` is the technically superior and safer engineering decision**.

---

## 2. Included Open-Source Libraries in APK

All libraries packaged in the application are official AndroidX / JetBrains libraries distributed under **Apache License 2.0**:
1. **AndroidX Core, Activity & Lifecycle (`androidx.core`, `androidx.activity`, `androidx.lifecycle`)** — Apache License 2.0
2. **AndroidX Jetpack Compose UI & Material 3 (`androidx.compose.ui`, `androidx.compose.material3`, `androidx.compose.material:material-icons-core`)** — Apache License 2.0
3. **Kotlin Coroutines (`org.jetbrains.kotlinx:kotlinx-coroutines-android`)** — Apache License 2.0
4. **JUnit 4 & Robolectric (Test-only scope)** — Eclipse Public License 1.0 / MIT License
