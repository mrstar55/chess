package com.example.data

import android.content.Context
import com.example.chess.ChessEngine
import com.example.chess.ExerciseHandlerRegistry
import com.example.chess.PgnSequence
import com.example.model.AuditStatus
import com.example.model.BookCatalogEntry
import com.example.model.ChapterCatalogEntry
import com.example.model.ChapterManifest
import com.example.model.ContentBlockValidator
import com.example.model.ContentValidationResult
import com.example.model.DiagramItem
import com.example.model.ExerciseDefinition
import com.example.model.LibraryCatalog
import com.example.model.SectionContentBlock
import com.example.model.SectionItem
import com.example.model.SectionKind
import com.example.model.SectionManifestEntry
import com.example.model.TranslationSlot
import com.example.model.TranslationStatus
import org.json.JSONArray
import org.json.JSONObject

class ChapterRepository @JvmOverloads constructor(
    private val context: Context,
    private val libraryAssetPath: String = DEFAULT_LIBRARY_ASSET_PATH,
    val assetReaderOverride: ((String) -> String)? = null
) {

    private val cachedDiagramsByChapter = mutableMapOf<String, List<DiagramItem>>()
    private val cachedSectionsByChapter = mutableMapOf<String, List<SectionItem>>()
    private val cachedPgnSequencesByChapter = mutableMapOf<String, Map<String, PgnSequence>>()
    private val cachedExercisesByChapter = mutableMapOf<String, List<ExerciseDefinition>>()

    private fun readAssetText(assetPath: String): String {
        require(ContentBlockValidator.isSafeRelativeAssetPath(assetPath)) {
            "Unsafe or invalid relative asset path: $assetPath"
        }
        if (assetReaderOverride != null) {
            return assetReaderOverride.invoke(assetPath)
        }
        return context.assets.open(assetPath).bufferedReader().use { it.readText() }
    }

    fun getLibraryCatalog(): LibraryCatalog {
        val root = JSONObject(readAssetText(libraryAssetPath))
        val schemaVersion = root.optInt("schemaVersion", 1)
        val defaultBookId = root.getString("defaultBookId")
        val booksArr = root.getJSONArray("books")
        val books = mutableListOf<BookCatalogEntry>()

        for (i in 0 until booksArr.length()) {
            val bObj = booksArr.getJSONObject(i)
            val chaptersArr = bObj.getJSONArray("chapters")
            val chapters = mutableListOf<ChapterCatalogEntry>()
            for (j in 0 until chaptersArr.length()) {
                val cObj = chaptersArr.getJSONObject(j)
                chapters.add(
                    ChapterCatalogEntry(
                        chapterId = cObj.getString("chapterId").trim(),
                        chapterNumber = cObj.getInt("chapterNumber"),
                        titleEn = cObj.getString("titleEn"),
                        titleFa = cObj.getString("titleFa"),
                        manifestPath = cObj.getString("manifestPath").trim(),
                        enabled = cObj.optBoolean("enabled", true)
                    )
                )
            }
            books.add(
                BookCatalogEntry(
                    bookId = bObj.getString("bookId").trim(),
                    titleEn = bObj.getString("titleEn"),
                    titleFa = bObj.getString("titleFa"),
                    authorEn = bObj.optString("authorEn", ""),
                    authorFa = bObj.optString("authorFa", ""),
                    chapters = chapters
                )
            )
        }

        return LibraryCatalog(
            schemaVersion = schemaVersion,
            defaultBookId = defaultBookId,
            books = books
        )
    }

    fun resolveDefaultBookId(): String {
        val catalog = getLibraryCatalog()
        return catalog.defaultBookId.ifBlank { catalog.books.firstOrNull()?.bookId ?: DEFAULT_BOOK_ID }
    }

    fun resolveInitialChapterEntry(
        preferredBookId: String? = null,
        preferredChapterId: String? = null
    ): Pair<BookCatalogEntry, ChapterCatalogEntry> {
        val catalog = getLibraryCatalog()
        val book = if (!preferredBookId.isNullOrBlank()) {
            catalog.findBook(preferredBookId) ?: catalog.books.first()
        } else {
            catalog.findBook(catalog.defaultBookId) ?: catalog.books.first()
        }
        val enabled = book.enabledChapters
        val chapter = if (!preferredChapterId.isNullOrBlank()) {
            enabled.find { it.chapterId == preferredChapterId }
                ?: enabled.firstOrNull()
                ?: book.chapters.first()
        } else {
            enabled.firstOrNull() ?: book.chapters.first()
        }
        return book to chapter
    }

    fun resolveDefaultChapterId(bookId: String = resolveDefaultBookId()): String {
        return resolveInitialChapterEntry(preferredBookId = bookId).second.chapterId
    }

    fun getBooks(): List<BookCatalogEntry> = getLibraryCatalog().books

    @JvmOverloads
    fun getChapters(bookId: String = resolveDefaultBookId()): List<ChapterCatalogEntry> {
        val catalog = getLibraryCatalog()
        val book = catalog.findBook(bookId) ?: return emptyList()
        return book.enabledChapters
    }

    @JvmOverloads
    fun getChapterManifest(
        chapterId: String = resolveDefaultChapterId(),
        bookId: String = resolveDefaultBookId()
    ): ChapterManifest {
        val catalog = getLibraryCatalog()
        val book = catalog.findBook(bookId)
            ?: throw IllegalArgumentException("Book not found: $bookId")
        val chapterEntry = book.chapters.find { it.chapterId == chapterId }
            ?: throw IllegalArgumentException("Chapter not found: $chapterId in book $bookId")
        val chapterBaseDir = chapterEntry.manifestPath.substringBeforeLast('/', "")
        return parseChapterManifest(
            manifestJsonText = readAssetText(chapterEntry.manifestPath),
            expectedChapterId = chapterId,
            chapterBaseDir = chapterBaseDir
        )
    }

    private fun resolveChapterRelativePath(chapterBaseDir: String, rawPath: String): String {
        val trimmed = rawPath.trim()
        if (trimmed.isEmpty()) return ""
        if (chapterBaseDir.isEmpty() || trimmed.startsWith("books/") || trimmed.startsWith("$chapterBaseDir/")) {
            return trimmed
        }
        return "$chapterBaseDir/$trimmed"
    }

    fun parseChapterManifest(
        manifestJsonText: String,
        expectedChapterId: String? = null,
        chapterBaseDir: String = ""
    ): ChapterManifest {
        val root = JSONObject(manifestJsonText)
        val chapterId = root.getString("chapterId").trim()
        val bookId = root.optString("bookId", DEFAULT_BOOK_ID).trim()
        val effectiveBaseDir = chapterBaseDir.ifEmpty { "books/$bookId/$chapterId" }
        if (expectedChapterId != null && chapterId != expectedChapterId) {
            throw IllegalArgumentException(
                "Chapter ID mismatch in chapter.json: expected $expectedChapterId, found $chapterId"
            )
        }
        val sectionsArr = root.getJSONArray("sections")
        val sections = mutableListOf<SectionManifestEntry>()
        for (i in 0 until sectionsArr.length()) {
            val sObj = sectionsArr.getJSONObject(i)
            val pagesArr = sObj.getJSONArray("pdfPages")
            val pages = (0 until pagesArr.length()).map { pagesArr.getInt(it) }
            val sectionId = sObj.getString("sectionId").trim()
            val titleEn = sObj.getString("titleEn")
            val titleFa = sObj.getString("titleFa")
            val kindStr = sObj.optString("sectionKind", "")
            val kind = if (kindStr.isNotBlank()) {
                SectionKind.fromString(kindStr)
            } else {
                SectionKind.fromSectionMetadata(sectionId, titleEn, titleFa)
            }
            val rawSectionFile = sObj.optString("file", "").ifBlank { sObj.optString("contentFile", "") }
            sections.add(
                SectionManifestEntry(
                    sectionId = sectionId,
                    order = sObj.optInt("order", i + 1),
                    sectionKind = kind,
                    titleEn = titleEn,
                    titleFa = titleFa,
                    pdfPages = pages,
                    contentFile = resolveChapterRelativePath(effectiveBaseDir, rawSectionFile)
                )
            )
        }

        val rawDiagramsFile = root.optString("diagramsFile", "diagrams.json")
        val rawPgnFile = root.optString("pgnSequencesFile", "").ifBlank { root.optString("pgnFile", "pgn_sequences.json") }
        val rawExercisesFile = root.optString("exercisesFile", "exercises.json")
        val rawNarrationFile = root.optString("narrationManifestFile", "").ifBlank {
            root.optString("narrationManifest", "")
        }

        return ChapterManifest(
            schemaVersion = root.optInt("schemaVersion", 1),
            bookId = bookId,
            chapterId = chapterId,
            chapterNumber = root.optInt("chapterNumber", 1),
            titleEn = root.getString("titleEn"),
            titleFa = root.getString("titleFa"),
            diagramsFile = resolveChapterRelativePath(effectiveBaseDir, rawDiagramsFile),
            pgnFile = resolveChapterRelativePath(effectiveBaseDir, rawPgnFile),
            exercisesFile = resolveChapterRelativePath(effectiveBaseDir, rawExercisesFile),
            narrationManifest = resolveChapterRelativePath(effectiveBaseDir, rawNarrationFile),
            sections = sections.sortedBy { it.order }
        )
    }

    @JvmOverloads
    fun getDiagrams(
        chapterId: String = resolveDefaultChapterId(),
        bookId: String = resolveDefaultBookId()
    ): List<DiagramItem> {
        val cacheKey = "$bookId:$chapterId"
        cachedDiagramsByChapter[cacheKey]?.let { return it }
        val loaded = loadDiagramsFromAssets(chapterId = chapterId, bookId = bookId)
        cachedDiagramsByChapter[cacheKey] = loaded
        return loaded
    }

    @JvmOverloads
    fun getSections(
        chapterId: String = resolveDefaultChapterId(),
        bookId: String = resolveDefaultBookId()
    ): List<SectionItem> {
        val cacheKey = "$bookId:$chapterId"
        cachedSectionsByChapter[cacheKey]?.let { return it }
        val loaded = loadSectionsFromAssets(chapterId = chapterId, bookId = bookId)
        cachedSectionsByChapter[cacheKey] = loaded
        return loaded
    }

    @JvmOverloads
    fun getPgnSequence(
        pgnRef: String,
        chapterId: String = resolveDefaultChapterId(),
        bookId: String = resolveDefaultBookId()
    ): PgnSequence? {
        return getAllPgnSequences(chapterId = chapterId, bookId = bookId)[pgnRef]
    }

    @JvmOverloads
    fun getAllPgnSequences(
        chapterId: String = resolveDefaultChapterId(),
        bookId: String = resolveDefaultBookId()
    ): Map<String, PgnSequence> {
        val cacheKey = "$bookId:$chapterId"
        cachedPgnSequencesByChapter[cacheKey]?.let { return it }
        val loaded = loadPgnSequencesFromAssets(chapterId = chapterId, bookId = bookId)
        cachedPgnSequencesByChapter[cacheKey] = loaded
        return loaded
    }

    @JvmOverloads
    fun getExercises(
        chapterId: String = resolveDefaultChapterId(),
        bookId: String = resolveDefaultBookId()
    ): List<ExerciseDefinition> {
        val cacheKey = "$bookId:$chapterId"
        cachedExercisesByChapter[cacheKey]?.let { return it }
        val loaded = loadExercisesFromAssets(chapterId = chapterId, bookId = bookId)
        cachedExercisesByChapter[cacheKey] = loaded
        return loaded
    }

    /**
     * Validates a chapter content pack including manifest relative paths, section files,
     * unique block IDs, diagram FENs, exercise definitions, handler types, and full PGN move replays.
     */
    @JvmOverloads
    fun validateChapterPack(
        chapterId: String = resolveDefaultChapterId(),
        bookId: String = resolveDefaultBookId()
    ): ContentValidationResult {
        val errors = mutableListOf<String>()
        val invalidRelativePaths = mutableListOf<String>()
        val invalidPgnRefs = mutableListOf<String>()

        return try {
            val manifest = getChapterManifest(chapterId = chapterId, bookId = bookId)

            val pathsToCheck = buildList {
                add(manifest.diagramsFile)
                add(manifest.pgnFile)
                if (manifest.exercisesFile.isNotBlank()) add(manifest.exercisesFile)
                if (manifest.narrationManifest.isNotBlank()) add(manifest.narrationManifest)
                manifest.sections.forEach { add(it.contentFile) }
            }
            for (path in pathsToCheck) {
                if (!ContentBlockValidator.isSafeRelativeAssetPath(path)) {
                    invalidRelativePaths.add(path)
                    errors.add("Invalid relative asset path: $path")
                }
            }

            if (manifest.sections.isEmpty()) {
                errors.add("Chapter $chapterId has no sections")
            }

            val sections = getSections(chapterId = chapterId, bookId = bookId)
            val diagrams = getDiagrams(chapterId = chapterId, bookId = bookId)
            val allSequences = getAllPgnSequences(chapterId = chapterId, bookId = bookId)
            val exercises = getExercises(chapterId = chapterId, bookId = bookId)

            val blockValidation = ContentBlockValidator.validateSectionsAndBlocks(
                sections = sections,
                diagrams = diagrams,
                expectedSectionSlotIds = manifest.sections.map { it.sectionId },
                exercises = exercises
            )
            errors.addAll(blockValidation.errorMessages)

            val diagramsById = diagrams.associateBy { it.diagramId }

            for (exercise in exercises) {
                if (!ExerciseHandlerRegistry.isSupportedHandlerType(exercise.handlerType)) {
                    errors.add("Unsupported exercise handlerType '${exercise.handlerType}' in exercise '${exercise.exerciseId}'")
                }
                val diagram = diagramsById[exercise.diagramId]
                if (diagram != null) {
                    for (solRef in exercise.acceptedSolutionPgnRefs) {
                        val solSeq = allSequences[solRef]
                        if (solSeq == null) {
                            invalidPgnRefs.add(solRef)
                            errors.add("Missing solution PGN '$solRef' for exercise '${exercise.exerciseId}'")
                        } else {
                            if (!solSeq.validateIntegrity(expectedStartFen = diagram.initialFen)) {
                                invalidPgnRefs.add(solRef)
                                errors.add("Solution PGN '$solRef' failed integrity check from diagram '${diagram.diagramId}' initialFen")
                            }
                            if (exercise.handlerType.equals("MATE_IN_ONE", ignoreCase = true)) {
                                if (solSeq.moves.size != 1) {
                                    invalidPgnRefs.add(solRef)
                                    errors.add("MATE_IN_ONE solution PGN '$solRef' must have 1 move, found ${solSeq.moves.size}")
                                }
                                val finalFen = solSeq.fens.lastOrNull()
                                if (finalFen == null || !ChessEngine(finalFen).isCheckmate()) {
                                    invalidPgnRefs.add(solRef)
                                    errors.add("MATE_IN_ONE solution PGN '$solRef' does not end in checkmate")
                                }
                            }
                        }
                    }
                }
            }

            for (diagram in diagrams) {
                val pgnRef = diagram.pgnRef
                if (pgnRef != null) {
                    val seq = allSequences[pgnRef]
                    if (seq == null) {
                        invalidPgnRefs.add(pgnRef)
                        errors.add("Diagram '${diagram.diagramId}' references missing pgnRef '$pgnRef'")
                    } else {
                        val startFen = seq.fens.firstOrNull() ?: ChessEngine.STANDARD_START_FEN
                        if (!seq.validateIntegrity(
                                expectedStartFen = startFen,
                                expectedFinalFen = diagram.initialFen
                            )
                        ) {
                            invalidPgnRefs.add(pgnRef)
                            errors.add("Diagram '${diagram.diagramId}' PGN '$pgnRef' failed replay integrity")
                        }
                    }
                }

                for (solRef in diagram.solutionPgnRefs) {
                    val solSeq = allSequences[solRef]
                    if (solSeq == null) {
                        invalidPgnRefs.add(solRef)
                        errors.add("Diagram '${diagram.diagramId}' references missing solution_pgn_ref '$solRef'")
                    } else if (!solSeq.validateIntegrity(expectedStartFen = diagram.initialFen)) {
                        invalidPgnRefs.add(solRef)
                        errors.add("Diagram '${diagram.diagramId}' solution_pgn_ref '$solRef' failed replay integrity")
                    }
                }
            }

            blockValidation.copy(
                isValid = blockValidation.isValid &&
                    invalidRelativePaths.isEmpty() &&
                    invalidPgnRefs.isEmpty() &&
                    errors.isEmpty(),
                invalidPgnRefs = invalidPgnRefs,
                invalidRelativePaths = invalidRelativePaths,
                errorMessages = errors
            )
        } catch (e: Exception) {
            errors.add(e.message ?: e.javaClass.simpleName)
            ContentValidationResult(
                isValid = false,
                duplicateBlockIds = emptySet(),
                invalidDiagramBlockIds = emptyList(),
                missingSectionSlotIds = emptyList(),
                invalidPgnRefs = invalidPgnRefs,
                invalidRelativePaths = invalidRelativePaths,
                errorMessages = errors
            )
        }
    }

    @JvmOverloads
    fun validateAllReferencesAndReplays(
        chapterId: String = resolveDefaultChapterId(),
        bookId: String = resolveDefaultBookId()
    ): Boolean {
        return validateChapterPack(chapterId = chapterId, bookId = bookId).isValid
    }

    private fun loadDiagramsFromAssets(
        chapterId: String,
        bookId: String
    ): List<DiagramItem> {
        val manifest = getChapterManifest(chapterId = chapterId, bookId = bookId)
        val jsonString = readAssetText(manifest.diagramsFile)
        val root = JSONObject(jsonString)
        val diagramsArray = root.getJSONArray("diagrams")
        val result = mutableListOf<DiagramItem>()

        for (i in 0 until diagramsArray.length()) {
            val obj = diagramsArray.getJSONObject(i)
            val id = obj.getString("diagram_id").trim()
            val page = obj.getInt("pdf_page")
            val section = obj.optString("section", "")
            val bookContext = obj.optString("book_context", "")
            val diagramKind = obj.optString("diagram_kind", "")
            val interaction = obj.optString("recommended_interaction", "")
            val fen = obj.getString("fen").trim()
            val sideToMove = obj.optString("side_to_move", "white")
            val moveHistory = obj.optString("move_history", "")
            val pgnRef = if (obj.isNull("pgn_ref")) null else obj.optString("pgn_ref").takeIf { it.isNotBlank() }

            val solutionRefs = mutableListOf<String>()
            val solutionRefsArray = obj.optJSONArray("solution_pgn_refs")
            if (solutionRefsArray != null) {
                for (s in 0 until solutionRefsArray.length()) {
                    solutionRefs.add(solutionRefsArray.getString(s))
                }
            }

            val highlights = mutableListOf<String>()
            val highlightsArray = obj.optJSONArray("highlight_squares")
            if (highlightsArray != null) {
                for (h in 0 until highlightsArray.length()) {
                    highlights.add(highlightsArray.getString(h))
                }
            }

            val related = mutableListOf<String>()
            val relatedArray = obj.optJSONArray("related_diagram_ids")
            if (relatedArray != null) {
                for (r in 0 until relatedArray.length()) {
                    related.add(relatedArray.getString(r))
                }
            }

            val visualConf = obj.optString("visual_confidence", "high")
            val notes = obj.optString("implementation_notes", "")

            val rawAuditStatus = if (obj.isNull("audit_status")) "" else obj.optString("audit_status", "")
            val rawAuditWarning = when {
                !obj.isNull("audit_warning_fa") && obj.has("audit_warning_fa") ->
                    obj.optString("audit_warning_fa").takeIf { it.isNotBlank() }
                !obj.isNull("audit_warning") && obj.has("audit_warning") ->
                    obj.optString("audit_warning").takeIf { it.isNotBlank() }
                else -> null
            }

            val (auditStatus, auditWarning) = when (rawAuditStatus.trim().uppercase()) {
                "BLOCKED_NEEDS_HUMAN_REVIEW" -> {
                    Pair(
                        AuditStatus.BLOCKED_NEEDS_HUMAN_REVIEW,
                        rawAuditWarning
                            ?: "⚠️ اخطار ممیزی شطرنج: این دیاگرام مسدود شده و نیازمند بازبینی انسانی است."
                    )
                }
                else -> {
                    Pair(AuditStatus.VALID, rawAuditWarning)
                }
            }

            result.add(
                DiagramItem(
                    diagramId = id,
                    pdfPage = page,
                    sectionName = section,
                    bookContext = bookContext,
                    diagramKind = diagramKind,
                    recommendedInteraction = interaction,
                    initialFen = fen,
                    currentFen = fen,
                    sideToMove = sideToMove,
                    moveHistory = moveHistory,
                    pgnRef = pgnRef,
                    solutionPgnRefs = solutionRefs,
                    highlightSquares = highlights,
                    relatedDiagramIds = related,
                    visualConfidence = visualConf,
                    implementationNotes = notes,
                    auditStatus = auditStatus,
                    auditWarning = auditWarning
                )
            )
        }

        return result
    }

    private fun loadSectionsFromAssets(
        chapterId: String,
        bookId: String
    ): List<SectionItem> {
        val manifest = getChapterManifest(chapterId = chapterId, bookId = bookId)
        return manifest.sections.mapIndexed { idx, entry ->
            val sectionJson = JSONObject(readAssetText(entry.contentFile))
            val fileSectionId = sectionJson.getString("sectionId").trim()
            require(fileSectionId == entry.sectionId) {
                "Section ID mismatch in ${entry.contentFile}: expected ${entry.sectionId}, found $fileSectionId"
            }

            val placeholderNoticeFa = sectionJson.optString(
                "placeholderNoticeFa",
                TranslationSlot.DEFAULT_PLACEHOLDER_NOTICE
            )
            val translationStatus = TranslationStatus.fromString(
                sectionJson.optString("translationStatus", "PENDING")
            )
            val blocksArr = sectionJson.optJSONArray("orderedContentBlocks")
                ?: sectionJson.getJSONArray("orderedBlocks")
            val blocks = parseContentBlocksArray(blocksArr, sectionId = entry.sectionId)

            val diagramIds = blocks.mapNotNull { block ->
                when (block) {
                    is SectionContentBlock.DiagramBlock -> block.diagramId
                    is SectionContentBlock.ExerciseBlock -> block.diagramId
                    else -> null
                }
            }

            SectionItem(
                sectionId = entry.sectionId,
                index = idx,
                titleEn = entry.titleEn,
                titleFa = entry.titleFa,
                pdfPages = entry.pdfPages,
                diagramIds = diagramIds,
                translationSlot = TranslationSlot(
                    sectionId = entry.sectionId,
                    orderedContentBlocks = blocks,
                    placeholderNotice = placeholderNoticeFa,
                    translationStatus = translationStatus
                ),
                sectionKind = entry.sectionKind
            )
        }
    }

    fun parseContentBlocksArray(
        blocksArr: JSONArray,
        sectionId: String = ""
    ): List<SectionContentBlock> {
        val blocks = mutableListOf<SectionContentBlock>()
        for (i in 0 until blocksArr.length()) {
            val bObj = blocksArr.getJSONObject(i)
            val type = bObj.getString("type").trim()
            val blockId = bObj.getString("blockId").trim()
            val textFa = if (bObj.isNull("textFa")) null else bObj.optString("textFa").takeIf { it.isNotEmpty() }
            val titleFa = if (bObj.isNull("titleFa")) null else bObj.optString("titleFa").takeIf { it.isNotEmpty() }
            val url = if (bObj.isNull("url")) null else bObj.optString("url").takeIf { it.isNotEmpty() }

            val block = when (type.lowercase()) {
                "paragraph" -> SectionContentBlock.ParagraphBlock(
                    blockId = blockId,
                    textFa = textFa,
                    showPlaceholderWhenEmpty = bObj.optBoolean("showPlaceholderWhenEmpty", true)
                )
                "heading" -> SectionContentBlock.HeadingBlock(
                    blockId = blockId,
                    textFa = textFa,
                    level = bObj.optInt("level", 2),
                    showPlaceholderWhenEmpty = bObj.optBoolean("showPlaceholderWhenEmpty", false)
                )
                "diagram" -> SectionContentBlock.DiagramBlock(
                    blockId = blockId,
                    diagramId = bObj.getString("diagramId").trim()
                )
                "exercise" -> {
                    val diagramId = bObj.getString("diagramId").trim()
                    val exerciseId = bObj.optString(
                        "exerciseId",
                        SectionContentBlock.defaultExerciseIdForDiagram(diagramId)
                    ).trim()
                    SectionContentBlock.ExerciseBlock(
                        blockId = blockId,
                        diagramId = diagramId,
                        exerciseId = exerciseId
                    )
                }
                "footnote" -> SectionContentBlock.FootnoteBlock(
                    blockId = blockId,
                    textFa = textFa,
                    showPlaceholderWhenEmpty = bObj.optBoolean("showPlaceholderWhenEmpty", false)
                )
                "externalreference", "external_reference" -> SectionContentBlock.ExternalReferenceBlock(
                    blockId = blockId,
                    titleFa = titleFa,
                    url = url,
                    isAuthorizedAndEnabled = bObj.optBoolean("isAuthorizedAndEnabled", false)
                )
                else -> throw IllegalArgumentException(
                    "Unsupported content block type '$type' in section '$sectionId' (blockId='$blockId')"
                )
            }
            blocks.add(block)
        }
        return blocks
    }

    private fun loadPgnSequencesFromAssets(
        chapterId: String,
        bookId: String
    ): Map<String, PgnSequence> {
        val manifest = getChapterManifest(chapterId = chapterId, bookId = bookId)
        val jsonString = readAssetText(manifest.pgnFile)
        val root = JSONObject(jsonString)
        val map = mutableMapOf<String, PgnSequence>()
        val keys = root.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val obj = root.optJSONObject(key) ?: continue
            if (!obj.has("moves") || !obj.has("fens")) continue
            val id = obj.optString("id", key)
            val desc = obj.optString("description", "")
            val movesJson = obj.getJSONArray("moves")
            val fensJson = obj.getJSONArray("fens")

            val moves = mutableListOf<String>()
            for (m in 0 until movesJson.length()) {
                moves.add(movesJson.getString(m))
            }

            val fens = mutableListOf<String>()
            for (f in 0 until fensJson.length()) {
                fens.add(fensJson.getString(f))
            }

            map[key] = PgnSequence(id, desc, moves, fens)
        }
        return map
    }

    private fun loadExercisesFromAssets(
        chapterId: String,
        bookId: String
    ): List<ExerciseDefinition> {
        val manifest = getChapterManifest(chapterId = chapterId, bookId = bookId)
        if (manifest.exercisesFile.isBlank()) return emptyList()
        val root = JSONObject(readAssetText(manifest.exercisesFile))
        val fileChapterId = root.optString("chapterId", chapterId).trim()
        require(fileChapterId == chapterId) {
            "Chapter ID mismatch in ${manifest.exercisesFile}: expected $chapterId, found $fileChapterId"
        }
        val arr = root.optJSONArray("exercises") ?: return emptyList()
        val result = mutableListOf<ExerciseDefinition>()
        for (i in 0 until arr.length()) {
            val eObj = arr.getJSONObject(i)
            val refsArr = eObj.optJSONArray("acceptedSolutionIds")
                ?: eObj.getJSONArray("acceptedSolutionPgnRefs")
            val refs = (0 until refsArr.length()).map { refsArr.getString(it) }
            val handlerType = eObj.optString("exerciseType", "").ifBlank {
                eObj.getString("handlerType")
            }.trim()
            val allowHints = if (eObj.has("allowLegalMoveHints")) {
                eObj.optBoolean("allowLegalMoveHints", true)
            } else {
                eObj.optBoolean("showLegalMovesHint", true)
            }
            val initialFen = if (eObj.isNull("initialFen")) null else eObj.optString("initialFen", "").trim().takeIf { it.isNotEmpty() }
            val sideToMove = if (eObj.isNull("sideToMove")) null else eObj.optString("sideToMove", "").trim().takeIf { it.isNotEmpty() }
            val titleFa = if (eObj.isNull("titleFa")) null else eObj.optString("titleFa", "").trim().takeIf { it.isNotEmpty() }
            val promptFa = if (eObj.isNull("promptFa")) null else eObj.optString("promptFa", "").trim().takeIf { it.isNotEmpty() }
            val successFeedbackFa = if (eObj.isNull("successFeedbackFa")) null else eObj.optString("successFeedbackFa", "").trim().takeIf { it.isNotEmpty() }
            val wrongMoveFeedbackFa = if (eObj.isNull("wrongMoveFeedbackFa")) null else eObj.optString("wrongMoveFeedbackFa", "").trim().takeIf { it.isNotEmpty() }
            val illegalMoveFeedbackFa = if (eObj.isNull("illegalMoveFeedbackFa")) null else eObj.optString("illegalMoveFeedbackFa", "").trim().takeIf { it.isNotEmpty() }
            val hintFa = if (eObj.isNull("hintFa")) null else eObj.optString("hintFa", "").trim().takeIf { it.isNotEmpty() }

            result.add(
                ExerciseDefinition(
                    exerciseId = eObj.getString("exerciseId").trim(),
                    diagramId = eObj.getString("diagramId").trim(),
                    handlerType = handlerType,
                    acceptedSolutionPgnRefs = refs,
                    showLegalMovesHint = allowHints,
                    allowLegalMoveHints = allowHints,
                    initialFen = initialFen,
                    sideToMove = sideToMove,
                    titleFa = titleFa,
                    promptFa = promptFa,
                    successFeedbackFa = successFeedbackFa,
                    wrongMoveFeedbackFa = wrongMoveFeedbackFa,
                    illegalMoveFeedbackFa = illegalMoveFeedbackFa,
                    hintFa = hintFa
                )
            )
        }
        return result
    }

    companion object {
        const val DEFAULT_LIBRARY_ASSET_PATH = "books/library.json"
        const val DEFAULT_BOOK_ID = "how_to_win_at_chess"
        const val DEFAULT_CHAPTER_ID = "CH01"
    }
}
