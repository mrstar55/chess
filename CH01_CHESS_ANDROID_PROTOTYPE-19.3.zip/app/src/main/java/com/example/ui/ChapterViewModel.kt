package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.audio.AudioSettingsState
import com.example.audio.BookNarrationManager
import com.example.audio.ChessSoundEvent
import com.example.audio.ChessSoundManager
import com.example.audio.ChessSoundType
import com.example.audio.NarrationPlaybackSpeed
import com.example.audio.NarrationUiState
import com.example.chess.ChessRulesAdapter
import com.example.chess.ExerciseHandlerRegistry
import com.example.chess.PgnReplayer
import com.example.chess.PgnSequence
import com.example.data.ChapterRepository
import com.example.data.EducationalPlaybackSpeed
import com.example.data.FontSizeScale
import com.example.data.UserPreferencesManager
import com.example.model.BoardTransition
import com.example.model.BoardTransitionResolver
import com.example.model.ChapterCatalogEntry
import com.example.model.DiagramItem
import com.example.model.ExerciseDefinition
import com.example.model.ExercisePhase
import com.example.model.ExerciseUiState
import com.example.model.MoveTrailState
import com.example.model.ReaderPage
import com.example.model.ReaderPaginator
import com.example.model.SectionItem
import com.example.model.TranslationSlot
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

@Deprecated(
    message = "Use ExercisePhase from com.example.model instead.",
    replaceWith = ReplaceWith("ExercisePhase", "com.example.model.ExercisePhase")
)
typealias Bd032ExercisePhase = ExercisePhase

@Deprecated(
    message = "Use ExerciseUiState from com.example.model instead.",
    replaceWith = ReplaceWith("ExerciseUiState", "com.example.model.ExerciseUiState")
)
typealias Bd032UiState = ExerciseUiState

data class ChapterUiState(
    val activeBookId: String = "",
    val activeBookTitleFa: String = "",
    val activeChapterId: String = "",
    val activeChapterNumber: Int = 1,
    val activeChapterTitleFa: String = "",
    val activeChapterTitleEn: String = "",
    val availableChapters: List<ChapterCatalogEntry> = emptyList(),
    val sections: List<SectionItem> = emptyList(),
    val diagrams: List<DiagramItem> = emptyList(),
    val currentSectionIndex: Int = 0,
    val currentPages: List<ReaderPage> = emptyList(),
    val currentPageIndex: Int = 0,
    val viewportWidthDp: Int = 380,
    val viewportHeightDp: Int = 640,
    val fontScale: FontSizeScale = FontSizeScale.NORMAL,
    val bookmarks: Set<String> = emptySet(),
    val pgnStates: Map<String, PgnReplayerState> = emptyMap(),
    val exerciseDefinitions: Map<String, ExerciseDefinition> = emptyMap(),
    val exerciseStates: Map<String, ExerciseUiState> = emptyMap(),
    val audioSettings: AudioSettingsState = AudioSettingsState(),
    val narrationState: NarrationUiState = NarrationUiState(),
    val showMoveTrail: Boolean = true,
    val playbackSpeed: EducationalPlaybackSpeed = EducationalPlaybackSpeed.NORMAL,
    val showAudioSettingsDialog: Boolean = false,
    val currentTab: AppTab = AppTab.SPLASH
) {
    val hasMultipleChapters: Boolean
        get() = availableChapters.size > 1

    val activeChapterShortTitleFa: String
        get() = activeChapterTitleFa.substringBefore(":").trim().ifBlank { activeChapterTitleFa }

    val currentPage: ReaderPage?
        get() = currentPages.getOrNull(currentPageIndex)

    fun exerciseStateFor(
        exerciseId: String,
        diagramId: String? = null
    ): ExerciseUiState? {
        exerciseStates[exerciseId]?.let { return it }
        if (diagramId != null) {
            val matchedDef = exerciseDefinitions.values.firstOrNull { it.diagramId == diagramId }
            if (matchedDef != null) {
                exerciseStates[matchedDef.exerciseId]?.let { return it }
            }
        }
        return null
    }

    @Deprecated(
        message = "Legacy test compatibility accessor; active code must use exerciseStates[exerciseId] or exerciseStateFor(exerciseId)."
    )
    val bd032State: ExerciseUiState
        get() = exerciseStates[UserPreferencesManager.DEFAULT_CH01_EXERCISE_ID] ?: ExerciseUiState()
}

enum class AppTab {
    SPLASH,
    INTRODUCTION,
    CHAPTERS_LIST,
    SECTIONS_LIST,
    READER,
    AUDIT_REPORT
}

data class PgnReplayerState(
    val pgnRef: String,
    val currentStep: Int,
    val totalSteps: Int,
    val currentFen: String,
    val currentMoveSan: String?,
    val isAtStart: Boolean,
    val isAtEnd: Boolean,
    val activeTransition: BoardTransition? = null,
    val activeMoveTrail: MoveTrailState? = null,
    val lastMoveDescriptionFa: String? = null,
    val isTransitioning: Boolean = false
) {
    val canGoPrevious: Boolean
        get() = currentStep > 0

    val canGoNext: Boolean
        get() = currentStep < totalSteps
}

class ChapterViewModel @JvmOverloads constructor(
    application: Application,
    customRepository: ChapterRepository? = null
) : AndroidViewModel(application) {

    private val repository = customRepository ?: ChapterRepository(application)
    private val prefs = UserPreferencesManager(application)
    val soundManager = ChessSoundManager(application)
    val narrationManager = BookNarrationManager(application, prefs)

    private val replayers = mutableMapOf<String, PgnReplayer>()
    private val exerciseAdapters = mutableMapOf<String, ChessRulesAdapter>()
    private var loadedPgnSequences: Map<String, PgnSequence> = emptyMap()

    private val transitionCounter = AtomicLong(1L)
    private val soundEventCounter = AtomicLong(1L)

    private val _soundEvents = MutableSharedFlow<ChessSoundEvent>(extraBufferCapacity = 64)
    val soundEvents: SharedFlow<ChessSoundEvent> = _soundEvents.asSharedFlow()

    private val _uiState = MutableStateFlow(ChapterUiState())
    val uiState: StateFlow<ChapterUiState> = _uiState.asStateFlow()

    init {
        narrationManager.setOnStateChangedListener { narrationSt ->
            _uiState.update { it.copy(narrationState = narrationSt) }
        }
        narrationManager.setAutoNavigationCallback { secIdx, blockId ->
            navigateToSectionAndBlockForNarration(secIdx, blockId)
        }
        loadData()
    }

    private fun emitSound(type: ChessSoundType, sourceTag: String = ""): ChessSoundEvent {
        val event = ChessSoundEvent(
            eventId = soundEventCounter.getAndIncrement(),
            soundType = type,
            sourceTag = sourceTag
        )
        soundManager.handleEvent(event, _uiState.value.audioSettings)
        _soundEvents.tryEmit(event)
        return event
    }

    private fun loadData() {
        val (book, initialChapter) = repository.resolveInitialChapterEntry(
            preferredBookId = prefs.getSavedActiveBookIdOrNull(),
            preferredChapterId = prefs.getSavedActiveChapterIdOrNull()
        )
        val chapters = book.enabledChapters

        loadChapterInternal(
            bookId = book.bookId,
            bookTitleFa = book.titleFa,
            chapterEntry = initialChapter,
            availableChapters = chapters,
            targetTab = AppTab.SPLASH
        )
    }

    private fun loadChapterInternal(
        bookId: String,
        bookTitleFa: String,
        chapterEntry: ChapterCatalogEntry,
        availableChapters: List<ChapterCatalogEntry>,
        targetTab: AppTab
    ) {
        val chapterId = chapterEntry.chapterId
        val manifest = repository.getChapterManifest(chapterId = chapterId, bookId = bookId)
        val sections = repository.getSections(chapterId = chapterId, bookId = bookId)
        val diagrams = repository.getDiagrams(chapterId = chapterId, bookId = bookId)
        val pgnSequences = repository.getAllPgnSequences(chapterId = chapterId, bookId = bookId)
        val exercises = repository.getExercises(chapterId = chapterId, bookId = bookId)

        loadedPgnSequences = pgnSequences

        val savedPos = prefs.getSavedReadingPosition(chapterId = chapterId, bookId = bookId)
        val savedSection = if (!savedPos.sectionId.isNullOrBlank()) {
            val byId = sections.indexOfFirst { it.sectionId == savedPos.sectionId }
            if (byId >= 0) byId else savedPos.sectionIndexFallback.coerceIn(0, (sections.size - 1).coerceAtLeast(0))
        } else {
            savedPos.sectionIndexFallback.coerceIn(0, (sections.size - 1).coerceAtLeast(0))
        }

        val fontScale = prefs.fontScale
        val bookmarks = prefs.getBookmarks()
        val audioSettings = prefs.loadAudioSettings()
        val showMoveTrail = prefs.showMoveTrail
        val playbackSpeed = prefs.playbackSpeed
        val vpWidth = _uiState.value.viewportWidthDp
        val vpHeight = _uiState.value.viewportHeightDp

        val initialPages = sections.getOrNull(savedSection)?.let { section ->
            ReaderPaginator.paginateSection(
                section = section,
                diagrams = diagrams,
                fontScale = fontScale,
                viewportWidthDp = vpWidth,
                viewportHeightDp = vpHeight
            )
        } ?: emptyList()

        val savedPage = if (!savedPos.pageId.isNullOrBlank()) {
            val byPageId = initialPages.indexOfFirst { it.pageId == savedPos.pageId }
            if (byPageId >= 0) byPageId else savedPos.pageIndex.coerceIn(0, (initialPages.size - 1).coerceAtLeast(0))
        } else {
            savedPos.pageIndex.coerceIn(0, (initialPages.size - 1).coerceAtLeast(0))
        }

        replayers.clear()
        val pgnStatesMap = mutableMapOf<String, PgnReplayerState>()
        diagrams.forEach { diagram ->
            diagram.pgnRef?.let { pgnRef ->
                val seq = pgnSequences[pgnRef]
                if (seq != null) {
                    val replayer = PgnReplayer(seq)
                    replayer.jumpToEnd()
                    replayers[pgnRef] = replayer
                    pgnStatesMap[pgnRef] = PgnReplayerState(
                        pgnRef = pgnRef,
                        currentStep = replayer.currentStep,
                        totalSteps = seq.totalSteps,
                        currentFen = replayer.currentFen,
                        currentMoveSan = replayer.currentMoveSan,
                        isAtStart = replayer.isAtStart,
                        isAtEnd = replayer.isAtEnd,
                        activeTransition = null,
                        activeMoveTrail = null,
                        lastMoveDescriptionFa = null,
                        isTransitioning = false
                    )
                }
            }
        }

        val diagramsById = diagrams.associateBy { it.diagramId }
        exerciseAdapters.clear()
        val exerciseDefsMap = linkedMapOf<String, ExerciseDefinition>()
        val exerciseStatesMap = linkedMapOf<String, ExerciseUiState>()

        for (exDef in exercises) {
            exerciseDefsMap[exDef.exerciseId] = exDef
            val diag = diagramsById[exDef.diagramId] ?: continue
            val handler = ExerciseHandlerRegistry.getHandler(exDef.handlerType) ?: continue
            val adapter = handler.createRulesAdapter(exDef, diag)
            exerciseAdapters[exDef.exerciseId] = adapter
            val solved = prefs.isExerciseSolved(exDef.exerciseId)
            exerciseStatesMap[exDef.exerciseId] = handler.createInitialState(exDef, diag, solved)
        }

        narrationManager.switchChapterManifest(
            chapterId = chapterId,
            manifestAssetPath = manifest.narrationManifest,
            sections = sections,
            currentPage = initialPages.getOrNull(savedPage),
            bookId = bookId,
            assetReaderOverride = repository.assetReaderOverride
        )

        _uiState.update {
            it.copy(
                activeBookId = bookId,
                activeBookTitleFa = bookTitleFa,
                activeChapterId = chapterId,
                activeChapterNumber = manifest.chapterNumber,
                activeChapterTitleFa = manifest.titleFa.ifBlank { chapterEntry.titleFa },
                activeChapterTitleEn = manifest.titleEn.ifBlank { chapterEntry.titleEn },
                availableChapters = availableChapters,
                sections = sections,
                diagrams = diagrams,
                currentSectionIndex = savedSection,
                currentPages = initialPages,
                currentPageIndex = savedPage,
                fontScale = fontScale,
                bookmarks = bookmarks,
                audioSettings = audioSettings,
                showMoveTrail = showMoveTrail,
                playbackSpeed = playbackSpeed,
                pgnStates = pgnStatesMap,
                exerciseDefinitions = exerciseDefsMap,
                exerciseStates = exerciseStatesMap,
                narrationState = narrationManager.state.value,
                currentTab = targetTab
            )
        }
    }

    private fun saveCurrentReadingPosition(
        state: ChapterUiState,
        sectionIndex: Int,
        pageIndex: Int,
        pages: List<ReaderPage>
    ) {
        val safeSecIdx = sectionIndex.coerceIn(0, (state.sections.size - 1).coerceAtLeast(0))
        val safePageIdx = pageIndex.coerceIn(0, (pages.size - 1).coerceAtLeast(0))
        val secId = state.sections.getOrNull(safeSecIdx)?.sectionId
        val pageId = pages.getOrNull(safePageIdx)?.pageId
        if (!secId.isNullOrBlank()) {
            prefs.saveReadingPosition(
                bookId = state.activeBookId,
                chapterId = state.activeChapterId,
                sectionId = secId,
                sectionIndex = safeSecIdx,
                pageIndex = safePageIdx,
                pageId = pageId
            )
        } else {
            prefs.saveReadingPosition(sectionIndex = safeSecIdx, pageIndex = safePageIdx)
        }
    }

    /**
     * Enters a section and always opens its first page (page index 0).
     */
    fun selectSection(index: Int) {
        val stateSnapshot = _uiState.value
        val target = index.coerceIn(0, (stateSnapshot.sections.size - 1).coerceAtLeast(0))
        _uiState.update { state ->
            val targetSection = state.sections.getOrNull(target)
            val pages = if (targetSection != null) {
                ReaderPaginator.paginateSection(
                    section = targetSection,
                    diagrams = state.diagrams,
                    fontScale = state.fontScale,
                    viewportWidthDp = state.viewportWidthDp,
                    viewportHeightDp = state.viewportHeightDp
                )
            } else {
                emptyList()
            }
            saveCurrentReadingPosition(state, target, 0, pages)
            // Clear any transient animations, move trails, and persistent move descriptions when switching sections
            val clearedPgnStates = state.pgnStates.mapValues { (_, pgn) ->
                pgn.copy(
                    activeTransition = null,
                    activeMoveTrail = null,
                    lastMoveDescriptionFa = null,
                    isTransitioning = false
                )
            }
            val clearedExStates = state.exerciseStates.mapValues { (_, ex) ->
                ex.copy(
                    activeTransition = null,
                    activeMoveTrail = null,
                    lastMoveDescriptionFa = null
                )
            }
            state.copy(
                currentSectionIndex = target,
                currentPages = pages,
                currentPageIndex = 0,
                currentTab = AppTab.READER,
                pgnStates = clearedPgnStates,
                exerciseStates = clearedExStates
            )
        }
        val updated = _uiState.value
        narrationManager.onManualPageOrSectionChanged(updated.sections, updated.currentPage)
    }

    /**
     * Resumes reading at the last saved section and saved page index without resetting to page 0.
     */
    fun resumeReading() {
        _uiState.update { state ->
            val targetSectionIdx = state.currentSectionIndex.coerceIn(0, (state.sections.size - 1).coerceAtLeast(0))
            val targetSection = state.sections.getOrNull(targetSectionIdx)
            val pages = state.currentPages.ifEmpty {
                if (targetSection != null) {
                    ReaderPaginator.paginateSection(
                        section = targetSection,
                        diagrams = state.diagrams,
                        fontScale = state.fontScale,
                        viewportWidthDp = state.viewportWidthDp,
                        viewportHeightDp = state.viewportHeightDp
                    )
                } else {
                    emptyList()
                }
            }
            val savedPageIdx = state.currentPageIndex.coerceIn(0, (pages.size - 1).coerceAtLeast(0))
            saveCurrentReadingPosition(state, targetSectionIdx, savedPageIdx, pages)
            val clearedPgnStates = state.pgnStates.mapValues { (_, pgn) ->
                pgn.copy(
                    activeTransition = null,
                    activeMoveTrail = null,
                    lastMoveDescriptionFa = null,
                    isTransitioning = false
                )
            }
            val clearedExStates = state.exerciseStates.mapValues { (_, ex) ->
                ex.copy(
                    activeTransition = null,
                    activeMoveTrail = null,
                    lastMoveDescriptionFa = null
                )
            }
            state.copy(
                currentSectionIndex = targetSectionIdx,
                currentPages = pages,
                currentPageIndex = savedPageIdx,
                currentTab = AppTab.READER,
                pgnStates = clearedPgnStates,
                exerciseStates = clearedExStates
            )
        }
        val updated = _uiState.value
        narrationManager.refreshAvailability(updated.sections, updated.currentPage)
    }

    fun nextSection() {
        if (_uiState.value.currentSectionIndex < _uiState.value.sections.size - 1) {
            selectSection(_uiState.value.currentSectionIndex + 1)
        }
    }

    fun prevSection() {
        if (_uiState.value.currentSectionIndex > 0) {
            selectSection(_uiState.value.currentSectionIndex - 1)
        }
    }

    /**
     * Navigates to a specific 0-based page index within the current section and persists the reading position.
     */
    fun goToPage(pageIndex: Int) {
        val currentState = _uiState.value
        val maxIdx = (currentState.currentPages.size - 1).coerceAtLeast(0)
        val targetPage = pageIndex.coerceIn(0, maxIdx)
        val pageChanged = targetPage != currentState.currentPageIndex
        saveCurrentReadingPosition(currentState, currentState.currentSectionIndex, targetPage, currentState.currentPages)
        _uiState.update { state ->
            val updatedPgnStates = if (pageChanged) {
                state.pgnStates.mapValues { (_, pgn) ->
                    pgn.copy(
                        activeTransition = null,
                        activeMoveTrail = null,
                        lastMoveDescriptionFa = null,
                        isTransitioning = false
                    )
                }
            } else {
                state.pgnStates
            }
            val updatedExStates = if (pageChanged) {
                state.exerciseStates.mapValues { (_, ex) ->
                    ex.copy(
                        activeTransition = null,
                        activeMoveTrail = null,
                        lastMoveDescriptionFa = null
                    )
                }
            } else {
                state.exerciseStates
            }
            state.copy(
                currentPageIndex = targetPage,
                pgnStates = updatedPgnStates,
                exerciseStates = updatedExStates
            )
        }
        if (pageChanged) {
            val updated = _uiState.value
            narrationManager.onManualPageOrSectionChanged(updated.sections, updated.currentPage)
        }
    }

    /**
     * Auto-navigates to the page containing [blockId] inside [sectionIndex] during Mode B
     * (Continuous Chapter narration) without interrupting active narration playback.
     */
    private fun navigateToSectionAndBlockForNarration(sectionIndex: Int, blockId: String) {
        val normalizedBlockId = ReaderPaginator.originalBlockId(blockId)
        _uiState.update { state ->
            val targetSecIdx = sectionIndex.coerceIn(0, (state.sections.size - 1).coerceAtLeast(0))
            val targetSection = state.sections.getOrNull(targetSecIdx) ?: return@update state
            val pages = if (targetSecIdx == state.currentSectionIndex && state.currentPages.isNotEmpty()) {
                state.currentPages
            } else {
                ReaderPaginator.paginateSection(
                    section = targetSection,
                    diagrams = state.diagrams,
                    fontScale = state.fontScale,
                    viewportWidthDp = state.viewportWidthDp,
                    viewportHeightDp = state.viewportHeightDp
                )
            }
            val pageIdx = pages.indexOfFirst { page ->
                page.orderedBlocks.any { ReaderPaginator.originalBlockId(it.blockId) == normalizedBlockId }
            }.coerceAtLeast(0)
            saveCurrentReadingPosition(state, targetSecIdx, pageIdx, pages)
            state.copy(
                currentSectionIndex = targetSecIdx,
                currentPages = pages,
                currentPageIndex = pageIdx
            )
        }
    }

    fun nextPage(): Boolean {
        val state = _uiState.value
        if (state.currentPageIndex < state.currentPages.size - 1) {
            goToPage(state.currentPageIndex + 1)
            return true
        }
        return false
    }

    fun prevPage(): Boolean {
        val state = _uiState.value
        if (state.currentPageIndex > 0) {
            goToPage(state.currentPageIndex - 1)
            return true
        }
        return false
    }

    fun setTab(tab: AppTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun openIntroduction() {
        _uiState.update { it.copy(currentTab = AppTab.INTRODUCTION) }
    }

    fun openBookFromIntroduction() {
        val s = _uiState.value
        if (s.hasMultipleChapters) {
            _uiState.update { it.copy(currentTab = AppTab.CHAPTERS_LIST) }
        } else {
            openSectionsList()
        }
    }

    fun openChaptersList() {
        narrationManager.stop()
        _uiState.update { it.copy(currentTab = AppTab.CHAPTERS_LIST) }
    }

    fun openSectionsList() {
        _uiState.update { it.copy(currentTab = AppTab.SECTIONS_LIST) }
    }

    fun selectChapter(chapterId: String, navigateToSectionsList: Boolean = true) {
        val s = _uiState.value
        val chapterEntry = s.availableChapters.find { it.chapterId == chapterId } ?: return
        prefs.activeBookId = s.activeBookId
        prefs.activeChapterId = chapterId
        loadChapterInternal(
            bookId = s.activeBookId,
            bookTitleFa = s.activeBookTitleFa,
            chapterEntry = chapterEntry,
            availableChapters = s.availableChapters,
            targetTab = if (navigateToSectionsList) AppTab.SECTIONS_LIST else s.currentTab
        )
    }

    private fun findPreservedPageIndex(
        oldPages: List<ReaderPage>,
        oldPageIndex: Int,
        newPages: List<ReaderPage>
    ): Int {
        if (newPages.isEmpty()) return 0
        val oldPage = oldPages.getOrNull(oldPageIndex)
            ?: return oldPageIndex.coerceIn(0, newPages.lastIndex)

        // 1. If the user was on a page with a primary diagram, keep them on the page with that diagram
        val diagramId = oldPage.primaryDiagramId
        if (diagramId != null) {
            val diagramMatch = newPages.indexOfFirst { it.primaryDiagramId == diagramId }
            if (diagramMatch >= 0) return diagramMatch
        }

        // 2. Match the first content block on the page (preferring non-heading content if a heading precedes a paragraph)
        val anchorBlock = oldPage.orderedBlocks.firstOrNull {
            it !is com.example.model.SectionContentBlock.HeadingBlock
        } ?: oldPage.orderedBlocks.firstOrNull()

        if (anchorBlock != null) {
            val exactId = anchorBlock.blockId
            val origId = ReaderPaginator.originalBlockId(exactId)

            val oldPagesWithOrig = oldPages.indices.filter { idx ->
                oldPages[idx].orderedBlocks.any { ReaderPaginator.originalBlockId(it.blockId) == origId }
            }
            val newPagesWithOrig = newPages.indices.filter { idx ->
                newPages[idx].orderedBlocks.any { ReaderPaginator.originalBlockId(it.blockId) == origId }
            }

            if (newPagesWithOrig.isNotEmpty()) {
                if (oldPagesWithOrig.size > 1 && newPagesWithOrig.size > 1) {
                    val posInOldGroup = oldPagesWithOrig.indexOf(oldPageIndex).coerceAtLeast(0)
                    val fraction = posInOldGroup.toFloat() / (oldPagesWithOrig.size - 1).coerceAtLeast(1).toFloat()
                    val targetInNewGroup = kotlin.math.round(fraction * (newPagesWithOrig.size - 1)).toInt()
                        .coerceIn(0, newPagesWithOrig.lastIndex)
                    return newPagesWithOrig[targetInNewGroup]
                }
                val exactMatch = newPages.indexOfFirst { page ->
                    page.orderedBlocks.any { it.blockId == exactId }
                }
                if (exactMatch >= 0) return exactMatch
                return newPagesWithOrig.first()
            }
        }

        return oldPageIndex.coerceIn(0, newPages.lastIndex)
    }

    fun setFontScale(scale: FontSizeScale) {
        prefs.fontScale = scale
        _uiState.update { state ->
            val currentSection = state.sections.getOrNull(state.currentSectionIndex)
            val newPages = if (currentSection != null) {
                ReaderPaginator.paginateSection(
                    section = currentSection,
                    diagrams = state.diagrams,
                    fontScale = scale,
                    viewportWidthDp = state.viewportWidthDp,
                    viewportHeightDp = state.viewportHeightDp
                )
            } else {
                state.currentPages
            }
            val mappedPageIndex = findPreservedPageIndex(
                oldPages = state.currentPages,
                oldPageIndex = state.currentPageIndex,
                newPages = newPages
            )
            saveCurrentReadingPosition(state, state.currentSectionIndex, mappedPageIndex, newPages)
            state.copy(
                fontScale = scale,
                currentPages = newPages,
                currentPageIndex = mappedPageIndex
            )
        }
        val updated = _uiState.value
        narrationManager.refreshAvailability(updated.sections, updated.currentPage)
    }

    fun updateViewportSize(widthDp: Int, heightDp: Int) {
        val clampedWidth = widthDp.coerceAtLeast(200)
        val clampedHeight = heightDp.coerceAtLeast(200)
        val current = _uiState.value
        if (current.viewportWidthDp == clampedWidth && current.viewportHeightDp == clampedHeight) return
        _uiState.update { state ->
            val currentSection = state.sections.getOrNull(state.currentSectionIndex)
            val newPages = if (currentSection != null) {
                ReaderPaginator.paginateSection(
                    section = currentSection,
                    diagrams = state.diagrams,
                    fontScale = state.fontScale,
                    viewportWidthDp = clampedWidth,
                    viewportHeightDp = clampedHeight
                )
            } else {
                state.currentPages
            }
            val mappedPageIndex = findPreservedPageIndex(
                oldPages = state.currentPages,
                oldPageIndex = state.currentPageIndex,
                newPages = newPages
            )
            saveCurrentReadingPosition(state, state.currentSectionIndex, mappedPageIndex, newPages)
            state.copy(
                viewportWidthDp = clampedWidth,
                viewportHeightDp = clampedHeight,
                currentPages = newPages,
                currentPageIndex = mappedPageIndex
            )
        }
    }

    fun toggleBookmark(diagramId: String) {
        prefs.toggleBookmark(diagramId)
        _uiState.update { it.copy(bookmarks = prefs.getBookmarks()) }
    }

    fun updateSectionTranslationSlot(sectionId: String, updatedSlot: TranslationSlot) {
        _uiState.update { state ->
            val updatedSections = state.sections.map { sec ->
                if (sec.sectionId == sectionId) {
                    sec.copy(translationSlot = updatedSlot)
                } else {
                    sec
                }
            }
            val activeSection = updatedSections.getOrNull(state.currentSectionIndex)
            val newPages = if (activeSection != null) {
                ReaderPaginator.paginateSection(
                    section = activeSection,
                    diagrams = state.diagrams,
                    fontScale = state.fontScale,
                    viewportWidthDp = state.viewportWidthDp,
                    viewportHeightDp = state.viewportHeightDp
                )
            } else {
                state.currentPages
            }
            val clampedPageIdx = state.currentPageIndex.coerceIn(0, (newPages.size - 1).coerceAtLeast(0))
            state.copy(
                sections = updatedSections,
                currentPages = newPages,
                currentPageIndex = clampedPageIdx
            )
        }
        val updated = _uiState.value
        narrationManager.refreshAvailability(updated.sections, updated.currentPage)
    }

    fun stepPgnNext(pgnRef: String) {
        val replayer = replayers[pgnRef] ?: return
        val fromFen = replayer.currentFen
        if (replayer.next()) {
            val toFen = replayer.currentFen
            val transitionId = "pgn_${pgnRef}_next_${replayer.currentStep}_${transitionCounter.getAndIncrement()}"
            val transition = BoardTransitionResolver.resolveForwardTransition(
                transitionId = transitionId,
                fromFen = fromFen,
                toFen = toFen
            )
            val moveTrail = if (transition != null && _uiState.value.showMoveTrail) {
                BoardTransitionResolver.createMoveTrail(transition, _uiState.value.playbackSpeed)
            } else {
                null
            }
            val moveDescriptionFa = BoardTransitionResolver.buildPersistentMoveDescriptionFa(transition)
            updatePgnState(
                pgnRef = pgnRef,
                replayer = replayer,
                transition = transition,
                moveTrail = moveTrail,
                lastMoveDescriptionFa = moveDescriptionFa
            )
            if (transition != null) {
                val soundType = ChessSoundManager.resolveSoundForTransition(transition)
                emitSound(soundType, "pgn_next_$pgnRef")
            }
        }
    }

    fun stepPgnPrev(pgnRef: String) {
        val replayer = replayers[pgnRef] ?: return
        val fromFen = replayer.currentFen
        if (replayer.previous()) {
            val toFen = replayer.currentFen
            val transitionId = "pgn_${pgnRef}_prev_${replayer.currentStep}_${transitionCounter.getAndIncrement()}"
            val transition = BoardTransitionResolver.resolveReverseTransition(
                transitionId = transitionId,
                currentFen = fromFen,
                previousFen = toFen
            )
            updatePgnState(
                pgnRef = pgnRef,
                replayer = replayer,
                transition = transition,
                moveTrail = null,
                lastMoveDescriptionFa = null
            )
            if (transition != null) {
                val soundType = ChessSoundManager.resolveSoundForTransition(transition)
                emitSound(soundType, "pgn_prev_$pgnRef")
            }
        }
    }

    fun resetPgn(pgnRef: String) {
        val replayer = replayers[pgnRef] ?: return
        replayer.reset()
        updatePgnState(
            pgnRef = pgnRef,
            replayer = replayer,
            transition = null,
            moveTrail = null,
            lastMoveDescriptionFa = null
        )
    }

    fun jumpPgnToEnd(pgnRef: String) {
        val replayer = replayers[pgnRef] ?: return
        replayer.jumpToEnd()
        updatePgnState(
            pgnRef = pgnRef,
            replayer = replayer,
            transition = null,
            moveTrail = null,
            lastMoveDescriptionFa = null
        )
    }

    fun onPgnTransitionFinished(pgnRef: String, transitionId: String) {
        _uiState.update { state ->
            val current = state.pgnStates[pgnRef] ?: return@update state
            if (current.activeTransition?.transitionId != transitionId) return@update state
            val updatedMap = state.pgnStates.toMutableMap()
            updatedMap[pgnRef] = current.copy(
                activeTransition = null,
                isTransitioning = false
            )
            state.copy(pgnStates = updatedMap)
        }
    }

    fun onPgnMoveTrailFinished(pgnRef: String, eventId: String) {
        _uiState.update { state ->
            val current = state.pgnStates[pgnRef] ?: return@update state
            if (current.activeMoveTrail?.eventId != eventId) return@update state
            val updatedMap = state.pgnStates.toMutableMap()
            updatedMap[pgnRef] = current.copy(
                activeMoveTrail = null
            )
            state.copy(pgnStates = updatedMap)
        }
    }

    private fun updatePgnState(
        pgnRef: String,
        replayer: PgnReplayer,
        transition: BoardTransition?,
        moveTrail: MoveTrailState? = null,
        lastMoveDescriptionFa: String? = null
    ) {
        _uiState.update { state ->
            val updatedMap = state.pgnStates.toMutableMap()
            updatedMap[pgnRef] = PgnReplayerState(
                pgnRef = pgnRef,
                currentStep = replayer.currentStep,
                totalSteps = replayer.sequence.totalSteps,
                currentFen = replayer.currentFen,
                currentMoveSan = replayer.currentMoveSan,
                isAtStart = replayer.isAtStart,
                isAtEnd = replayer.isAtEnd,
                activeTransition = transition,
                activeMoveTrail = moveTrail,
                lastMoveDescriptionFa = lastMoveDescriptionFa,
                isTransitioning = transition != null
            )
            state.copy(pgnStates = updatedMap)
        }
    }

    // ==========================================
    // Book Narration Controls (Independent of ChessSoundManager)
    // ==========================================

    fun playCurrentPageNarration(): Boolean {
        val st = _uiState.value
        val page = st.currentPage ?: return false
        return narrationManager.playCurrentPage(
            sections = st.sections,
            sectionIndex = st.currentSectionIndex,
            page = page
        )
    }

    fun playChapterNarration(fromCurrentSection: Boolean = true): Boolean {
        val st = _uiState.value
        val startIdx = if (fromCurrentSection) st.currentSectionIndex else 0
        return narrationManager.playContinuousChapter(
            sections = st.sections,
            startSectionIndex = startIdx,
            startBlockId = null,
            startPositionMs = 0
        )
    }

    fun pauseNarration() {
        narrationManager.pause()
    }

    fun resumeNarration(): Boolean {
        return narrationManager.resume(_uiState.value.sections)
    }

    fun stopNarration() {
        narrationManager.stop()
    }

    fun seekNarrationTo(positionMs: Int) {
        narrationManager.seekTo(positionMs)
    }

    fun setNarrationSpeed(speed: NarrationPlaybackSpeed) {
        narrationManager.setSpeed(speed)
    }

    fun cycleNarrationSpeed(): NarrationPlaybackSpeed {
        return narrationManager.cycleSpeed()
    }

    fun setNarrationVolumePercent(volumePercent: Int) {
        narrationManager.setVolumePercent(volumePercent)
    }

    fun setNarrationEnabled(enabled: Boolean) {
        narrationManager.setNarrationEnabled(enabled)
        val st = _uiState.value
        narrationManager.refreshAvailability(st.sections, st.currentPage)
    }

    // ==========================================
    // Audio Settings & Educational Visual Settings
    // ==========================================

    fun openAudioSettings() {
        _uiState.update { it.copy(showAudioSettingsDialog = true) }
    }

    fun closeAudioSettings() {
        _uiState.update { it.copy(showAudioSettingsDialog = false) }
    }

    private fun updateAudioSettings(transform: (AudioSettingsState) -> AudioSettingsState) {
        val updated = transform(_uiState.value.audioSettings)
        prefs.saveAudioSettings(updated)
        _uiState.update { it.copy(audioSettings = updated) }
    }

    fun setMasterSoundEnabled(enabled: Boolean) {
        updateAudioSettings { it.copy(soundEnabled = enabled) }
    }

    fun setSoundVolumePercent(volumePercent: Int) {
        updateAudioSettings { it.copy(volumePercent = volumePercent.coerceIn(0, 100)) }
    }

    fun setMoveSoundEnabled(enabled: Boolean) {
        updateAudioSettings { it.copy(moveSoundEnabled = enabled) }
    }

    fun setCaptureSoundEnabled(enabled: Boolean) {
        updateAudioSettings { it.copy(captureSoundEnabled = enabled) }
    }

    fun setSpecialMoveSoundEnabled(enabled: Boolean) {
        updateAudioSettings { it.copy(specialMoveSoundEnabled = enabled) }
    }

    fun setCheckMateSoundEnabled(enabled: Boolean) {
        updateAudioSettings { it.copy(checkMateSoundEnabled = enabled) }
    }

    fun setExerciseFeedbackSoundEnabled(enabled: Boolean) {
        updateAudioSettings { it.copy(exerciseFeedbackSoundEnabled = enabled) }
    }

    fun setShowMoveTrail(enabled: Boolean) {
        prefs.showMoveTrail = enabled
        _uiState.update { state ->
            val updatedPgn = if (!enabled) {
                state.pgnStates.mapValues { (_, pgn) -> pgn.copy(activeMoveTrail = null) }
            } else {
                state.pgnStates
            }
            val updatedEx = if (!enabled) {
                state.exerciseStates.mapValues { (_, ex) -> ex.copy(activeMoveTrail = null) }
            } else {
                state.exerciseStates
            }
            state.copy(
                showMoveTrail = enabled,
                pgnStates = updatedPgn,
                exerciseStates = updatedEx
            )
        }
    }

    fun setPlaybackSpeed(speed: EducationalPlaybackSpeed) {
        prefs.playbackSpeed = speed
        _uiState.update { it.copy(playbackSpeed = speed) }
    }

    fun playTestSound() {
        emitSound(ChessSoundType.MOVE_NORMAL, "audio_test_btn")
    }

    // ==========================================
    // Generalized Exercise Engine Dispatch
    // ==========================================

    private fun resolveExerciseContext(
        state: ChapterUiState,
        exerciseId: String
    ): Triple<ExerciseDefinition, DiagramItem, ExerciseUiState>? {
        val exDef = state.exerciseDefinitions[exerciseId] ?: return null
        val diagram = state.diagrams.find { it.diagramId == exDef.diagramId } ?: return null
        val currentExState = state.exerciseStates[exerciseId] ?: return null
        return Triple(exDef, diagram, currentExState)
    }

    private fun applyExerciseStateUpdate(exerciseId: String, updatedExState: ExerciseUiState) {
        _uiState.update { state ->
            val updatedMap = state.exerciseStates + (exerciseId to updatedExState)
            state.copy(exerciseStates = updatedMap)
        }
    }

    fun toggleExerciseLegalMovesHint(exerciseId: String) {
        val current = _uiState.value
        val (exDef, _, exState) = resolveExerciseContext(current, exerciseId) ?: return
        val handler = ExerciseHandlerRegistry.getHandler(exDef.handlerType) ?: return
        val updated = handler.onToggleLegalMovesHint(exState)
        applyExerciseStateUpdate(exerciseId, updated)
    }

    fun onExerciseSquareClicked(exerciseId: String, file: Int, rank: Int) {
        val current = _uiState.value
        val (exDef, diagram, exState) = resolveExerciseContext(current, exerciseId) ?: return
        val handler = ExerciseHandlerRegistry.getHandler(exDef.handlerType) ?: return
        val adapter = exerciseAdapters.getOrPut(exerciseId) {
            handler.createRulesAdapter(exDef, diagram)
        }
        val outcome = handler.onSquareClicked(
            definition = exDef,
            diagram = diagram,
            pgnSequences = loadedPgnSequences,
            currentState = exState,
            adapter = adapter,
            file = file,
            rank = rank,
            showMoveTrail = current.showMoveTrail,
            playbackSpeed = current.playbackSpeed,
            nextTransitionNumber = { transitionCounter.getAndIncrement() }
        )
        if (outcome.newlySolved) {
            prefs.setExerciseSolved(exerciseId, true)
        }
        applyExerciseStateUpdate(exerciseId, outcome.updatedState)
        outcome.soundToEmit?.let { (type, tag) -> emitSound(type, tag) }
    }

    fun onExerciseTransitionFinished(exerciseId: String, transitionId: String) {
        val current = _uiState.value
        val (exDef, _, exState) = resolveExerciseContext(current, exerciseId) ?: return
        val handler = ExerciseHandlerRegistry.getHandler(exDef.handlerType) ?: return
        val outcome = handler.onTransitionFinished(exDef, exState, transitionId)
        applyExerciseStateUpdate(exerciseId, outcome.updatedState)
        outcome.soundToEmit?.let { (type, tag) -> emitSound(type, tag) }
    }

    fun onExerciseMoveTrailFinished(exerciseId: String, eventId: String) {
        val current = _uiState.value
        val (exDef, _, exState) = resolveExerciseContext(current, exerciseId) ?: return
        val handler = ExerciseHandlerRegistry.getHandler(exDef.handlerType) ?: return
        val updated = handler.onMoveTrailFinished(exState, eventId)
        applyExerciseStateUpdate(exerciseId, updated)
    }

    fun retryExercise(exerciseId: String) {
        val current = _uiState.value
        val (exDef, diagram, _) = resolveExerciseContext(current, exerciseId) ?: return
        val handler = ExerciseHandlerRegistry.getHandler(exDef.handlerType) ?: return
        val adapter = exerciseAdapters.getOrPut(exerciseId) {
            handler.createRulesAdapter(exDef, diagram)
        }
        val outcome = handler.onRetry(exDef, diagram, adapter)
        applyExerciseStateUpdate(exerciseId, outcome.updatedState)
        outcome.soundToEmit?.let { (type, tag) -> emitSound(type, tag) }
    }

    fun resetExercise(exerciseId: String) {
        val current = _uiState.value
        val (exDef, diagram, _) = resolveExerciseContext(current, exerciseId) ?: return
        val handler = ExerciseHandlerRegistry.getHandler(exDef.handlerType) ?: return
        val adapter = exerciseAdapters.getOrPut(exerciseId) {
            handler.createRulesAdapter(exDef, diagram)
        }
        val outcome = handler.onReset(exDef, diagram, adapter)
        if (outcome.resetSolvedPreference) {
            prefs.setExerciseSolved(exerciseId, false)
        }
        applyExerciseStateUpdate(exerciseId, outcome.updatedState)
        outcome.soundToEmit?.let { (type, tag) -> emitSound(type, tag) }
    }

    // --- Legacy BD-032 Exercise Wrappers (for backward test compatibility only) ---

    @Deprecated("Use toggleExerciseLegalMovesHint(exerciseId) instead")
    fun toggleBd032LegalMovesHint() {
        toggleExerciseLegalMovesHint(UserPreferencesManager.DEFAULT_CH01_EXERCISE_ID)
    }

    @Deprecated("Use onExerciseSquareClicked(exerciseId, file, rank) instead")
    fun onBd032SquareClicked(file: Int, rank: Int) {
        onExerciseSquareClicked(UserPreferencesManager.DEFAULT_CH01_EXERCISE_ID, file, rank)
    }

    @Deprecated("Use onExerciseTransitionFinished(exerciseId, transitionId) instead")
    fun onBd032TransitionFinished(transitionId: String) {
        onExerciseTransitionFinished(UserPreferencesManager.DEFAULT_CH01_EXERCISE_ID, transitionId)
    }

    @Deprecated("Use onExerciseMoveTrailFinished(exerciseId, eventId) instead")
    fun onBd032MoveTrailFinished(eventId: String) {
        onExerciseMoveTrailFinished(UserPreferencesManager.DEFAULT_CH01_EXERCISE_ID, eventId)
    }

    @Deprecated("Use retryExercise(exerciseId) instead")
    fun retryBd032() {
        retryExercise(UserPreferencesManager.DEFAULT_CH01_EXERCISE_ID)
    }

    @Deprecated("Use resetExercise(exerciseId) instead")
    fun resetBd032() {
        resetExercise(UserPreferencesManager.DEFAULT_CH01_EXERCISE_ID)
    }

    public override fun onCleared() {
        super.onCleared()
        soundManager.release()
        narrationManager.release()
    }
}
