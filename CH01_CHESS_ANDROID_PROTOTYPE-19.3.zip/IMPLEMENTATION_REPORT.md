# گزارش فنی پیاده‌سازی نسخه 19.3 (`CH01_CHESS_ANDROID_PROTOTYPE-19.3.zip`)

## ۱. مشخصات بسته ورودی و خروجی

| ویژگی | مقدار |
|---|---|
| **فایل ورودی (مبنا)** | `CH01_CHESS_ANDROID_PROTOTYPE-19.2.zip` |
| **SHA-256 فایل ورودی** | `5f657bf7308fad5fdcb338a577d253ed6f7d435902e4f94e69ff3fd5e3705cc0` |
| **حجم فایل ورودی** | `4,253,848` بایت (`4.06 MiB`) |
| **فایل خروجی نهایی** | `CH01_CHESS_ANDROID_PROTOTYPE-19.3.zip` |

---

## ۲. خلاصه اصلاحات انجام‌شده در نسخه 19.3

این مرحله صرفاً برای اصلاح دو مورد مشخص‌شده (۱. یکسان‌سازی مسیر واقعی فایل صوتی در Gradle و Android Runtime بر مبنای `app/src/main/assets/narration/` و ۲. تفکیک دقیق اعتبارسنجی ساختاری JSON Schema از اعتبارسنجی معنایی در تست و گزارش) انجام شده است. هیچ‌یک از بخش‌های `ExerciseEngine`، `ExerciseHandler`، `ExerciseUiState`، `ChapterRepository`، `ChapterViewModel`، `ReaderScreen`، منابع آیکون رسمی اسب شطرنج، تصاویر Splash/Introduction، منطق تخته و ۱۱ فایل صوتی `.wav` شطرنج تغییر نکرده‌اند.

### الف) بخش ۱ — یکسان‌سازی مسیر واقعی فایل صوتی در Gradle و Android Runtime
1. **مرجع رسمی و واحد فایل‌های صوتی روایت کتاب:**
   - تمامی فایل‌های صوتی روایت کتاب منحصراً در مسیر `app/src/main/assets/narration/` قرار می‌گیرند و مقدار `audioAssetPath` در `manifest.json` همواره نسبت به این پوشه سنجیده می‌شود (مثلاً `chapter_01/section_01/block_001.mp3` معادل `app/src/main/assets/narration/chapter_01/section_01/block_001.mp3`).
2. **اصلاح `resolveAudioFile()` در `app/build.gradle.kts`:**
   - حذف کامل fallback به `File(assetsDir, audioPath)`.
   - حذف کامل fallback به `File(chapterFolder, audioPath)`.
   - پذیرش انحصاری `File(assetsDir, "narration/$audioPath")` به شرطی که مسیر Canonical آن زیر پوشهٔ `File(assetsDir, "narration").canonicalFile` باقی بماند.
3. **بازسازی دقیق ساختار `assets/narration/` در تست‌ها و پوشش هر ۸ سناریوی مسیر صوتی:**
   - بازسازی ساختار واقعی `tempAssetsDir/narration/...` در تمام Fixtureهای صوتی `ContentArchitectureVersion19Test.kt`.
   - بررسی تطابق مسیر دریافتی در `FakeNarrationPlaybackEngine` با فایل فیزیکی در `assets/narration/`.
   - راستی‌آزمایی هر ۸ سناریوی الزامی (پذیرش فایل موجود در `assets/narration/` با وضعیت `AVAILABLE`، رد فایل موجود فقط در ریشهٔ `assets/`، رد فایل موجود فقط در پوشهٔ `CH01/`، رد فایل خارج از `narration/` با نام معتبر، پذیرش `UNAVAILABLE` بدون فایل فیزیکی، رد مسیر دارای `../`، رد مسیر مطلق و خطای اعتبارسنجی در صورت نبود فایل `AVAILABLE`).

### ب) بخش ۲ — تفکیک اعتبارسنجی ساختاری JSON Schema از اعتبارسنجی معنایی در تست و گزارش
1. **اصلاح `evaluateAgainstSchemaFile()` در `ContentArchitectureVersion19Test.kt`:**
   - هماهنگ‌سازی کامل ارزیاب دستی Schema با قواعد ساختاری واقعی `content_schemas/narration_manifest.schema.json` (که در آن `uniqueItems: true` فقط اشیای کاملاً یکسان در آرایه را رد می‌کند و مسئول بررسی یکتایی معنایی `blockId` در دو شیء متفاوت، مالکیت `chapterId`/`sectionId` یا وجود فیزیکی فایل در دیسک نیست).
2. **اصلاح انتظارات ۱۸ سناریوی Fixture (`v19_2 narration 3`):**
   - سناریوی ۱۰ (`blockId` تکراری با `audioAssetPath` متفاوت)، سناریوی ۱۴ (فایل `AVAILABLE` ناموجود در دیسک)، سناریوی ۱۷ (`chapterId` نامنطبق با فصل مالک) و سناریوی ۱۸ (`sectionId` متعلق به فصل دیگر) از نظر **لایهٔ اول (Structural Schema) معتبر** و از نظر **لایهٔ دوم (Kotlin Semantic Validator) نامعتبر** هستند.
3. **به‌روزرسانی مستندات (`NARRATION_SCHEMA_CONSISTENCY_REPORT_FA.md` و `IMPLEMENTATION_REPORT.md`):**
   - مستندسازی دقیق تفکیک سه لایه (Structural JSON Schema، Kotlin Semantic Validation و Gradle Content Pack Validation)، حذف ادعای اجرای مستقیم ۱۸ Fixture توسط تسک Gradle و ثبت جدول اصلاح‌شدهٔ ۱۸ سناریو و ۸ سناریوی مسیر فایل صوتی.

---

## ۳. نتایج اجرای جداگانه دستورات اعتبارسنجی، تست و ساخت

1. **`./gradlew :app:validateContentPacks --console=plain`**:
   - وضعیت: `BUILD SUCCESSFUL` (`[validateContentPacks] All book content packs in assets/books/ validated successfully.`)
2. **`./gradlew :app:testDebugUnitTest --rerun-tasks --console=plain`**:
   - وضعیت: `BUILD SUCCESSFUL` — **۱۲۸ تست اجرا شد، ۰ خطا، ۰ شکست، ۰ ردشده:**
     - `ExampleRobolectricTest`: ۶۰ تست
     - `ReaderPaginationRobolectricTest`: ۳۲ تست
     - `ChessChapterOneTest`: ۲۳ تست
     - `ContentArchitectureVersion19Test`: ۷ تست
     - `ContentArchitectureVersion18Test`: ۵ تست
     - `ExampleUnitTest`: ۱ تست
3. **`./gradlew :app:assembleDebug --console=plain`**:
   - وضعیت: `BUILD SUCCESSFUL`
