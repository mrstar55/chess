# کتاب تعاملی شطرنج — موتور آموزشی داده‌محور اندروید (نسخه 19.3)

- **عنوان رسمی کتاب:** *How to Win at Chess*
- **عنوان فصل اول:** *How to (Literally) Win at Chess* (صفحات ۳۹ تا ۵۰ فایل PDF؛ صفحات دارای دیاگرام: ۴۰ تا ۴۹ و صفحه خلاصه: ۵۰)

این پروژه پیاده‌سازی بومی اندروید (**Kotlin + Jetpack Compose**) با **معماری جداسازی کامل موتور اپلیکیشن از محتوای کتاب (`Application Engine + Book Content Packs`)** در نسخه **19.3** است. در این نسخه، مسیر واقعی فایل‌های صوتی کتاب میان Android Runtime (`BookNarrationManager.kt`) و تسک Gradle (`validateContentPacks`) به‌طور انحصاری روی پوشهٔ `app/src/main/assets/narration/` یکسان‌سازی شده و تفکیک دقیق میان اعتبارسنجی ساختاری (`JSON Schema Structural Validation`)، اعتبارسنجی معنایی زمان اجرا (`Kotlin Semantic Validation`) و اعتبارسنجی بستهٔ محتوا در زمان ساخت (`Gradle Content Pack Validation`) در تست‌ها و گزارش فنی اعمال شده است.

---

## ۱. معماری و ویژگی‌های کلیدی پروژه (نسخه 19.3)

### الف) معماری محتوامحور (`Application Engine + Book Content Packs`)
1. **ساختار بسته محتوای استاندارد (`app/src/main/assets/books/`):**
   - `books/library.json`: کاتالوگ کتاب و فهرست فصل‌های فعال (`CH01`).
   - `books/how_to_win_at_chess/CH01/chapter.json`: متادیتای فصل اول و فهرست ۶ بخش آن با فیلد معنایی `sectionKind` (`OPENING`, `CONTENT`, `SUMMARY`).
   - `books/how_to_win_at_chess/CH01/sections/01_opening.json` تا `06_summary.json`: بلوک‌های محتوای ترتیبی (`orderedContentBlocks`) شامل پاراگراف، تیتر، پانویس، ارجاع بیرونی، نمودار و تمرین.
   - `books/how_to_win_at_chess/CH01/diagrams.json`: مشخصات کامل ۱۰ نمودار فصل اول (`BD-025` تا `BD-034`) همراه با وضعیت ممیزی داده‌محور (`audit_status` و `audit_warning_fa` برای `BD-027`).
   - `books/how_to_win_at_chess/CH01/pgn_sequences.json`: دنباله‌های حرکت قابل پخش و راه‌حل‌های تمرین.
   - `books/how_to_win_at_chess/CH01/exercises.json`: تعریف کامل داده‌محور تمرین‌ها (شامل `titleFa`، `promptFa`، `successFeedbackFa`، `wrongMoveFeedbackFa`، `illegalMoveFeedbackFa`، `hintFa`، `allowLegalMoveHints` و `initialFen`).
   - `books/how_to_win_at_chess/CH01/narration/manifest.json`: مانیفست روایت صوتی مستقل هر فصل با ساختار واحد `chapters -> sections -> blocks` و مسیر نسبی `audioAssetPath` نسبت به `app/src/main/assets/narration/`.
2. **سیستم تمرین کاملاً عمومی (`ExerciseUiState`, `ExerciseEngine`, `InteractiveExerciseView`):**
   - تعریف مدل‌های مستقل `ExerciseUiState` و `ExercisePhase` در `com.example.model`.
   - پشتیبانی از اجرای هم‌زمان چندین تمرین تعاملی مستقل با `ChessRulesAdapter` مجزا، وضعیت مستقل در `exerciseStates: Map<String, ExerciseUiState>` و برچسب‌های تست مبتنی بر `exerciseId`.
3. **قالب‌های آماده و اسکیماهای JSON:**
   - `starter_pack/content_template/`: قالب‌های آماده برای افزودن فصل جدید بدون کدنویسی.
   - `content_schemas/`: فایل‌های JSON Schema برای اعتبارسنجی ساختاری فایل‌های محتوا.
   - تسک خودکار `gradle validateContentPacks` متصل به `preBuild` با بررسی بازگشتی `chapters -> sections -> blocks` و بررسی وجود فیزیکی فایل‌های `AVAILABLE` منحصراً در `app/src/main/assets/narration/`.

### ب) معماری صوتی دوگانه: صدای مهره‌های شطرنج (`ChessSoundManager`) و خواندن صوتی کتاب (`BookNarrationManager`)
1. **سیستم صوتی ۱۱گانه شطرنج (`app/src/main/res/raw/*.wav` و `ChessSoundManager.kt`):**
   - ۱۱ فایل صوتی استودیویی WAV (۴۴۱۰۰ هرتز، ۱۶ بیت PCM Mono، بدون کلیپینگ).
2. **زیرساخت مستقل و چندفصلی خواندن صوتی کتاب (`BookNarrationManager.kt`):**
   - بارگذاری و اعتبارسنجی مانیفست صوتی اختصاصی هر فصل و بازگشایی فایل‌های صوتی از مسیر رسمی `narration/$audioAssetPath`.
   - پشتیبانی از فصل‌هایی با تعداد بخش‌های متغیر، توقف و آزادسازی خودکار پخش‌کننده هنگام تعویض فصل و ذخیره‌سازی موقعیت ادامه پخش صوتی به تفکیک هر فصل `(bookId, chapterId)`.

### ج) آیکون رسمی اپلیکیشن (اسب شطرنج — تولید مستقیم از تصویر اصلی)
- فایل مرجع اصلی با ابعاد `1254×1254` در مسیر `branding/chess_knight_app_icon_source.png` (کپی باینری مستقیم فایل پیوست‌شده، خارج از `assets`).
- آیکون تطبیقی اندروید (`ic_launcher_background.xml` با رنگ کرم گرم `#FEF0D2`، `ic_launcher_foreground.xml` مبتنی بر تصویر اصلی `@drawable/ic_launcher_foreground_bitmap`، و `ic_launcher_monochrome.xml` مبتنی بر سیلوئت استخراج‌شده مستقیم از تصویر اصلی `@drawable/ic_launcher_monochrome_bitmap` در `mipmap-anydpi-v26`) به همراه آیکون‌های PNG مربعی و گرد (`ic_launcher.png` و `ic_launcher_round.png`) در هر ۵ تراکم استاندارد (`mdpi`, `hdpi`, `xhdpi`, `xxhdpi`, `xxxhdpi`).

---

## ۲. دستورات اعتبارسنجی، تست و ساخت پروژه

```bash
# اعتبارسنجی خودکار بسته‌های محتوای کتاب
./gradlew :app:validateContentPacks --console=plain

# اجرای تمام ۱۲۸ تست واحد، Robolectric و Compose UI
./gradlew :app:testDebugUnitTest --rerun-tasks --console=plain

# ساخت فایل APK نسخه Debug
./gradlew :app:assembleDebug --console=plain
```

- **گزارش‌های تست (۱۲۸ تست با ۰ خطا و ۰ شکست):**
  - `ExampleRobolectricTest`: **۶۰ تست** (تست‌های انیمیشن، شبح مهره، مسیر حرکت، پالس قرمز Capture، توضیح پایدار حرکت، ثبات تخته، صدای ۱۱گانه شطرنج و زیرساخت خواندن صوتی کتاب)
  - `ReaderPaginationRobolectricTest`: **۳۲ تست** (تست‌های کتاب‌خوان صفحه‌گردان فارسی، عدم اسکرول عمودی، هندسه مربع خانه‌های تخته، نشان‌های معنایی و صفحات آغازین)
  - `ChessChapterOneTest`: **۲۳ تست** (قوانین شطرنج، Perft، FEN، PGN و یکپارچگی داده‌های فصل اول)
  - `ContentArchitectureVersion18Test`: **۵ تست** (برابری کامل فصل اول، فصل دوم آزمایشی `CH02` و ناوبری چندفصلی)
  - `ContentArchitectureVersion19Test`: **۷ تست جامع نسخه ۱۹ تا 19.3** (استقلال کامل `ExerciseUiState` و `ExerciseEngine` از UI و `BD-032`، اجرای هم‌زمان دو تمرین `MATE_IN_ONE` در یک فصل، اعتبارسنجی عدم تطابق `initialFen` تمرین با نمودار، عمومی‌سازی چندفصلی `BookNarrationManager`، راستی‌آزمایی منابع آیکون رسمی اسب شطرنج مبتنی بر تصویر اصلی، سناریوهای اعتبارسنجی بازگشتی مانیفست صوتی و مسیر انحصاری `assets/narration/`، و ۱۸ سناریوی تفکیک ارزیابی ساختاری JSON Schema و اعتبارسنجی معنایی Kotlin)
  - `ExampleUnitTest`: **۱ تست** پایه
