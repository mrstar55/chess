package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ChapterCatalogEntry
import com.example.model.FrontMatterTocEntry
import com.example.model.ReaderPaginator
import com.example.ui.ChapterUiState
import com.example.ui.theme.AppIcons

/**
 * Grouping of a book chapter from `front_matter/table_of_contents.json` (Chapters 1..15).
 */
data class BookTocChapterGroup(
    val chapterId: String,
    val chapterNumber: Int,
    val chapterLabelFa: String,
    val chapterTitleFa: String,
    val chapterTitleEn: String,
    val startPdfPage: Int,
    val endPdfPage: Int?,
    val subtopics: List<FrontMatterTocEntry>
)

object BookTocNavigationHelper {

    fun extractFrontMatterTopics(entries: List<FrontMatterTocEntry>): List<FrontMatterTocEntry> {
        return entries.filter { entry ->
            entry.chapterId == null &&
                entry.targetSourcePdfPage in 1..38 &&
                entry.entryKind.lowercase() in setOf(
                    "frontmatter",
                    "topic",
                    "front_matter_section",
                    "front_matter_subsection"
                )
        }
    }

    fun extractChapterGroups(entries: List<FrontMatterTocEntry>): List<BookTocChapterGroup> {
        if (entries.isEmpty()) return emptyList()
        val byChapterId = entries.filter { !it.chapterId.isNullOrBlank() }.groupBy { it.chapterId!! }
        val sortedChapterIds = byChapterId.keys.sortedBy {
            it.removePrefix("CH").toIntOrNull() ?: 999
        }
        return sortedChapterIds.mapIndexed { idx, chId ->
            val chEntries = byChapterId[chId].orEmpty()
            val chNum = chId.removePrefix("CH").toIntOrNull() ?: (idx + 1)
            val headerEntry = chEntries.firstOrNull {
                it.entryKind.equals("chapter", ignoreCase = true) ||
                    it.entryKind.equals("CHAPTER", ignoreCase = true)
            }
            val titleEntry = chEntries.firstOrNull {
                it.entryKind.equals("chapterTitle", ignoreCase = true) ||
                    it.entryKind.equals("CHAPTER_TITLE", ignoreCase = true)
            }
            val subtopics = chEntries.filter {
                it.entryKind.equals("topic", ignoreCase = true) ||
                    it.entryKind.equals("section", ignoreCase = true) ||
                    it.entryKind.equals("SECTION", ignoreCase = true)
            }
            val startPage = titleEntry?.targetSourcePdfPage
                ?: headerEntry?.targetSourcePdfPage
                ?: subtopics.firstOrNull()?.targetSourcePdfPage
                ?: 40
            val nextChId = sortedChapterIds.getOrNull(idx + 1)
            val nextStart = nextChId?.let { nId ->
                byChapterId[nId]?.firstOrNull()?.targetSourcePdfPage
            }
            val endPage = when {
                chId == "CH01" -> 50
                nextStart != null && nextStart > startPage -> nextStart - 1
                else -> subtopics.maxOfOrNull { it.targetSourcePdfPage }
            }
            BookTocChapterGroup(
                chapterId = chId,
                chapterNumber = chNum,
                chapterLabelFa = headerEntry?.labelFa ?: "فصل ${ReaderPaginator.toPersianDigits(chNum)}",
                chapterTitleFa = titleEntry?.labelFa ?: headerEntry?.labelFa ?: chId,
                chapterTitleEn = titleEntry?.sourceLabel ?: headerEntry?.sourceLabel ?: chId,
                startPdfPage = startPage,
                endPdfPage = endPage,
                subtopics = subtopics
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChaptersListScreen(
    state: ChapterUiState,
    onSelectChapter: (String) -> Unit,
    onBackToIntroduction: () -> Unit,
    onStartFrontMatter: (Int) -> Unit = {},
    onResumeFrontMatter: () -> Unit = {},
    onNavigateToPdfPage: (Int, String?) -> Unit = { page, _ ->
        if (page in 1..39) onStartFrontMatter(page) else onSelectChapter("CH01")
    },
    onDismissNavigationNotice: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val fontMultiplier = state.fontScale.scale
    val tocEntries = state.frontMatterPack?.tableOfContents?.entries.orEmpty()
    val frontMatterTopics = remember(tocEntries) {
        BookTocNavigationHelper.extractFrontMatterTopics(tocEntries)
    }
    val tocChapterGroups = remember(tocEntries) {
        BookTocNavigationHelper.extractChapterGroups(tocEntries)
    }
    val enabledChapterIds = remember(state.availableChapters) {
        state.availableChapters.map { it.chapterId }.toSet()
    }
    val upcomingTocChapters = remember(tocChapterGroups, enabledChapterIds) {
        tocChapterGroups.filter { it.chapterId !in enabledChapterIds }
    }

    var frontMatterTopicsExpanded by remember { mutableStateOf(true) }
    var expandedChapterId by remember { mutableStateOf<String?>("CH01") }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "فهرست فصل‌های کتاب",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.testTag("chapters_list_title")
                            )
                            Text(
                                text = state.activeBookTitleFa,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = onBackToIntroduction,
                            modifier = Modifier.testTag("back_to_intro_from_chapters_btn")
                        ) {
                            Icon(
                                imageVector = AppIcons.ArrowBack,
                                contentDescription = "بازگشت به معرفی کتاب"
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                )
            },
            modifier = modifier.testTag("chapters_list_screen")
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp)
                    .testTag("chapters_lazy_list"),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                if (!state.lastNavigationNoticeFa.isNullOrBlank()) {
                    item(key = "navigation_notice_banner") {
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("navigation_notice_banner"),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.outlinedCardColors(
                                containerColor = MaterialTheme.colorScheme.secondaryContainer
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = state.lastNavigationNoticeFa,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = onDismissNavigationNotice,
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = AppIcons.Close,
                                        contentDescription = "بستن اعلان"
                                    )
                                }
                            }
                        }
                    }
                }

                // 1. Unified First Item: پیش‌درآمد و مبانی شطرنج (PDF Pages 1 to 39 — no artificial chapter number)
                if (state.hasFrontMatter) {
                    item(key = "FRONT_MATTER_UNIFIED_ITEM") {
                        UnifiedFrontMatterChapterCard(
                            navigationTitleFa = state.frontMatterNavigationTitleFa,
                            fullTitleFa = "معرفی کتاب، مهره‌ها، قوانین حرکت، نمادگذاری شطرنج و اهداف آموزشی",
                            lastReadPdfPage = state.lastReadFrontMatterSourcePdfPage,
                            isActiveRegion = state.isReadingFrontMatter,
                            topics = frontMatterTopics,
                            isExpanded = frontMatterTopicsExpanded,
                            fontMultiplier = fontMultiplier,
                            onToggleExpand = { frontMatterTopicsExpanded = !frontMatterTopicsExpanded },
                            onStartFromPage1 = { onStartFrontMatter(1) },
                            onResumeFrontMatter = onResumeFrontMatter,
                            onOpenIntroPage11 = { onStartFrontMatter(11) },
                            onSelectTopicPage = { page -> onNavigateToPdfPage(page, null) }
                        )
                    }
                }

                // 2. Active / Enabled Chapters (e.g. CH01 — فصل اول)
                items(state.availableChapters, key = { it.chapterId }) { chapter ->
                    val tocGroup = tocChapterGroups.find { it.chapterId == chapter.chapterId }
                    ChapterItemCard(
                        chapter = chapter,
                        tocGroup = tocGroup,
                        isSelected = !state.isReadingFrontMatter && chapter.chapterId == state.activeChapterId,
                        isExpanded = expandedChapterId == chapter.chapterId,
                        fontMultiplier = fontMultiplier,
                        onClick = { onSelectChapter(chapter.chapterId) },
                        onToggleSubtopics = {
                            expandedChapterId = if (expandedChapterId == chapter.chapterId) null else chapter.chapterId
                        },
                        onSelectSubtopicPage = { page ->
                            onNavigateToPdfPage(page, chapter.chapterId)
                        }
                    )
                }

                // 3. Remaining Book Chapters (CH02..CH15 from front_matter/table_of_contents.json)
                items(upcomingTocChapters, key = { it.chapterId }) { tocChapter ->
                    UpcomingTocChapterCard(
                        tocChapter = tocChapter,
                        isExpanded = expandedChapterId == tocChapter.chapterId,
                        fontMultiplier = fontMultiplier,
                        onToggleExpand = {
                            expandedChapterId = if (expandedChapterId == tocChapter.chapterId) null else tocChapter.chapterId
                        },
                        onSelectChapterOrSubtopic = { page ->
                            onNavigateToPdfPage(page, tocChapter.chapterId)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun UnifiedFrontMatterChapterCard(
    navigationTitleFa: String,
    fullTitleFa: String,
    lastReadPdfPage: Int,
    isActiveRegion: Boolean,
    topics: List<FrontMatterTocEntry>,
    isExpanded: Boolean,
    fontMultiplier: Float,
    onToggleExpand: () -> Unit,
    onStartFromPage1: () -> Unit,
    onResumeFrontMatter: () -> Unit,
    onOpenIntroPage11: () -> Unit,
    onSelectTopicPage: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        onClick = onToggleExpand,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = if (isActiveRegion) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("front_matter_region_card")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Book icon badge (no artificial chapter number)
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = AppIcons.AutoStories,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = navigationTitleFa,
                            fontWeight = FontWeight.Bold,
                            fontSize = (15.5f * fontMultiplier).sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.testTag("front_matter_nav_title_text")
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = "صفحات PDF ۱ تا ۳۹",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                    .testTag("front_matter_page_range_badge")
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = fullTitleFa,
                        fontSize = (12f * fontMultiplier).sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.testTag("front_matter_full_title_text")
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilledTonalButton(
                    onClick = onStartFromPage1,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(32.dp)
                        .testTag("front_matter_start_btn")
                ) {
                    Text("شروع از صفحه ۱", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                FilledTonalButton(
                    onClick = onOpenIntroPage11,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(32.dp)
                        .testTag("front_matter_intro_page11_btn")
                ) {
                    Text("مقدمه (صفحه ۱۱)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onResumeFrontMatter,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier
                        .weight(1.2f)
                        .height(32.dp)
                        .testTag("front_matter_resume_btn")
                ) {
                    val lastPageFa = ReaderPaginator.toPersianDigits(lastReadPdfPage)
                    Text("ادامه (صفحه $lastPageFa)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            AnimatedVisibility(visible = isExpanded && topics.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    HorizontalDivider(
                        thickness = 0.6.dp,
                        color = MaterialTheme.colorScheme.outlineVariant
                    )
                    Text(
                        text = "موضوعات پیش‌درآمد و مبانی شطرنج:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    topics.forEachIndexed { idx, topic ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectTopicPage(topic.targetSourcePdfPage) }
                                .testTag("toc_front_matter_topic_$idx")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = topic.labelFa,
                                    fontSize = (12.5f * fontMultiplier).sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Text(
                                    text = "صفحه PDF ${ReaderPaginator.toPersianDigits(topic.targetSourcePdfPage)}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChapterItemCard(
    chapter: ChapterCatalogEntry,
    tocGroup: BookTocChapterGroup?,
    isSelected: Boolean,
    isExpanded: Boolean,
    fontMultiplier: Float,
    onClick: () -> Unit,
    onToggleSubtopics: () -> Unit,
    onSelectSubtopicPage: (Int) -> Unit
) {
    val startPage = tocGroup?.startPdfPage ?: 40
    val endPage = tocGroup?.endPdfPage ?: 50
    val pageRangeText = "صفحات PDF ${ReaderPaginator.toPersianDigits(startPage)} تا ${ReaderPaginator.toPersianDigits(endPage)}"

    ElevatedCard(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = if (isSelected) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("chapter_card_${chapter.chapterId}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = ReaderPaginator.toPersianDigits(chapter.chapterNumber),
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = tocGroup?.chapterLabelFa ?: "فصل ${ReaderPaginator.toPersianDigits(chapter.chapterNumber)}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = pageRangeText,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = chapter.titleFa,
                        fontWeight = FontWeight.Bold,
                        fontSize = (15.5f * fontMultiplier).sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = chapter.titleEn,
                        fontSize = (12.5f * fontMultiplier).sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                }

                IconButton(
                    onClick = onToggleSubtopics,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = AppIcons.ChevronLeft,
                        contentDescription = "مشاهده بخش‌های فصل",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            if (tocGroup != null && tocGroup.subtopics.isNotEmpty() && isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    HorizontalDivider(
                        thickness = 0.6.dp,
                        color = MaterialTheme.colorScheme.outlineVariant
                    )
                    tocGroup.subtopics.forEachIndexed { idx, sub ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectSubtopicPage(sub.targetSourcePdfPage) }
                                .testTag("toc_subtopic_${chapter.chapterId}_$idx")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = sub.labelFa,
                                    fontSize = (12.5f * fontMultiplier).sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Text(
                                    text = "صفحه PDF ${ReaderPaginator.toPersianDigits(sub.targetSourcePdfPage)}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun UpcomingTocChapterCard(
    tocChapter: BookTocChapterGroup,
    isExpanded: Boolean,
    fontMultiplier: Float,
    onToggleExpand: () -> Unit,
    onSelectChapterOrSubtopic: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        onClick = { onSelectChapterOrSubtopic(tocChapter.startPdfPage) },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("chapter_card_${tocChapter.chapterId}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = ReaderPaginator.toPersianDigits(tocChapter.chapterNumber),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${tocChapter.chapterLabelFa} (صفحه PDF ${ReaderPaginator.toPersianDigits(tocChapter.startPdfPage)})",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer
                        ) {
                            Text(
                                text = "محتوا در حال آماده‌سازی",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = tocChapter.chapterTitleFa,
                        fontWeight = FontWeight.Bold,
                        fontSize = (14.5f * fontMultiplier).sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = tocChapter.chapterTitleEn,
                        fontSize = (11.5f * fontMultiplier).sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                }

                if (tocChapter.subtopics.isNotEmpty()) {
                    IconButton(
                        onClick = onToggleExpand,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("toc_expand_btn_${tocChapter.chapterId}")
                    ) {
                        Icon(
                            imageVector = AppIcons.ChevronLeft,
                            contentDescription = "مشاهده زیرموضوعات ${tocChapter.chapterLabelFa}",
                            tint = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            }

            AnimatedVisibility(visible = isExpanded && tocChapter.subtopics.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    HorizontalDivider(
                        thickness = 0.6.dp,
                        color = MaterialTheme.colorScheme.outlineVariant
                    )
                    tocChapter.subtopics.forEachIndexed { idx, sub ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectChapterOrSubtopic(sub.targetSourcePdfPage) }
                                .testTag("toc_subtopic_${tocChapter.chapterId}_$idx")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 5.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = sub.labelFa,
                                    fontSize = (12f * fontMultiplier).sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "صفحه ${ReaderPaginator.toPersianDigits(sub.targetSourcePdfPage)}",
                                    fontSize = 10.5.sp,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
