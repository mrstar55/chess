# گزارش پیاده‌سازی، کنترل کیفیت نهایی و بهینه‌سازی فنی — فصل اول (نسخه ۰۴)

این گزارش مستندات کامل آخرین مرحله کنترل کیفیت فنی نمونه اولیه فصل اول (نسخه `-04`) شامل تکمیل اعتبارسنجی FEN، تست واقعی Compose UI برای عدم افشای جواب `BD-032`، تفکیک دقیق اجرای JVM و D8 برای `KChessLib`، بهینه‌سازی حجم APK و خروجی واقعی اجرای تست‌ها، اسکرین‌شات‌ها و بررسی نصب روی دستگاه را ارائه می‌دهد.

---

## ۱. تکمیل اعتبارسنجی FEN (`ChessEngine.kt` -> `parseFen`)

### ۱.۱ قانون اضافه‌شده در `parseValidatedFenParts`
- موقعیتی که در آن **شاهِ طرفی که نوبت حرکتش نیست (Inactive Side) در وضعیت کیش قرار داشته باشد** در شطرنج غیرقانونی است و اکنون در متد `ChessEngine.parseFen` (و `parseIncompleteFen`) با پرتاب `IllegalArgumentException` رد می‌شود:
  ```kotlin
  val inactiveColor = if (activeColor == 'w') 'b' else 'w'
  if (isColorInCheck(inactiveColor, board)) {
      throw IllegalArgumentException(
          "Invalid FEN: king of the side not to move ('$inactiveColor') cannot be in check"
      )
  }
  ```

### ۱.۲ تست‌های جدید اضافه‌شده (`testFenValidation_ActiveVsInactiveKingInCheckAndDiagrams`)
1. **شاه طرفی که نوبتش نیست در کیش باشد -> رد می‌شود (`IllegalArgumentException`):**
   - `4k3/8/8/8/8/8/4R3/4K3 w - - 0 1` (شاه سیاه در `e8` توسط رخ سفید `e2` در کیش است ولی نوبت سفید `w` است -> **رد شد**)
   - `4k3/4r3/8/8/8/8/8/4K3 b - - 0 1` (شاه سفید در `e1` توسط رخ سیاه `e7` در کیش است ولی نوبت سیاه `b` است -> **رد شد**)
2. **شاه طرفی که نوبت دارد در کیش باشد -> پذیرفته می‌شود:**
   - `4k3/8/8/8/8/8/4R3/4K3 b - - 0 1` (نوبت سیاه `b` است و شاه سیاه در کیش است -> **پذیرفته شد** و `isInCheck() == true`)
   - `4k3/4r3/8/8/8/8/8/4K3 w - - 0 1` (نوبت سفید `w` است و شاه سفید در کیش است -> **پذیرفته شد** و `isInCheck() == true`)
3. **وضعیت شروع استاندارد (`STANDARD_START_FEN`) -> پذیرفته می‌شود.**
4. **هر ۱۰ نمودار فصل اول (`BD-025` تا `BD-034`) -> وضعیت قبلی کاملاً حفظ شده و پذیرفته می‌شوند.**

---

## ۲. تست واقعی عدم افشای جواب `BD-032` با Compose UI (`ExampleRobolectricTest.kt`)

تست جدید `verify BD032 Compose UI does not reveal Qh8 or Qh2 or target squares before solving and shows success after solving` با استفاده از `createComposeRule()` کامپوننت واقعی `DiagramCard` و `Bd032ExerciseView` را رندر کرده و موارد زیر را روی درخت معنایی (Semantics Tree) رابط کاربری بررسی می‌کند:
1. **قبل از حل تمرین:**
   - تمام گره‌های متنی و `contentDescription` در درخت `onRoot(useUnmergedTree = true)` استخراج می‌شوند و بررسی می‌گردد که هیچ متنی شامل `Qh8#`، `Qh2#`، `Qh8`، `Qh2`، `h8` یا `h2` در رابط کاربری وجود ندارد.
   - بررسی می‌شود که `bd032Diagram.highlightSquares` و `bd032State.legalTargetSquares` خالی هستند و خانه‌های `h8` و `h2` به‌عنوان جواب به کاربر معرفی یا هایلایت نمی‌شوند.
   - بررسی می‌شود که بنر بازخورد (`exercise_feedback`) قبل از تعامل وجود ندارد.
2. **پس از حل تمرین با کلیک واقعی روی خانه‌های صفحه شطرنج:**
   - با اجرای `onNodeWithTag("square_e5").performClick()` و سپس `onNodeWithTag("square_h8").performClick()`، بنر `exercise_feedback` ظاهر شده و پیام موفقیت `«پاسخ صحیح! حرکت Qh8# توسط موتور قوانین بررسی شد و شاه سفید مات شد.»` نمایش داده می‌شود.
   - سپس دکمه `exercise_reset_btn` لمس شده، عدم وجود متن پاسخ مجدداً بررسی شده و حرکت دوم (`square_e5` به `square_h2`) نیز در UI اجرا و پیام موفقیت `Qh2#` تأیید می‌شود.

---

## ۳. گزارش اصلاح‌شده و دقیق ارزیابی `KChessLib` (`io.github.cvb941:kchesslib:1.0.5`)

### ۳.۱ تفکیک اجرای تست در JVM از بیلد Android با D8
1. **بررسی بایت‌کد کتابخانه با `javap -v` (قابل بازتولید):**
   فایل `kchesslib-jvm-1.0.5.jar` در Maven Central با **Java 21 (`major version: 65`, class file version `65.0`)** و **Kotlin `2.2.21` (`mv = [2, 2, 0]`)** کامپایل شده است:
   ```text
   Classfile jar:file:///.../kchesslib-jvm-1.0.5.jar!/com/github/bhlangonijr/chesslib/Board.class
     minor version: 0
     major version: 65
     flags: (0x0031) ACC_PUBLIC, ACC_FINAL, ACC_SUPER
   RuntimeVisibleAnnotations:
     kotlin.Metadata(mv=[2, 2, 0], k=1, xi=48, ...)
   ```
2. **رفتار در اجرای JVM (مانند `./gradlew testDebugUnitTest`):**
   - در زمان اجرای تست‌های واحد روی ماشین مجازی جاوا (JVM)، کلاس‌های `kchesslib-jvm:1.0.5` مستقیماً توسط ClassLoader استاندارد JVM بارگذاری می‌شوند.
   - اگر تست‌ها روی **JDK 17** اجرا شوند (که حداکثر تا `class file version 61.0` را می‌شناسد)، بارگذاری کلاس `Board` با خطای زیر مواجه می‌شود:
     `java.lang.UnsupportedClassVersionError: com/github/bhlangonijr/chesslib/Board has been compiled by a more recent version of the Java Runtime (class file version 65.0), this version of the Java Runtime only recognizes class file versions up to 61.0`
   - اجرای مستقیم JVM برای این کتابخانه نیازمند **JDK 21** است.
3. **رفتار در بیلد Android با D8 (`./gradlew assembleDebug`):**
   - در زنجیره ساخت اندروید، کامپایلر **D8** بایت‌کد جاوا را به فرمت Dalvik Executable (`.dex`) تبدیل و Desugar می‌کند.
   - هنگامی که پروسه Gradle با **JDK 21** اجرا شود، D8 کلاس‌های `major version: 65` را بدون خطا به DEX سازگار با `minSdk = 24` تبدیل می‌کند.
4. **وضعیت سازگاری با Kotlin و Android:**
   - پروژه فعلی از **Kotlin `2.2.10`** استفاده می‌کند، در حالی که `kchesslib:1.0.5` وابستگی انتقالی `org.jetbrains.kotlin:kotlin-stdlib:2.2.21` به همراه `kotlinx-datetime:0.7.1` و `kotlinx-io-core:0.8.2` را وارد گراف وابستگی می‌کند و فایل ۳۵۸ کیلوبایتی `eco.pgn` را در APK قرار می‌دهد.
   - علاوه بر این، در تست‌های فنی مشخص شد `KChessLib 1.0.5` در `generateCastleMoves` حضور واقعی رخ در خانه‌های اولیه را بررسی نمی‌کند و در `loadFromFen` نیز FENهای نامعتبر (مانند شاه‌های مجاور یا در کیش بودن شاهِ طرفِ غیرفعال) را رد نمی‌کند.
   - مطابق دستور، `KChessLib` به پروژه اضافه نشده و موتور فعلی (`ChessEngine`) حفظ شده است.

---

## ۴. گزارش کامل اجرای تست‌ها (تعداد دقیق `@Test` از خروجی واقعی Gradle)

تمامی **۳۲ تست خودکار** پروژه با دستور `gradle :app:testDebugUnitTest --rerun-tasks` اجرا شدند و با **۰ خطا و ۰ شکست** (`failures="0" errors="0"`) به پایان رسیدند:

| کلاس تست | تعداد `@Test` | زمان اجرا | وضعیت |
|---|---|---|---|
| `com.example.ChessChapterOneTest` | **23** | `0.813s` | **PASS (23/23)** |
| `com.example.ExampleRobolectricTest` | **8** | `16.106s` | **PASS (8/8)** |
| `com.example.ExampleUnitTest` | **1** | `0.001s` | **PASS (1/1)** |
| **مجموع کل** | **32** | `16.920s` | **PASS (32/32)** |

### پوشش کامل تست‌های موتور و UI:
- **Perft وضعیت شروع استاندارد تا عمق ۴:** `Depth 1 = 20`، `Depth 2 = 400`، `Depth 3 = 8902`، `Depth 4 = 197281` (`PASS`)
- **Perft موقعیت‌های پیچیده (Kiwipete، CPW Pos 3، CPW Pos 4):** `97862`، `43238`، `9467` (`PASS`)
- **اعتبارسنجی سخت‌گیرانه FEN (شامل رد کیش بودن شاه طرف غیرفعال و پذیرش کیش بودن شاه طرف فعال):** (`PASS`)
- **آن‌پاسان و حذف واقعی پیاده گرفته‌شده، ارتقای پیاده به هر ۴ مهره و رد ارتقای بدون انتخاب مهره:** (`PASS`)
- **قلعه و حقوق قلعه (شامل رد قلعه بدون رخ و حذف حق قلعه در صورت زده شدن رخ در خانه اولیه):** (`PASS`)
- **کیش، مات، پات، آچار و کیش دوگانه:** (`PASS`)
- **بررسی هر ۱۰ نمودار فصل اول (`BD-025` تا `BD-034`) و وضعیت مسدود `BD-027` (`1...Kg8`):** (`PASS`)
- **تست منطق و تست واقعی Compose UI برای تمرین `BD-032` (عدم افشای `Qh8#`/`Qh2#`/`h8`/`h2` قبل از حل و نمایش پیام موفقیت پس از حل):** (`PASS`)
- **بازپخش PGN و راستی‌آزمایی تمام ۶ فیلد FEN شامل `enPassant`:** (`PASS`)
- **عدم وارونگی مختصات صفحه شطرنج (`a..h` چپ به راست و `8..1` بالا به پایین) در محیط فارسی RTL:** (`PASS`)

---

## ۵. بهینه‌سازی حجم برنامه (مقایسه نسخه جدید با نسخه‌های قبلی)

### اقدامات انجام‌شده در `app/build.gradle.kts` و `AppIcons.kt`
1. حفظ و تکمیل آیکون‌های برداری اختصاصی در `AppIcons.kt` (شامل ۱۸ آیکون برداری استاندارد ۲۴×۲۴).
2. حذف کامل وابستگی‌های غیرضروری باقی‌مانده از `app/build.gradle.kts`:
   - حذف `androidx.compose.material:material-icons-core`
   - حذف `androidx.compose.ui:ui-tooling` و `androidx.compose.ui:ui-tooling-preview`
   - حذف `androidx.lifecycle:lifecycle-runtime-compose`
   - حذف وابستگی‌های غیرضروری `androidTestImplementation`

### جدول مقایسه حجم APK
| نسخه | حجم دقیق `app-debug.apk` (بایت) | حجم برحسب مگابایت | تغییرات نسبت به نسخه قبل |
|---|---|---|---|
| نسخه ۰۲ (قبل از حذف آیکون‌های Extended) | `22,329,140` بایت | **22.33 MB (`21.29 MiB`)** | — |
| نسخه ۰۳ (حذف `material-icons-extended`) | `9,715,055` بایت | **9.72 MB (`9.26 MiB`)** | کاهش `12,614,085` بایت (`-56.49%`) |
| **نسخه ۰۴ (حذف `material-icons-core`، `ui-tooling` و کتابخانه‌های غیرضروری باقی‌مانده)** | **`8,988,422` بایت** | **8.99 MB (`8.57 MiB`)** | **کاهش 추가 `726,633` بایت نسبت به نسخه ۰۳ (مجموعاً `-59.75%` کاهش نسبت به نسخه ۰۲)** |

---

## ۶. گزارش اجرای واقعی دستور نصب روی دستگاه (`installDebug`) و اسکرین‌شات‌ها

### ۶.۱ خروجی واقعی اجرای `adb devices` و `gradle testDebugUnitTest installDebug`
در محیط کانتینر ابری بیلد، دستور بررسی دستگاه‌های متصل و نصب مستقیم اجرا شد. خروجی واقعی و بدون تغییر دستور:
```text
/opt/android/sdk/platform-tools/adb
* daemon not running; starting now at tcp:5037
* daemon started successfully
List of devices attached

> Task :app:installDebug FAILED
FAILURE: Build failed with an exception.
* What went wrong:
Execution failed for task ':app:installDebug'.
> com.android.builder.testing.api.DeviceException: No connected devices!
```
- **گزارش صادقانه وضعیت نصب مستقیم:** در محیط کانتینر سرور بیلد، هیچ دستگاه فیزیکی یا شبیه‌ساز از طریق ADB مستقیم (`tcp:5037`) به کانتینر متصل نیست (`List of devices attached` خالی است) و بنابراین تسک `:app:installDebug` همان‌طور که در لاگ بالا ثبت شده با پیام `DeviceException: No connected devices!` متوقف می‌شود. (در پلتفرم AI Studio، نصب و نمایش برنامه روی Streaming Emulator پس از اتمام پاسخ عامل توسط سرویس بیرونی پلتفرم انجام می‌گیرد).

### ۶.۲ اسکرین‌شات‌های واقعی رندرشده از رابط کاربری (`screenshots/`)
با استفاده از موتور گرافیکی بومی Robolectric (`@GraphicsMode(GraphicsMode.Mode.NATIVE)`) در حین اجرای تست‌های UI، ۵ اسکرین‌شات واقعی با وضوح `1080x2340` از صفحات برنامه رندر و در پوشه `screenshots/` ذخیره شدند:
1. `screenshots/01_main_sections_list.png`: **صفحه اصلی** (فهرست ۶ بخش فصل اول، آمار ممیزی و دکمه‌های ناوبری در چیدمان RTL).
2. `screenshots/02_reader_screen_section1.png`: **صفحه مطالعه (بخش ۱)** شامل `TranslationSlot` با شناسه `SEC_CH01_01_OPENING` و دیاگرام آغازین `BD-025`.
3. `screenshots/03_chessboard_section2_checkmate.png`: **صفحه شطرنج و بخش ۲ (مات)** شامل دیاگرام `BD-026` و کارت دیاگرام `BD-027`.
4. `screenshots/04_bd032_section4_before_solve.png`: **تمرین تعاملی `BD-032` قبل از حل** (بدون هیچ‌گونه افشای پاسخ `Qh8#` یا `Qh2#` یا هایلایت خانه‌های مقصد).
5. `screenshots/05_bd032_section4_after_solve.png`: **تمرین تعاملی `BD-032` پس از حل با حرکت `Qh8#`** (نمایش موقعیت مات روی صفحه شطرنج و بنر سبز تأیید حرکت توسط موتور قوانین).
