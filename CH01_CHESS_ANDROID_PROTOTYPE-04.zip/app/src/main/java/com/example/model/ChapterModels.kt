package com.example.model

enum class AuditStatus {
    VALID,
    BLOCKED_NEEDS_HUMAN_REVIEW
}

data class ChessPiece(
    val type: PieceType,
    val isWhite: Boolean
) {
    val symbol: String
        get() = when (type) {
            PieceType.PAWN -> if (isWhite) "♙" else "♟"
            PieceType.KNIGHT -> if (isWhite) "♘" else "♞"
            PieceType.BISHOP -> if (isWhite) "♗" else "♝"
            PieceType.ROOK -> if (isWhite) "♖" else "♜"
            PieceType.QUEEN -> if (isWhite) "♕" else "♛"
            PieceType.KING -> if (isWhite) "♔" else "♚"
        }
}

enum class PieceType {
    PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING
}

data class BoardSquare(
    val file: Int, // 0 to 7 (a to h)
    val rank: Int, // 0 to 7 (1 to 8)
    val piece: ChessPiece?,
    val isHighlighted: Boolean = false,
    val isSelected: Boolean = false,
    val isPossibleMove: Boolean = false
) {
    val notation: String
        get() = "${('a' + file)}${rank + 1}"
}

data class DiagramItem(
    val diagramId: String,
    val pdfPage: Int,
    val sectionName: String,
    val bookContext: String,
    val diagramKind: String,
    val recommendedInteraction: String,
    val initialFen: String,
    val currentFen: String = initialFen,
    val sideToMove: String,
    val moveHistory: String,
    val pgnRef: String?,
    val solutionPgnRefs: List<String> = emptyList(),
    val highlightSquares: List<String>,
    val relatedDiagramIds: List<String>,
    val visualConfidence: String,
    val implementationNotes: String,
    val auditStatus: AuditStatus = AuditStatus.VALID,
    val auditWarning: String? = null
)

data class TranslationSlot(
    val sectionId: String,
    val isPending: Boolean = true,
    val translatedParagraphs: List<String> = emptyList(),
    val placeholderNotice: String = "در انتظار اتصال ترجمه رسمی متن کتاب توسط مدیر پروژه (شناسه اتصال: $sectionId)"
)

data class SectionItem(
    val sectionId: String,
    val index: Int,
    val titleEn: String,
    val titleFa: String,
    val pdfPages: List<Int>,
    val diagramIds: List<String>,
    val translationSlot: TranslationSlot
)

data class PgnGameItem(
    val id: String,
    val description: String,
    val result: String,
    val moves: String
)
