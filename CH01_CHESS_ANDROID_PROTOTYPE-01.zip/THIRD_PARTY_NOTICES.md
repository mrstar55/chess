# اطلاعیه مجوزهای شخص ثالث و دارایی‌ها (THIRD_PARTY_NOTICES)

این سند شامل مجوزها و شرایط استفاده از کتابخانه‌ها، فونت‌ها، گلیف‌ها و بسته‌های منبع باز استفاده‌شده در این نمونه اولیه است.

---

## ۱. نرم‌افزارهای منبع باز (Dependencies)

### Android Jetpack Libraries & Compose
- **ناشر:** Google LLC / Android Open Source Project
- **مجوز:** Apache License, Version 2.0
- **ماژول‌ها:**
  - `androidx.compose.ui`
  - `androidx.compose.material3`
  - `androidx.compose.foundation`
  - `androidx.activity.compose`
  - `androidx.lifecycle.viewmodel.compose`
  - `androidx.core.ktx`

### Moshi (JSON Serialization)
- **ناشر:** Square, Inc.
- **مجوز:** Apache License, Version 2.0
- **توضیحات:** جهت پردازش سریع و سبک ساختارهای داده JSON محلی.

### Kotlin Standard Library & Coroutines
- **ناشر:** JetBrains s.r.o.
- **مجوز:** Apache License, Version 2.0

### chess.js (محیط ابزار ممیزی)
- **ناشر:** Jeff Hlywa
- **مجوز:** BSD-2-Clause License
- **توضیحات:** کتابخانه استاندارد قوانین شطرنج جهت اعتبارسنجی مستقل و ممیزی FEN و PGN در مرحله صفر.

---

## ۲. گلیف‌ها و دارایی‌های تصویری (Assets & Glyphs)

### گلیف‌های بین‌المللی شطرنج (Unicode Standard Chess Glyphs)
- **کدهای یونیکد:** U+2654 تا U+265F (♚ ♛ ♜ ♝ ♞ ♟ ♔ ♕ ♖ ♗ ♘ ♙)
- **مجوز:** استاندارد کنسرسیوم یونیکد (Unicode Consortium Data Files and Software License) / رندر شده با قلم پیش‌فرض سیستم اندروید
- **توضیحات:** هیچ دارایی یا اسکرین‌شات کپی‌رایت‌دار از کتاب اصلی وارد رابط کاربری نشده و رندر تخته مستقیماً از روی FEN انجام می‌شود.

### آیکون برنامه و بردارها (Vector & Adaptive Icon)
- **مجوز:** Creative Commons Zero (CC0) / طراحی اختصاصی برداری در محیط پروژه بدون وابستگی‌های دارای حق نشر شخص ثالث.
