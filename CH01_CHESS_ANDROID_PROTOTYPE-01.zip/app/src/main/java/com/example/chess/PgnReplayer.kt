package com.example.chess

data class PgnSequence(
    val id: String,
    val description: String,
    val moves: List<String>,
    val fens: List<String>
) {
    val totalSteps: Int get() = moves.size
}

class PgnReplayer(val sequence: PgnSequence) {
    var currentStep: Int = 0
        private set

    val currentFen: String
        get() = sequence.fens.getOrElse(currentStep) { sequence.fens.last() }

    val currentMoveSan: String?
        get() = if (currentStep > 0 && currentStep <= sequence.moves.size) {
            sequence.moves[currentStep - 1]
        } else null

    val isAtStart: Boolean get() = currentStep <= 0
    val isAtEnd: Boolean get() = currentStep >= sequence.totalSteps

    fun next(): Boolean {
        if (!isAtEnd) {
            currentStep++
            return true
        }
        return false
    }

    fun previous(): Boolean {
        if (!isAtStart) {
            currentStep--
            return true
        }
        return false
    }

    fun reset() {
        currentStep = 0
    }

    fun jumpToEnd() {
        currentStep = sequence.totalSteps
    }

    fun jumpTo(step: Int) {
        currentStep = step.coerceIn(0, sequence.totalSteps)
    }
}
