package com.example.chess

import com.example.model.ChessPiece
import com.example.model.PieceType

/**
 * Robust, pure Kotlin Chess Rules Engine.
 * Fully calculates real legal moves, king safety, pins, check, checkmate, and stalemate
 * without any hardcoded answers.
 */

data class Move(
    val fromFile: Int, // 0..7 (a..h)
    val fromRank: Int, // 0..7 (1..8)
    val toFile: Int,   // 0..7
    val toRank: Int,   // 0..7
    val promotion: PieceType? = null
) {
    val fromNotation: String get() = "${('a' + fromFile)}${fromRank + 1}"
    val toNotation: String get() = "${('a' + toFile)}${toRank + 1}"
    val uci: String get() = "$fromNotation$toNotation"
}

data class MoveResult(
    val move: Move,
    val san: String,
    val newPosition: ChessBoardState,
    val isCheck: Boolean,
    val isCheckmate: Boolean,
    val isStalemate: Boolean
)

data class ChessBoardState(
    val board: Array<Array<ChessPiece?>>, // [rank][file], rank 0 is 1st rank, rank 7 is 8th rank
    val activeColor: Char, // 'w' or 'b'
    val castling: String,
    val enPassant: String,
    val halfMove: Int,
    val fullMove: Int
) {
    fun getPiece(file: Int, rank: Int): ChessPiece? {
        if (rank in 0..7 && file in 0..7) {
            return board[rank][file]
        }
        return null
    }

    fun getPieceAt(notation: String): ChessPiece? {
        if (notation.length < 2) return null
        val file = notation[0] - 'a'
        val rank = notation[1] - '1'
        return getPiece(file, rank)
    }

    fun copyBoard(): Array<Array<ChessPiece?>> {
        return Array(8) { r -> Array(8) { f -> board[r][f] } }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as ChessBoardState
        for (r in 0..7) {
            for (f in 0..7) {
                if (board[r][f] != other.board[r][f]) return false
            }
        }
        return activeColor == other.activeColor &&
                castling == other.castling &&
                enPassant == other.enPassant
    }

    override fun hashCode(): Int {
        var result = board.contentDeepHashCode()
        result = 31 * result + activeColor.hashCode()
        result = 31 * result + castling.hashCode()
        return result
    }
}

class ChessEngine(initialFen: String = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1") {

    var state: ChessBoardState = parseFen(initialFen)
        private set

    fun setFen(fen: String) {
        state = parseFen(fen)
    }

    fun toFen(): String = stateToFen(state)

    // ==========================================
    // FEN Parsing & Serialization
    // ==========================================

    companion object {
        fun parseFen(fen: String): ChessBoardState {
            val parts = fen.trim().split("\\s+".toRegex())
            val ranks = parts[0].split("/")
            val board = Array(8) { Array<ChessPiece?>(8) { null } }

            for (rankIndex in 0 until 8) {
                val fenRank = ranks[rankIndex]
                val actualRank = 7 - rankIndex // Rank 8 is index 0 in FEN
                var file = 0
                for (char in fenRank) {
                    if (char.isDigit()) {
                        file += char.toString().toInt()
                    } else {
                        val isWhite = char.isUpperCase()
                        val type = when (char.lowercaseChar()) {
                            'p' -> PieceType.PAWN
                            'n' -> PieceType.KNIGHT
                            'b' -> PieceType.BISHOP
                            'r' -> PieceType.ROOK
                            'q' -> PieceType.QUEEN
                            'k' -> PieceType.KING
                            else -> PieceType.PAWN
                        }
                        if (file in 0..7 && actualRank in 0..7) {
                            board[actualRank][file] = ChessPiece(type, isWhite)
                        }
                        file++
                    }
                }
            }

            val activeColor = if (parts.size > 1) parts[1].firstOrNull() ?: 'w' else 'w'
            val castling = if (parts.size > 2) parts[2] else "-"
            val enPassant = if (parts.size > 3) parts[3] else "-"
            val halfMove = if (parts.size > 4) parts[4].toIntOrNull() ?: 0 else 0
            val fullMove = if (parts.size > 5) parts[5].toIntOrNull() ?: 1 else 1

            return ChessBoardState(board, activeColor, castling, enPassant, halfMove, fullMove)
        }

        fun stateToFen(pos: ChessBoardState): String {
            val sb = StringBuilder()
            for (rank in 7 downTo 0) {
                var emptyCount = 0
                for (file in 0..7) {
                    val piece = pos.board[rank][file]
                    if (piece == null) {
                        emptyCount++
                    } else {
                        if (emptyCount > 0) {
                            sb.append(emptyCount)
                            emptyCount = 0
                        }
                        val char = when (piece.type) {
                            PieceType.PAWN -> 'p'
                            PieceType.KNIGHT -> 'n'
                            PieceType.BISHOP -> 'b'
                            PieceType.ROOK -> 'r'
                            PieceType.QUEEN -> 'q'
                            PieceType.KING -> 'k'
                        }
                        sb.append(if (piece.isWhite) char.uppercaseChar() else char)
                    }
                }
                if (emptyCount > 0) {
                    sb.append(emptyCount)
                }
                if (rank > 0) {
                    sb.append('/')
                }
            }

            sb.append(" ").append(pos.activeColor)
            sb.append(" ").append(pos.castling)
            sb.append(" ").append(pos.enPassant)
            sb.append(" ").append(pos.halfMove)
            sb.append(" ").append(pos.fullMove)

            return sb.toString()
        }
    }

    // ==========================================
    // Attack & King Safety Detection
    // ==========================================

    fun isSquareAttacked(targetFile: Int, targetRank: Int, byColor: Char, board: Array<Array<ChessPiece?>>): Boolean {
        val isAttackerWhite = byColor == 'w'

        // 1. Pawn attacks
        val pawnPusherRank = if (isAttackerWhite) targetRank - 1 else targetRank + 1
        if (pawnPusherRank in 0..7) {
            for (df in listOf(-1, 1)) {
                val pf = targetFile + df
                if (pf in 0..7) {
                    val p = board[pawnPusherRank][pf]
                    if (p != null && p.isWhite == isAttackerWhite && p.type == PieceType.PAWN) {
                        return true
                    }
                }
            }
        }

        // 2. Knight attacks
        val knightOffsets = listOf(
            Pair(-2, -1), Pair(-2, 1), Pair(-1, -2), Pair(-1, 2),
            Pair(1, -2), Pair(1, 2), Pair(2, -1), Pair(2, 1)
        )
        for ((df, dr) in knightOffsets) {
            val f = targetFile + df
            val r = targetRank + dr
            if (f in 0..7 && r in 0..7) {
                val p = board[r][f]
                if (p != null && p.isWhite == isAttackerWhite && p.type == PieceType.KNIGHT) {
                    return true
                }
            }
        }

        // 3. Bishop & Queen diagonal attacks
        val diagonalDirections = listOf(Pair(-1, -1), Pair(-1, 1), Pair(1, -1), Pair(1, 1))
        for ((df, dr) in diagonalDirections) {
            var f = targetFile + df
            var r = targetRank + dr
            while (f in 0..7 && r in 0..7) {
                val p = board[r][f]
                if (p != null) {
                    if (p.isWhite == isAttackerWhite && (p.type == PieceType.BISHOP || p.type == PieceType.QUEEN)) {
                        return true
                    }
                    break // Ray is blocked
                }
                f += df
                r += dr
            }
        }

        // 4. Rook & Queen orthogonal attacks
        val orthogonalDirections = listOf(Pair(-1, 0), Pair(1, 0), Pair(0, -1), Pair(0, 1))
        for ((df, dr) in orthogonalDirections) {
            var f = targetFile + df
            var r = targetRank + dr
            while (f in 0..7 && r in 0..7) {
                val p = board[r][f]
                if (p != null) {
                    if (p.isWhite == isAttackerWhite && (p.type == PieceType.ROOK || p.type == PieceType.QUEEN)) {
                        return true
                    }
                    break // Ray is blocked
                }
                f += df
                r += dr
            }
        }

        // 5. King adjacent attacks
        for (df in -1..1) {
            for (dr in -1..1) {
                if (df == 0 && dr == 0) continue
                val f = targetFile + df
                val r = targetRank + dr
                if (f in 0..7 && r in 0..7) {
                    val p = board[r][f]
                    if (p != null && p.isWhite == isAttackerWhite && p.type == PieceType.KING) {
                        return true
                    }
                }
            }
        }

        return false
    }

    fun isColorInCheck(color: Char, board: Array<Array<ChessPiece?>>): Boolean {
        // Find king position
        val isWhite = color == 'w'
        val opponentColor = if (isWhite) 'b' else 'w'
        var kingFile = -1
        var kingRank = -1

        for (r in 0..7) {
            for (f in 0..7) {
                val p = board[r][f]
                if (p != null && p.isWhite == isWhite && p.type == PieceType.KING) {
                    kingFile = f
                    kingRank = r
                    break
                }
            }
            if (kingFile != -1) break
        }

        if (kingFile == -1) return false // No king on board
        return isSquareAttacked(kingFile, kingRank, opponentColor, board)
    }

    fun isInCheck(): Boolean = isColorInCheck(state.activeColor, state.board)

    // ==========================================
    // Legal Move Generation
    // ==========================================

    fun generateLegalMoves(forState: ChessBoardState = state): List<Move> {
        val pseudoMoves = generatePseudoLegalMoves(forState)
        val legalMoves = mutableListOf<Move>()
        val activeColor = forState.activeColor

        for (move in pseudoMoves) {
            val simulatedBoard = forState.copyBoard()
            val piece = simulatedBoard[move.fromRank][move.fromFile] ?: continue
            simulatedBoard[move.fromRank][move.fromFile] = null
            simulatedBoard[move.toRank][move.toFile] = if (move.promotion != null) {
                ChessPiece(move.promotion, piece.isWhite)
            } else {
                piece
            }

            // En passant pawn removal
            if (piece.type == PieceType.PAWN && move.fromFile != move.toFile && forState.board[move.toRank][move.toFile] == null) {
                val capturedPawnRank = if (piece.isWhite) move.toRank - 1 else move.toRank + 1
                simulatedBoard[capturedPawnRank][move.toFile] = null
            }

            // Verify King safety
            if (!isColorInCheck(activeColor, simulatedBoard)) {
                legalMoves.add(move)
            }
        }

        return legalMoves
    }

    fun generateLegalMovesForSquare(file: Int, rank: Int, forState: ChessBoardState = state): List<Move> {
        return generateLegalMoves(forState).filter { it.fromFile == file && it.fromRank == rank }
    }

    private fun generatePseudoLegalMoves(pos: ChessBoardState): List<Move> {
        val moves = mutableListOf<Move>()
        val isWhite = pos.activeColor == 'w'

        for (r in 0..7) {
            for (f in 0..7) {
                val piece = pos.board[r][f] ?: continue
                if (piece.isWhite != isWhite) continue

                when (piece.type) {
                    PieceType.PAWN -> generatePawnMoves(f, r, isWhite, pos, moves)
                    PieceType.KNIGHT -> generateKnightMoves(f, r, isWhite, pos, moves)
                    PieceType.BISHOP -> generateSlidingMoves(f, r, isWhite, pos, listOf(Pair(-1, -1), Pair(-1, 1), Pair(1, -1), Pair(1, 1)), moves)
                    PieceType.ROOK -> generateSlidingMoves(f, r, isWhite, pos, listOf(Pair(-1, 0), Pair(1, 0), Pair(0, -1), Pair(0, 1)), moves)
                    PieceType.QUEEN -> generateSlidingMoves(f, r, isWhite, pos, listOf(Pair(-1, -1), Pair(-1, 1), Pair(1, -1), Pair(1, 1), Pair(-1, 0), Pair(1, 0), Pair(0, -1), Pair(0, 1)), moves)
                    PieceType.KING -> generateKingMoves(f, r, isWhite, pos, moves)
                }
            }
        }
        return moves
    }

    private fun generatePawnMoves(file: Int, rank: Int, isWhite: Boolean, pos: ChessBoardState, moves: MutableList<Move>) {
        val forwardDir = if (isWhite) 1 else -1
        val startRank = if (isWhite) 1 else 6
        val promoRank = if (isWhite) 7 else 0

        // Single push
        val nextRank = rank + forwardDir
        if (nextRank in 0..7 && pos.board[nextRank][file] == null) {
            if (nextRank == promoRank) {
                listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT).forEach { promo ->
                    moves.add(Move(file, rank, file, nextRank, promo))
                }
            } else {
                moves.add(Move(file, rank, file, nextRank))
                // Double push from start rank
                val doubleRank = rank + 2 * forwardDir
                if (rank == startRank && pos.board[doubleRank][file] == null) {
                    moves.add(Move(file, rank, file, doubleRank))
                }
            }
        }

        // Captures
        for (df in listOf(-1, 1)) {
            val targetFile = file + df
            if (targetFile in 0..7 && nextRank in 0..7) {
                val targetPiece = pos.board[nextRank][targetFile]
                val enPassantNotation = pos.enPassant
                val isEnPassant = enPassantNotation != "-" &&
                        enPassantNotation.length == 2 &&
                        (enPassantNotation[0] - 'a' == targetFile) &&
                        (enPassantNotation[1] - '1' == nextRank)

                if ((targetPiece != null && targetPiece.isWhite != isWhite) || isEnPassant) {
                    if (nextRank == promoRank) {
                        listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT).forEach { promo ->
                            moves.add(Move(file, rank, targetFile, nextRank, promo))
                        }
                    } else {
                        moves.add(Move(file, rank, targetFile, nextRank))
                    }
                }
            }
        }
    }

    private fun generateKnightMoves(file: Int, rank: Int, isWhite: Boolean, pos: ChessBoardState, moves: MutableList<Move>) {
        val offsets = listOf(
            Pair(-2, -1), Pair(-2, 1), Pair(-1, -2), Pair(-1, 2),
            Pair(1, -2), Pair(1, 2), Pair(2, -1), Pair(2, 1)
        )
        for ((df, dr) in offsets) {
            val f = file + df
            val r = rank + dr
            if (f in 0..7 && r in 0..7) {
                val p = pos.board[r][f]
                if (p == null || p.isWhite != isWhite) {
                    moves.add(Move(file, rank, f, r))
                }
            }
        }
    }

    private fun generateSlidingMoves(
        file: Int,
        rank: Int,
        isWhite: Boolean,
        pos: ChessBoardState,
        directions: List<Pair<Int, Int>>,
        moves: MutableList<Move>
    ) {
        for ((df, dr) in directions) {
            var f = file + df
            var r = rank + dr
            while (f in 0..7 && r in 0..7) {
                val p = pos.board[r][f]
                if (p == null) {
                    moves.add(Move(file, rank, f, r))
                } else {
                    if (p.isWhite != isWhite) {
                        moves.add(Move(file, rank, f, r))
                    }
                    break // Blocked
                }
                f += df
                r += dr
            }
        }
    }

    private fun generateKingMoves(file: Int, rank: Int, isWhite: Boolean, pos: ChessBoardState, moves: MutableList<Move>) {
        for (df in -1..1) {
            for (dr in -1..1) {
                if (df == 0 && dr == 0) continue
                val f = file + df
                val r = rank + dr
                if (f in 0..7 && r in 0..7) {
                    val p = pos.board[r][f]
                    if (p == null || p.isWhite != isWhite) {
                        moves.add(Move(file, rank, f, r))
                    }
                }
            }
        }

        // Castling (simplified basic check)
        val opponentColor = if (isWhite) 'b' else 'w'
        val homeRank = if (isWhite) 0 else 7
        if (rank == homeRank && file == 4 && !isSquareAttacked(4, homeRank, opponentColor, pos.board)) {
            // Kingside
            val canCastleKing = if (isWhite) pos.castling.contains("K") else pos.castling.contains("k")
            if (canCastleKing && pos.board[homeRank][5] == null && pos.board[homeRank][6] == null) {
                if (!isSquareAttacked(5, homeRank, opponentColor, pos.board) && !isSquareAttacked(6, homeRank, opponentColor, pos.board)) {
                    moves.add(Move(file, rank, 6, homeRank))
                }
            }
            // Queenside
            val canCastleQueen = if (isWhite) pos.castling.contains("Q") else pos.castling.contains("q")
            if (canCastleQueen && pos.board[homeRank][3] == null && pos.board[homeRank][2] == null && pos.board[homeRank][1] == null) {
                if (!isSquareAttacked(3, homeRank, opponentColor, pos.board) && !isSquareAttacked(2, homeRank, opponentColor, pos.board)) {
                    moves.add(Move(file, rank, 2, homeRank))
                }
            }
        }
    }

    // ==========================================
    // Move Execution & Game Over Evaluation
    // ==========================================

    fun isCheckmate(): Boolean {
        val legalMoves = generateLegalMoves(state)
        return legalMoves.isEmpty() && isInCheck()
    }

    fun isStalemate(): Boolean {
        val legalMoves = generateLegalMoves(state)
        return legalMoves.isEmpty() && !isInCheck()
    }

    fun makeMove(move: Move): MoveResult? {
        val legalMoves = generateLegalMoves(state)
        val isLegal = legalMoves.any {
            it.fromFile == move.fromFile &&
                    it.fromRank == move.fromRank &&
                    it.toFile == move.toFile &&
                    it.toRank == move.toRank &&
                    (move.promotion == null || it.promotion == move.promotion)
        }
        if (!isLegal) return null

        val movingPiece = state.board[move.fromRank][move.fromFile] ?: return null
        val targetPiece = state.board[move.toRank][move.toFile]
        val isCapture = targetPiece != null

        val newBoard = state.copyBoard()
        newBoard[move.fromRank][move.fromFile] = null
        newBoard[move.toRank][move.toFile] = if (move.promotion != null) {
            ChessPiece(move.promotion, movingPiece.isWhite)
        } else {
            movingPiece
        }

        // Handle Castling Rook move
        if (movingPiece.type == PieceType.KING && kotlin.math.abs(move.toFile - move.fromFile) == 2) {
            if (move.toFile == 6) { // Kingside
                val rook = newBoard[move.fromRank][7]
                newBoard[move.fromRank][7] = null
                newBoard[move.fromRank][5] = rook
            } else if (move.toFile == 2) { // Queenside
                val rook = newBoard[move.fromRank][0]
                newBoard[move.fromRank][0] = null
                newBoard[move.fromRank][3] = rook
            }
        }

        val nextColor = if (state.activeColor == 'w') 'b' else 'w'
        val nextFullMove = if (state.activeColor == 'b') state.fullMove + 1 else state.fullMove
        val newState = ChessBoardState(
            board = newBoard,
            activeColor = nextColor,
            castling = updateCastlingRights(state.castling, move, movingPiece),
            enPassant = if (movingPiece.type == PieceType.PAWN && kotlin.math.abs(move.toRank - move.fromRank) == 2) {
                "${('a' + move.fromFile)}${(move.fromRank + move.toRank) / 2 + 1}"
            } else "-",
            halfMove = if (movingPiece.type == PieceType.PAWN || isCapture) 0 else state.halfMove + 1,
            fullMove = nextFullMove
        )

        // Evaluate resulting position
        val nextInCheck = isColorInCheck(nextColor, newBoard)
        val opponentLegalMoves = generateLegalMoves(newState)
        val isMate = nextInCheck && opponentLegalMoves.isEmpty()
        val isStale = !nextInCheck && opponentLegalMoves.isEmpty()

        val san = buildSan(movingPiece, move, isCapture, isMate, nextInCheck)

        state = newState
        return MoveResult(
            move = move,
            san = san,
            newPosition = newState,
            isCheck = nextInCheck,
            isCheckmate = isMate,
            isStalemate = isStale
        )
    }

    private fun updateCastlingRights(current: String, move: Move, piece: ChessPiece): String {
        var c = current
        if (piece.type == PieceType.KING) {
            c = if (piece.isWhite) c.replace("K", "").replace("Q", "") else c.replace("k", "").replace("q", "")
        }
        if (move.fromFile == 0 && move.fromRank == 0) c = c.replace("Q", "")
        if (move.fromFile == 7 && move.fromRank == 0) c = c.replace("K", "")
        if (move.fromFile == 0 && move.fromRank == 7) c = c.replace("q", "")
        if (move.fromFile == 7 && move.fromRank == 7) c = c.replace("k", "")
        return if (c.isEmpty()) "-" else c
    }

    private fun buildSan(
        piece: ChessPiece,
        move: Move,
        isCapture: Boolean,
        isCheckmate: Boolean,
        isCheck: Boolean
    ): String {
        val sb = StringBuilder()
        when (piece.type) {
            PieceType.PAWN -> {
                if (isCapture) {
                    sb.append(('a' + move.fromFile)).append('x')
                }
                sb.append(move.toNotation)
                if (move.promotion != null) {
                    sb.append("=").append(
                        when (move.promotion) {
                            PieceType.QUEEN -> "Q"
                            PieceType.ROOK -> "R"
                            PieceType.BISHOP -> "B"
                            PieceType.KNIGHT -> "N"
                            else -> "Q"
                        }
                    )
                }
            }
            PieceType.KING -> {
                if (kotlin.math.abs(move.toFile - move.fromFile) == 2) {
                    if (move.toFile == 6) sb.append("O-O") else sb.append("O-O-O")
                } else {
                    sb.append("K").append(if (isCapture) "x" else "").append(move.toNotation)
                }
            }
            else -> {
                val pChar = when (piece.type) {
                    PieceType.KNIGHT -> "N"
                    PieceType.BISHOP -> "B"
                    PieceType.ROOK -> "R"
                    PieceType.QUEEN -> "Q"
                    else -> ""
                }
                sb.append(pChar).append(if (isCapture) "x" else "").append(move.toNotation)
            }
        }

        if (isCheckmate) {
            sb.append("#")
        } else if (isCheck) {
            sb.append("+")
        }
        return sb.toString()
    }
}
