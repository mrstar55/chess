package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.Bd032UiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Bd032ExerciseView(
    state: Bd032UiState,
    onSquareClick: (file: Int, rank: Int) -> Unit,
    onQuickMove: (targetSquare: String) -> Unit,
    onReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "تمرین تعاملی: مات در یک حرکت برای سیاه",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Text(
                text = "سیاه برتری مهره‌ای قاطع دارد. با لمس مهره‌های سیاه (مانند وزیر e5 یا رخ g1)، خانه‌های قانونی حرکت با نقطه سبز مشخص می‌شوند. روی خانه مقصد بزنید تا مات در یک حرکت را اجرا کنید:",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            // The Interactive ChessBoard with dynamic legal moves from engine
            ChessBoardView(
                fen = state.currentFen,
                selectedSquare = state.selectedSquare,
                possibleMoves = state.legalTargetSquares,
                onSquareClick = onSquareClick,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            // Candidate quick moves to test
            Text(
                text = "آزمودن سریع گزینه‌های حرکتی وزیر سیاه (e5):",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .align(Alignment.Start)
                    .padding(top = 4.dp, bottom = 4.dp)
            )

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    Pair("Qh8", "h8"),
                    Pair("Qh2", "h2"),
                    Pair("Qe8", "e8"),
                    Pair("Qf5", "f5"),
                    Pair("Qe1", "e1")
                ).forEach { (label, target) ->
                    val isPlayed = state.solutionPlayed?.startsWith(label) == true
                    OutlinedButton(
                        onClick = { onQuickMove(target) },
                        colors = if (isPlayed) {
                            ButtonDefaults.outlinedButtonColors(
                                containerColor = if (state.feedbackIsSuccess) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)
                            )
                        } else ButtonDefaults.outlinedButtonColors(),
                        modifier = Modifier.testTag("btn_move_$target")
                    ) {
                        Text(label, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Real-time Feedback result from ChessEngine
            if (state.feedbackMessage != null) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (state.feedbackIsSuccess) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                        .testTag("exercise_feedback")
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (state.feedbackIsSuccess) Icons.Default.Check else Icons.Default.Close,
                            contentDescription = null,
                            tint = if (state.feedbackIsSuccess) Color(0xFF2E7D32) else Color(0xFFC62828)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = state.feedbackMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (state.feedbackIsSuccess) Color(0xFF1B5E20) else Color(0xFFB71C1C),
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            // Reset Button
            Button(
                onClick = onReset,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                modifier = Modifier
                    .padding(top = 10.dp)
                    .testTag("exercise_reset_btn")
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "شروع مجدد تمرین")
                Spacer(modifier = Modifier.width(6.dp))
                Text("شروع مجدد وضعیت")
            }
        }
    }
}
