package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.chess.ChessEngine
import com.example.chess.Move
import com.example.chess.PgnReplayer
import com.example.data.ChapterRepository
import com.example.data.FontSizeScale
import com.example.data.UserPreferencesManager
import com.example.model.DiagramItem
import com.example.model.PieceType
import com.example.model.SectionItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class Bd032UiState(
    val currentFen: String = "8/8/1p6/1k2q1P1/7K/8/8/6r1 b - - 0 1",
    val selectedSquare: String? = null,
    val selectedFile: Int = -1,
    val selectedRank: Int = -1,
    val legalTargetSquares: List<String> = emptyList(),
    val isSolved: Boolean = false,
    val feedbackMessage: String? = null,
    val feedbackIsSuccess: Boolean = false,
    val solutionPlayed: String? = null
)

data class ChapterUiState(
    val sections: List<SectionItem> = emptyList(),
    val diagrams: List<DiagramItem> = emptyList(),
    val currentSectionIndex: Int = 0,
    val fontScale: FontSizeScale = FontSizeScale.NORMAL,
    val bookmarks: Set<String> = emptySet(),
    val pgnStates: Map<String, PgnReplayerState> = emptyMap(),
    val bd032State: Bd032UiState = Bd032UiState(),
    val currentTab: AppTab = AppTab.READER
)

enum class AppTab {
    READER,
    SECTIONS_LIST,
    AUDIT_REPORT
}

data class PgnReplayerState(
    val pgnRef: String,
    val currentStep: Int,
    val totalSteps: Int,
    val currentFen: String,
    val currentMoveSan: String?,
    val isAtStart: Boolean,
    val isAtEnd: Boolean
)

class ChapterViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ChapterRepository(application)
    private val prefs = UserPreferencesManager(application)

    private val replayers = mutableMapOf<String, PgnReplayer>()
    private val bd032InitialFen = "8/8/1p6/1k2q1P1/7K/8/8/6r1 b - - 0 1"
    private var bd032Engine = ChessEngine(bd032InitialFen)

    private val _uiState = MutableStateFlow(ChapterUiState())
    val uiState: StateFlow<ChapterUiState> = _uiState.asStateFlow()

    init {
        loadData()
    }

    private fun loadData() {
        val sections = repository.getSections()
        val diagrams = repository.getDiagrams()
        val savedSection = prefs.lastReadSectionIndex.coerceIn(0, sections.size - 1)
        val fontScale = prefs.fontScale
        val bookmarks = prefs.getBookmarks()

        val pgnStatesMap = mutableMapOf<String, PgnReplayerState>()
        diagrams.forEach { diagram ->
            diagram.pgnRef?.let { pgnRef ->
                val seq = repository.getPgnSequence(pgnRef)
                if (seq != null) {
                    val replayer = PgnReplayer(seq)
                    replayer.jumpToEnd()
                    replayers[pgnRef] = replayer
                    pgnStatesMap[pgnRef] = PgnReplayerState(
                        pgnRef = pgnRef,
                        currentStep = replayer.currentStep,
                        totalSteps = seq.totalSteps,
                        currentFen = replayer.currentFen,
                        currentMoveSan = replayer.currentMoveSan,
                        isAtStart = replayer.isAtStart,
                        isAtEnd = replayer.isAtEnd
                    )
                }
            }
        }

        bd032Engine = ChessEngine(bd032InitialFen)

        _uiState.update {
            it.copy(
                sections = sections,
                diagrams = diagrams,
                currentSectionIndex = savedSection,
                fontScale = fontScale,
                bookmarks = bookmarks,
                pgnStates = pgnStatesMap,
                bd032State = Bd032UiState(
                    currentFen = bd032InitialFen,
                    isSolved = prefs.isBd032Solved()
                )
            )
        }
    }

    fun selectSection(index: Int) {
        val target = index.coerceIn(0, _uiState.value.sections.size - 1)
        prefs.lastReadSectionIndex = target
        _uiState.update {
            it.copy(currentSectionIndex = target, currentTab = AppTab.READER)
        }
    }

    fun nextSection() {
        if (_uiState.value.currentSectionIndex < _uiState.value.sections.size - 1) {
            selectSection(_uiState.value.currentSectionIndex + 1)
        }
    }

    fun prevSection() {
        if (_uiState.value.currentSectionIndex > 0) {
            selectSection(_uiState.value.currentSectionIndex - 1)
        }
    }

    fun setTab(tab: AppTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun setFontScale(scale: FontSizeScale) {
        prefs.fontScale = scale
        _uiState.update { it.copy(fontScale = scale) }
    }

    fun toggleBookmark(diagramId: String) {
        prefs.toggleBookmark(diagramId)
        _uiState.update { it.copy(bookmarks = prefs.getBookmarks()) }
    }

    fun stepPgnNext(pgnRef: String) {
        val replayer = replayers[pgnRef] ?: return
        replayer.next()
        updatePgnState(pgnRef, replayer)
    }

    fun stepPgnPrev(pgnRef: String) {
        val replayer = replayers[pgnRef] ?: return
        replayer.previous()
        updatePgnState(pgnRef, replayer)
    }

    fun resetPgn(pgnRef: String) {
        val replayer = replayers[pgnRef] ?: return
        replayer.reset()
        updatePgnState(pgnRef, replayer)
    }

    fun jumpPgnToEnd(pgnRef: String) {
        val replayer = replayers[pgnRef] ?: return
        replayer.jumpToEnd()
        updatePgnState(pgnRef, replayer)
    }

    private fun updatePgnState(pgnRef: String, replayer: PgnReplayer) {
        _uiState.update { state ->
            val updatedMap = state.pgnStates.toMutableMap()
            updatedMap[pgnRef] = PgnReplayerState(
                pgnRef = pgnRef,
                currentStep = replayer.currentStep,
                totalSteps = replayer.sequence.totalSteps,
                currentFen = replayer.currentFen,
                currentMoveSan = replayer.currentMoveSan,
                isAtStart = replayer.isAtStart,
                isAtEnd = replayer.isAtEnd
            )
            state.copy(pgnStates = updatedMap)
        }
    }

    // ==========================================
    // Dynamic BD-032 Chess Engine Exercise Logic
    // ==========================================

    fun onBd032SquareClicked(file: Int, rank: Int) {
        val currentState = _uiState.value.bd032State
        val clickedNotation = "${('a' + file)}${rank + 1}"
        val pieceAtClicked = bd032Engine.state.getPiece(file, rank)

        // 1. If clicking a friendly black piece, generate its real legal moves via ChessEngine
        if (pieceAtClicked != null && !pieceAtClicked.isWhite && bd032Engine.state.activeColor == 'b') {
            val legalMoves = bd032Engine.generateLegalMovesForSquare(file, rank)
            val legalTargets = legalMoves.map { it.toNotation }
            _uiState.update {
                it.copy(
                    bd032State = currentState.copy(
                        selectedSquare = clickedNotation,
                        selectedFile = file,
                        selectedRank = rank,
                        legalTargetSquares = legalTargets,
                        feedbackMessage = "مهره ${pieceAtClicked.type.name} در $clickedNotation انتخاب شد. ${legalTargets.size} حرکت قانونی دارد. روی خانه هدف بزنید."
                    )
                )
            }
            return
        }

        // 2. If already selected a piece and clicked a target square
        if (currentState.selectedSquare != null && currentState.selectedFile != -1) {
            val fromFile = currentState.selectedFile
            val fromRank = currentState.selectedRank
            val move = Move(fromFile, fromRank, file, rank)
            executeBd032Move(move)
        }
    }

    fun onBd032ExecuteSanOrTarget(targetSquare: String) {
        // If queen on e5 is selected or default queen move
        val fromFile = 4 // 'e'
        val fromRank = 4 // '5'
        val toFile = targetSquare[0] - 'a'
        val toRank = targetSquare[1] - '1'
        val move = Move(fromFile, fromRank, toFile, toRank)
        executeBd032Move(move)
    }

    private fun executeBd032Move(move: Move) {
        val testEngine = ChessEngine(bd032InitialFen)
        val moveResult = testEngine.makeMove(move)

        if (moveResult == null) {
            _uiState.update {
                it.copy(
                    bd032State = it.bd032State.copy(
                        selectedSquare = null,
                        selectedFile = -1,
                        selectedRank = -1,
                        legalTargetSquares = emptyList(),
                        feedbackMessage = "این حرکت طبق قوانین شطرنج غیرقانونی است!",
                        feedbackIsSuccess = false
                    )
                )
            }
            return
        }

        // Move is completely legal! Check if it delivers checkmate dynamically
        bd032Engine = testEngine
        val isMate = moveResult.isCheckmate
        val san = moveResult.san

        if (isMate) {
            prefs.setBd032Solved(true)
            _uiState.update {
                it.copy(
                    bd032State = it.bd032State.copy(
                        currentFen = testEngine.toFen(),
                        selectedSquare = null,
                        selectedFile = -1,
                        selectedRank = -1,
                        legalTargetSquares = emptyList(),
                        isSolved = true,
                        feedbackMessage = "پاسخ صحیح! حرکت $san توسط موتور قوانین ارزیابی شد: شاه سفید در کیش است و هیچ حرکت قانونی ندارد (کیش‌مات). هر دو پاسخ Qh8# و Qh2# تأیید می‌شوند.",
                        feedbackIsSuccess = true,
                        solutionPlayed = san
                    )
                )
            }
        } else {
            _uiState.update {
                it.copy(
                    bd032State = it.bd032State.copy(
                        currentFen = testEngine.toFen(),
                        selectedSquare = null,
                        selectedFile = -1,
                        selectedRank = -1,
                        legalTargetSquares = emptyList(),
                        feedbackMessage = "حرکت قانونی $san اجرا شد، اما موقعیت مات در یک حرکت نیست (${if (moveResult.isCheck) "شاه در کیش است اما خانه فرار دارد" else "شاه در کیش نیست"}).",
                        feedbackIsSuccess = false,
                        solutionPlayed = san
                    )
                )
            }
        }
    }

    fun resetBd032() {
        bd032Engine = ChessEngine(bd032InitialFen)
        _uiState.update {
            it.copy(
                bd032State = Bd032UiState(
                    currentFen = bd032InitialFen,
                    selectedSquare = null,
                    selectedFile = -1,
                    selectedRank = -1,
                    legalTargetSquares = emptyList(),
                    isSolved = false,
                    feedbackMessage = "صفحه بازنشانی شد. نوبت سیاه است؛ با انتخاب مهره و حرکت به خانه مقصد، مات در ۱ حرکت را پیدا کنید.",
                    feedbackIsSuccess = false,
                    solutionPlayed = null
                )
            )
        }
    }
}
