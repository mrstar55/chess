package com.example

import com.example.chess.ChessEngine
import com.example.chess.Move
import com.example.chess.PgnReplayer
import com.example.chess.PgnSequence
import com.example.model.PieceType
import org.junit.Assert.*
import org.junit.Test

class ChessChapterOneTest {

    @Test
    fun testChessEngine_StandardStartPosition() {
        val startFen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
        val engine = ChessEngine(startFen)

        assertEquals('w', engine.state.activeColor)
        assertEquals("KQkq", engine.state.castling)
        assertFalse("White should not be in check in start position", engine.isInCheck())

        val legalMoves = engine.generateLegalMoves()
        // Standard chess initial position has exactly 20 legal moves (16 pawn moves + 4 knight moves)
        assertEquals(20, legalMoves.size)

        // Reserialization test
        val reserialized = engine.toFen()
        assertEquals(startFen, reserialized)
    }

    @Test
    fun testChessEngine_Bd026Checkmate() {
        // Black king e8, White queen e7, White king e6 -> Black to move, Checkmate
        val fen = "4k3/4Q3/4K3/8/8/8/8/8 b - - 0 1"
        val engine = ChessEngine(fen)

        assertEquals('b', engine.state.activeColor)
        assertTrue("Black king must be in check", engine.isInCheck())

        val legalMoves = engine.generateLegalMoves()
        assertTrue("Black must have 0 legal moves in checkmate", legalMoves.isEmpty())
        assertTrue("Engine must report checkmate", engine.isCheckmate())
        assertFalse("Checkmate is not stalemate", engine.isStalemate())
    }

    @Test
    fun testChessEngine_Bd027BlockedVerification() {
        // Diagram BD-027 has Black king at h8, White bishop at g7, White king at g6, White knight at h5
        // FEN: 7k/6B1/6K1/7N/8/8/8/8 b - - 0 1
        val fen = "7k/6B1/6K1/7N/8/8/8/8 b - - 0 1"
        val engine = ChessEngine(fen)

        assertEquals('b', engine.state.activeColor)
        assertTrue("Black king at h8 is in check by bishop on g7", engine.isInCheck())

        // Engine generates real legal moves
        val legalMoves = engine.generateLegalMoves()
        assertEquals("Black king must have exactly 1 legal move to escape", 1, legalMoves.size)

        val escapeMove = legalMoves.first()
        assertEquals("h8", escapeMove.fromNotation)
        assertEquals("g8", escapeMove.toNotation)

        // Verify position is NOT checkmate!
        assertFalse("BD-027 MUST NOT be reported as checkmate because 1... Kg8 is legal!", engine.isCheckmate())
        assertFalse("BD-027 is not stalemate", engine.isStalemate())
    }

    @Test
    fun testChessEngine_Bd032DynamicMateSolutions() {
        // BD-032 FEN: 8/8/1p6/1k2q1P1/7K/8/8/6r1 b - - 0 1 (Black to move)
        val startFen = "8/8/1p6/1k2q1P1/7K/8/8/6r1 b - - 0 1"
        val engine = ChessEngine(startFen)

        assertEquals('b', engine.state.activeColor)
        assertFalse("Black is not in check", engine.isInCheck())

        val allLegalMoves = engine.generateLegalMoves()
        assertEquals("Black has exactly 42 legal moves in BD-032", 42, allLegalMoves.size)

        // Find which moves deliver checkmate dynamically across ALL 42 moves
        val checkmateMoves = mutableListOf<String>()

        for (move in allLegalMoves) {
            val testEngine = ChessEngine(startFen)
            val result = testEngine.makeMove(move)
            assertNotNull(result)
            if (result!!.isCheckmate) {
                checkmateMoves.add(result.san)
            }
        }

        // Must find EXACTLY the two verified checkmate solutions: Qh8# and Qh2#
        assertEquals("There must be exactly 2 checkmate moves in one", 2, checkmateMoves.size)
        assertTrue("Qh8# must be detected as checkmate", checkmateMoves.contains("Qh8#"))
        assertTrue("Qh2# must be detected as checkmate", checkmateMoves.contains("Qh2#"))

        // Test non-mating moves
        val testEngineQe8 = ChessEngine(startFen)
        val qe8Move = allLegalMoves.first { it.fromNotation == "e5" && it.toNotation == "e8" }
        val qe8Result = testEngineQe8.makeMove(qe8Move)
        assertNotNull(qe8Result)
        assertFalse("Qe8 is not checkmate", qe8Result!!.isCheckmate)
    }

    @Test
    fun testPgnReplayer_NavigationAndBoundaries() {
        val seq = PgnSequence(
            id = "SCHOLARS_MATE_TEST",
            description = "Scholar's Mate",
            moves = listOf("e4", "e5", "Qh5", "Nc6", "Bc4", "Nf6", "Qxf7#"),
            fens = listOf(
                "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
                "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1",
                "rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq e6 0 2",
                "rnbqkbnr/pppp1ppp/8/4p3/4P3/7Q/PPPP1PPP/RNB1KBNR b KQkq - 1 2",
                "r1bqkbnr/pppp1ppp/2n5/4p3/4P3/7Q/PPPP1PPP/RNB1KBNR w KQkq - 2 3",
                "r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/7Q/PPPP1PPP/RNB1K1NR b KQkq - 3 3",
                "r1bqkb1r/pppp1ppp/2n2n2/4p3/2B1P3/7Q/PPPP1PPP/RNB1K1NR w KQkq - 4 4",
                "r1bqkb1r/pppp1Qpp/2n2n2/4p3/2B1P3/8/PPPP1PPP/RNB1K1NR b KQkq - 0 4"
            )
        )

        val replayer = PgnReplayer(seq)

        assertTrue("Must start at step 0", replayer.isAtStart)
        assertFalse("Cannot be at end at step 0", replayer.isAtEnd)
        assertEquals(0, replayer.currentStep)
        assertEquals(seq.fens[0], replayer.currentFen)
        assertNull("No SAN move at step 0", replayer.currentMoveSan)

        val prevResult = replayer.previous()
        assertFalse(prevResult)
        assertEquals(0, replayer.currentStep)

        val nextResult1 = replayer.next()
        assertTrue(nextResult1)
        assertEquals(1, replayer.currentStep)
        assertEquals("e4", replayer.currentMoveSan)
        assertEquals(seq.fens[1], replayer.currentFen)

        while (replayer.next()) {}

        assertTrue("Must be at end", replayer.isAtEnd)
        assertEquals(seq.totalSteps, replayer.currentStep)
        assertEquals("Qxf7#", replayer.currentMoveSan)
        assertEquals(seq.fens.last(), replayer.currentFen)

        val nextAtEnd = replayer.next()
        assertFalse(nextAtEnd)
        assertEquals(seq.totalSteps, replayer.currentStep)

        val prevFromEnd = replayer.previous()
        assertTrue(prevFromEnd)
        assertEquals(seq.totalSteps - 1, replayer.currentStep)

        replayer.reset()
        assertTrue("After reset must be at start", replayer.isAtStart)
        assertEquals(0, replayer.currentStep)
        assertEquals(seq.fens[0], replayer.currentFen)
    }

    @Test
    fun testChessboardCoordinates_NoMirroringInRTL() {
        val files = (0..7).map { ('a' + it).toString() }
        assertEquals(listOf("a", "b", "c", "d", "e", "f", "g", "h"), files)

        val ranksTopToBottom = (7 downTo 0).map { it + 1 }
        assertEquals(listOf(8, 7, 6, 5, 4, 3, 2, 1), ranksTopToBottom)
    }
}
