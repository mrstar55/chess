package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.ChapterRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("آموزش شطرنج", appName)
  }

  @Test
  fun `verify chapter repository loads 10 diagrams and 6 sections with fixed ids`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = ChapterRepository(context)
    val diagrams = repo.getDiagrams()
    val sections = repo.getSections()

    assertEquals(10, diagrams.size)
    assertEquals(6, sections.size)
    assertEquals("BD-025", diagrams.first().diagramId)
    assertEquals("BD-034", diagrams.last().diagramId)

    // Verify structured section IDs
    assertEquals("SEC_CH01_01_OPENING", sections[0].sectionId)
    assertEquals("SEC_CH01_02_CHECKMATE", sections[1].sectionId)
    assertEquals("SEC_CH01_03_RESIGNATION", sections[2].sectionId)
    assertEquals("SEC_CH01_04_TIMING_OUT", sections[3].sectionId)
    assertEquals("SEC_CH01_05_ABANDONMENT", sections[4].sectionId)
    assertEquals("SEC_CH01_06_SUMMARY", sections[5].sectionId)

    // Verify all translation slots are properly initialized awaiting translation
    sections.forEach { section ->
      assertTrue(section.translationSlot.isPending)
      assertEquals(section.sectionId, section.translationSlot.sectionId)
    }
  }
}
