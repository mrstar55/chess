package com.example

import android.app.Activity
import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View
import android.view.ViewGroup
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.SemanticsNode
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.test.performClick
import androidx.compose.ui.unit.LayoutDirection
import androidx.test.core.app.ApplicationProvider
import com.example.chess.ChessEngine
import com.example.data.ChapterRepository
import com.example.data.UserPreferencesManager
import com.example.ui.AppTab
import com.example.ui.ChapterViewModel
import com.example.ui.components.ChessBoardView
import com.example.ui.screens.DiagramCard
import com.example.ui.theme.MyApplicationTheme
import java.io.File
import java.io.FileOutputStream
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w411dp-h891dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("آموزش شطرنج", appName)
    }

    @Test
    fun `verify chapter repository loads 10 diagrams and 6 sections with fixed ids`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = ChapterRepository(context)
        val diagrams = repo.getDiagrams()
        val sections = repo.getSections()

        assertEquals(10, diagrams.size)
        assertEquals(6, sections.size)
        assertEquals("BD-025", diagrams.first().diagramId)
        assertEquals("BD-034", diagrams.last().diagramId)

        assertEquals("SEC_CH01_01_OPENING", sections[0].sectionId)
        assertEquals("SEC_CH01_02_CHECKMATE", sections[1].sectionId)
        assertEquals("SEC_CH01_03_RESIGNATION", sections[2].sectionId)
        assertEquals("SEC_CH01_04_TIMING_OUT", sections[3].sectionId)
        assertEquals("SEC_CH01_05_ABANDONMENT", sections[4].sectionId)
        assertEquals("SEC_CH01_06_SUMMARY", sections[5].sectionId)

        sections.forEach { section ->
            assertTrue(section.translationSlot.isPending)
            assertEquals(section.sectionId, section.translationSlot.sectionId)
        }
    }

    @Test
    fun `verify all PGN and exercise references in repository are valid with no dangling refs`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = ChapterRepository(context)
        val diagrams = repo.getDiagrams()

        val bd032 = diagrams.first { it.diagramId == "BD-032" }
        assertNull("BD-032 single pgnRef must be null", bd032.pgnRef)
        assertEquals(
            "BD-032 solutionPgnRefs must contain both verified mate solutions",
            listOf("BD032_MATE_QH8", "BD032_MATE_QH2"),
            bd032.solutionPgnRefs
        )

        // Verify all PGN references and precomputed sequences across all 10 diagrams
        assertTrue(
            "All diagram PGN references, solution references, and precomputed replay steps must be valid",
            repo.validateAllReferencesAndReplays()
        )
    }

    @Test
    fun `verify BD032 does not reveal solutions before solving and supports retry without reset`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val prefs = UserPreferencesManager(app)
        prefs.setBd032Solved(false)

        val viewModel = ChapterViewModel(app)
        val initialFen = "8/8/1p6/1k2q1P1/7K/8/8/6r1 b - - 0 1"

        // 1. Before solving, no solution or target coordinates are revealed
        val state0 = viewModel.uiState.value.bd032State
        assertFalse(state0.isSolved)
        assertNull(state0.solutionPlayed)
        assertNull(state0.feedbackMessage)
        assertEquals(initialFen, state0.currentFen)

        // 2. Select Queen at e5 (file 4, rank 4)
        viewModel.onBd032SquareClicked(4, 4)
        val stateSelected = viewModel.uiState.value.bd032State
        assertEquals("e5", stateSelected.selectedSquare)
        // Selection feedback must NOT leak 'h8' or 'h2'
        assertFalse(stateSelected.feedbackMessage?.contains("h8") == true)
        assertFalse(stateSelected.feedbackMessage?.contains("h2") == true)

        // 3. Play legal non-mating move: e5 -> e8 (file 4, rank 7)
        viewModel.onBd032SquareClicked(4, 7)
        val stateAfterWrong = viewModel.uiState.value.bd032State
        assertFalse("Qe8 is not checkmate, so exercise must remain unsolved", stateAfterWrong.isSolved)
        assertFalse(stateAfterWrong.feedbackIsSuccess)
        assertEquals("Board must automatically revert to initial FEN after non-mating move", initialFen, stateAfterWrong.currentFen)
        assertNull("Selection must be cleared", stateAfterWrong.selectedSquare)

        // 4. Retry immediately WITHOUT pressing Reset: select Queen at e5 (4, 4) -> move to h2 (7, 1)
        viewModel.onBd032SquareClicked(4, 4)
        assertEquals("e5", viewModel.uiState.value.bd032State.selectedSquare)
        viewModel.onBd032SquareClicked(7, 1) // Qh2#

        val stateSolved = viewModel.uiState.value.bd032State
        assertTrue("Qh2# must mark exercise as solved", stateSolved.isSolved)
        assertTrue(stateSolved.feedbackIsSuccess)
        assertEquals("Qh2#", stateSolved.solutionPlayed)
        assertEquals("8/8/1p6/1k4P1/7K/8/7q/6r1 w - - 1 2", stateSolved.currentFen)

        // 5. Once solved, further clicks on the board must be ignored until Reset
        val solvedFen = stateSolved.currentFen
        viewModel.onBd032SquareClicked(6, 0) // click rook at g1
        assertEquals(solvedFen, viewModel.uiState.value.bd032State.currentFen)
        assertNull(viewModel.uiState.value.bd032State.selectedSquare)
    }

    @Test
    fun `verify BD032 reset clears persisted solved status across app restart`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val prefs = UserPreferencesManager(app)
        val viewModel = ChapterViewModel(app)

        // Solve BD-032 with Qh8# (e5 -> h8)
        viewModel.onBd032SquareClicked(4, 4)
        viewModel.onBd032SquareClicked(7, 7)
        assertTrue(viewModel.uiState.value.bd032State.isSolved)
        assertTrue(prefs.isBd032Solved())

        // Call Reset
        viewModel.resetBd032()
        assertFalse("UI state must be unsolved after reset", viewModel.uiState.value.bd032State.isSolved)
        assertFalse("Persisted preference must be false after reset", prefs.isBd032Solved())

        // Simulate closing and reopening the app by creating a new ViewModel instance
        val restartedViewModel = ChapterViewModel(app)
        assertFalse(
            "After app restart following reset, exercise must still be unsolved",
            restartedViewModel.uiState.value.bd032State.isSolved
        )
    }

    @Test
    fun `verify ChessBoardView composable renders files a to h LTR and ranks 8 to 1 top to bottom inside RTL layout`() {
        composeTestRule.setContent {
            // Render ChessBoardView inside a Persian RTL parent container
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                ChessBoardView(fen = ChessEngine.STANDARD_START_FEN)
            }
        }
        composeTestRule.waitForIdle()

        // Verify files a1..h1 are positioned strictly left-to-right on screen (no RTL mirroring)
        val fileSquares = listOf("a1", "b1", "c1", "d1", "e1", "f1", "g1", "h1")
        val fileXPositions = fileSquares.map { sq ->
            composeTestRule.onNodeWithTag("square_$sq").fetchSemanticsNode().boundsInRoot.left
        }
        for (i in 0 until fileXPositions.size - 1) {
            assertTrue(
                "Square ${fileSquares[i]} (left=${fileXPositions[i]}) must be strictly to the left of ${fileSquares[i + 1]} (left=${fileXPositions[i + 1]}) even in RTL mode",
                fileXPositions[i] < fileXPositions[i + 1]
            )
        }

        // Verify ranks a8..a1 are positioned strictly top-to-bottom on screen
        val rankSquares = listOf("a8", "a7", "a6", "a5", "a4", "a3", "a2", "a1")
        val rankYPositions = rankSquares.map { sq ->
            composeTestRule.onNodeWithTag("square_$sq").fetchSemanticsNode().boundsInRoot.top
        }
        for (i in 0 until rankYPositions.size - 1) {
            assertTrue(
                "Square ${rankSquares[i]} (top=${rankYPositions[i]}) must be strictly above ${rankSquares[i + 1]} (top=${rankYPositions[i + 1]})",
                rankYPositions[i] < rankYPositions[i + 1]
            )
        }
    }

    private fun collectAllSemanticsStrings(node: SemanticsNode): List<String> {
        val result = mutableListOf<String>()
        if (SemanticsProperties.Text in node.config) {
            node.config[SemanticsProperties.Text].forEach { result.add(it.text) }
        }
        if (SemanticsProperties.ContentDescription in node.config) {
            node.config[SemanticsProperties.ContentDescription].forEach { result.add(it) }
        }
        node.children.forEach { child ->
            result.addAll(collectAllSemanticsStrings(child))
        }
        return result
    }

    @Test
    fun `verify BD032 Compose UI does not reveal Qh8 or Qh2 or target squares before solving and shows success after solving`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        UserPreferencesManager(app).setBd032Solved(false)
        val viewModel = ChapterViewModel(app)

        composeTestRule.setContent {
            val state by viewModel.uiState.collectAsState()
            val bd032Diagram = state.diagrams.first { it.diagramId == "BD-032" }
            MyApplicationTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    DiagramCard(
                        diagram = bd032Diagram,
                        state = state,
                        viewModel = viewModel,
                        fontMultiplier = 1.0f
                    )
                }
            }
        }
        composeTestRule.waitForIdle()

        // 1. Before solving: verify no text in the Compose UI contains Qh8#, Qh2#, Qh8, Qh2, h8, or h2
        val allStringsBefore = collectAllSemanticsStrings(
            composeTestRule.onRoot(useUnmergedTree = true).fetchSemanticsNode()
        )
        assertFalse(
            "UI must NOT contain 'Qh8#' before solving",
            allStringsBefore.any { it.contains("Qh8#", ignoreCase = true) || it.contains("Qh8", ignoreCase = true) }
        )
        assertFalse(
            "UI must NOT contain 'Qh2#' before solving",
            allStringsBefore.any { it.contains("Qh2#", ignoreCase = true) || it.contains("Qh2", ignoreCase = true) }
        )
        assertFalse(
            "UI must NOT introduce 'h8' or 'h2' as answer coordinates before solving",
            allStringsBefore.any { it.contains("h8", ignoreCase = true) || it.contains("h2", ignoreCase = true) }
        )

        composeTestRule.onNodeWithText("Qh8", substring = true).assertDoesNotExist()
        composeTestRule.onNodeWithText("Qh2", substring = true).assertDoesNotExist()
        composeTestRule.onNodeWithTag("exercise_feedback").assertDoesNotExist()

        // Also verify that BD-032 diagram and exercise state do not highlight h8 or h2 as answers
        val bd032Diagram = viewModel.uiState.value.diagrams.first { it.diagramId == "BD-032" }
        assertTrue("BD-032 highlightSquares must be empty so h8/h2 are not highlighted", bd032Diagram.highlightSquares.isEmpty())
        assertTrue("BD-032 legalTargetSquares must be empty before piece selection", viewModel.uiState.value.bd032State.legalTargetSquares.isEmpty())

        saveRootViewScreenshot("04_bd032_section4_before_solve.png")

        // 2. Solve BD-032 via real Compose UI clicks: select Black Queen at e5, then click destination h8
        composeTestRule.onNodeWithTag("square_e5").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("square_h8").performClick()
        composeTestRule.waitForIdle()

        // 3. Verify success feedback is displayed in the Compose UI
        composeTestRule.onNodeWithTag("exercise_feedback").assertIsDisplayed()
        composeTestRule.onNodeWithText("پاسخ صحیح! حرکت Qh8# توسط موتور قوانین بررسی شد و شاه سفید مات شد.", substring = false).assertIsDisplayed()

        saveRootViewScreenshot("05_bd032_section4_after_solve.png")

        // 4. Reset via UI button and verify second winning move (Qh2#) via real Compose UI clicks
        composeTestRule.onNodeWithTag("exercise_reset_btn").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("Qh8", substring = true).assertDoesNotExist()
        composeTestRule.onNodeWithText("Qh2", substring = true).assertDoesNotExist()

        composeTestRule.onNodeWithTag("square_e5").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("square_h2").performClick()
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("exercise_feedback").assertIsDisplayed()
        composeTestRule.onNodeWithText("پاسخ صحیح! حرکت Qh2# توسط موتور قوانین بررسی شد و شاه سفید مات شد.", substring = false).assertIsDisplayed()
    }

    private fun saveRootViewScreenshot(fileName: String) {
        composeTestRule.waitForIdle()
        val screenshotsDir = File("../screenshots").let {
            if (it.parentFile?.exists() == true) it else File("screenshots")
        }
        screenshotsDir.mkdirs()

        // Find the active window decorView via WindowInspector / ActivityThread or Robolectric
        val decorViews = android.view.inspector.WindowInspector.getGlobalWindowViews()
        val targetView: View = decorViews.lastOrNull() ?: return
        val width = if (targetView.width > 0) targetView.width else 1080
        val height = if (targetView.height > 0) targetView.height else 2340

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        targetView.draw(canvas)

        val outFile = File(screenshotsDir, fileName)
        FileOutputStream(outFile).use { fos ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
        }
    }

    @Test
    fun `capture real UI screenshots of main screens and BD032 exercise`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val viewModel = ChapterViewModel(app)
        viewModel.resetBd032()

        composeTestRule.setContent {
            MyApplicationTheme {
                ChessAppMain(viewModel = viewModel)
            }
        }
        composeTestRule.waitForIdle()

        // 1. Main Screen (Sections List / TOC)
        viewModel.setTab(AppTab.SECTIONS_LIST)
        composeTestRule.waitForIdle()
        // Verify English subtitles are hidden from SectionsListScreen UI
        val tocStrings = collectAllSemanticsStrings(
            composeTestRule.onRoot(useUnmergedTree = true).fetchSemanticsNode()
        )
        viewModel.uiState.value.sections.forEach { section ->
            assertFalse(
                "English subtitle '${section.titleEn}' must be hidden in SectionsListScreen UI",
                tocStrings.any { it.contains(section.titleEn, ignoreCase = true) }
            )
        }
        saveRootViewScreenshot("01_main_sections_list.png")

        // 2. Reader Screen (Section 1 - Opening & Standard Chessboard)
        viewModel.selectSection(0)
        composeTestRule.waitForIdle()
        val readerSec1Strings = collectAllSemanticsStrings(
            composeTestRule.onRoot(useUnmergedTree = true).fetchSemanticsNode()
        )
        assertFalse(
            "English section title must be hidden in ReaderScreen UI",
            readerSec1Strings.any { it.contains("Chapter opening", ignoreCase = true) }
        )
        assertFalse(
            "English book_context must be hidden in ReaderScreen UI",
            readerSec1Strings.any { it.contains("The chapter recalls the standard initial chess position", ignoreCase = true) }
        )
        assertTrue(
            "Persian pending notice must be displayed in ReaderScreen UI",
            readerSec1Strings.any { it.contains("محتوای این بخش در حال آماده‌سازی است.") }
        )
        saveRootViewScreenshot("02_reader_screen_section1.png")

        // 3. Chessboard & Section 2 (Checkmate & BD-027 Blocked Warning)
        viewModel.selectSection(1)
        composeTestRule.waitForIdle()
        val readerSec2Strings = collectAllSemanticsStrings(
            composeTestRule.onRoot(useUnmergedTree = true).fetchSemanticsNode()
        )
        assertFalse(
            "English book_context for BD-026 must be hidden in ReaderScreen UI",
            readerSec2Strings.any { it.contains("The simplest checkmate example", ignoreCase = true) }
        )
        saveRootViewScreenshot("03_chessboard_section2_checkmate.png")

        val screenshotsDir = File("../screenshots").let {
            if (it.exists()) it else File("screenshots")
        }
        assertTrue(File(screenshotsDir, "01_main_sections_list.png").exists())
        assertTrue(File(screenshotsDir, "02_reader_screen_section1.png").exists())
        assertTrue(File(screenshotsDir, "03_chessboard_section2_checkmate.png").exists())
    }
}
