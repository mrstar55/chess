# گزارش پیاده‌سازی، کنترل کیفیت نهایی و اصلاح مستندات — فصل اول (نسخه ۰۵)

- **عنوان رسمی کتاب:** *How to Win at Chess*
- **عنوان فصل اول:** *How to (Literally) Win at Chess*

این گزارش مستندات کامل نسخه `-05` نمونه اولیه فصل اول را ارائه می‌دهد. در این مرحله، بدون هیچ‌گونه تغییر در `ChessEngine`، `ChessRulesAdapter`، منطق تمرین `BD-032`، داده‌های `FEN` و `PGN`، معماری `MVVM` یا طراحی اصلی، موارد زیر انجام و راستی‌آزمایی شده‌اند:

---

## ۱. اصلاح عنوان کتاب و عنوان فصل اول در مستندات
در `README.md`، `CHAPTER1_DATA_AUDIT.md` و `IMPLEMENTATION_REPORT.md` تفکیک دقیق بین دو عنوان اعمال شد:
- **عنوان رسمی کتاب:** `How to Win at Chess`
- **عنوان فصل اول:** `How to (Literally) Win at Chess`

---

## ۲. حذف متن‌های انگلیسی موقت از رابط کاربری و نمایش پیام استاندارد آماده‌سازی محتوا
1. **پنهان‌سازی توضیحات انگلیسی `book_context` از کارت‌های دیاگرام (`ReaderScreen.kt` -> `DiagramCard`):**
   - فیلد `diagram.bookContext` در مدل داده `DiagramItem` برای ارجاع داخلی حفظ شده است، اما در رابط مطالعه نمایش داده نمی‌شود و به جای آن پیام فارسی **«محتوای این بخش در حال آماده‌سازی است.»** نمایش داده می‌شود.
   - همچنین متن توضیحی ساختگی مربوط به مقایسه دیاگرام `BD-033` حذف شد تا هیچ متن کتابی بدون ترجمه رسمی مدیر پروژه در برنامه وجود نداشته باشد.
2. **پنهان‌سازی عنوان‌های فرعی انگلیسی (`titleEn`) از رابط کاربری (`ReaderScreen.kt` و `SectionsListScreen.kt`):**
   - فیلد `section.titleEn` در مدل داده `SectionItem` برای ارجاع داخلی حفظ شده، اما از نوار ابزار بالای `ReaderScreen`، زیرعنوان بخش در `ReaderScreen` و کارت‌های فهرست بخش‌ها در `SectionsListScreen` حذف شده است.
3. **حفظ شناسه‌های `TranslationSlot` و یکسان‌سازی پیام قسمت‌های بدون ترجمه (`ChapterModels.kt` و `ChapterRepository.kt`):**
   - هر ۶ شناسه ثابت `TranslationSlot` (`SEC_CH01_01_OPENING` تا `SEC_CH01_06_SUMMARY`) بدون تغییر حفظ شده‌اند و در صورت خالی بودن `translatedParagraphs`، پیام فارسی **«محتوای این بخش در حال آماده‌سازی است.»** را نمایش می‌دهند.
4. **تأیید خودکار در تست‌های Compose UI (`ExampleRobolectricTest.kt`):**
   - در تست UI بررسی می‌شود که هیچ‌یک از عنوان‌های فرعی انگلیسی (`titleEn`) یا متن‌های `book_context` در درخت معنایی رابط کاربری وجود ندارند و پیام «محتوای این بخش در حال آماده‌سازی است.» نمایش داده می‌شود.

---

## ۳. خلاصه ویژگی‌های فنی تأییدشده از مراحل قبل (بدون تغییر در نسخه ۰۵)

### ۳.۱ اعتبارسنجی FEN (`ChessEngine.kt` -> `parseFen`)
- موقعیت‌هایی که در آن‌ها **شاه طرفی که نوبت حرکتش نیست (Inactive Side) در کیش قرار داشته باشد** (مانند `4k3/8/8/8/8/8/4R3/4K3 w - - 0 1`) با `IllegalArgumentException` رد می‌شوند، در حالی که کیش بودن شاه طرفی که نوبت حرکت دارد پذیرفته می‌شود.

### ۳.۲ تست واقعی عدم افشای جواب `BD-032` با Compose UI (`ExampleRobolectricTest.kt`)
- قبل از حل تمرین، هیچ متنی شامل `Qh8#`، `Qh2#`، `Qh8`، `Qh2`، `h8` یا `h2` در رابط کاربری وجود ندارد و خانه‌های مقصد هایلایت نمی‌شوند.
- پس از انتخاب وزیر سیاه در `e5` و لمس `h8` (یا `h2` پس از `Reset`)، پیام موفقیت در بنر `exercise_feedback` نمایش داده می‌شود.

### ۳.۳ ارزیابی `KChessLib` (`io.github.cvb941:kchesslib:1.0.5`)
- تفکیک دقیق اجرای تست مستقیم روی JVM (که به دلیل کامپایل شدن `kchesslib-jvm-1.0.5.jar` با بایت‌کد Java 21 / `major version: 65` روی JVM نسخه JDK 17 با `UnsupportedClassVersionError` متوقف می‌شود) از کامپایل Android با D8 (که در صورت اجرای Gradle روی JDK 21 به DEX تبدیل می‌شود) در `THIRD_PARTY_NOTICES.md` مستند شده است.
- موتور بومی پروژه (`ChessEngine`) بدون تغییر حفظ شده است.

---

## ۴. گزارش هماهنگ اجرای تست‌ها (۳۲ تست در XML و در `raw-test-execution-log.txt`)

تمامی **۳۲ تست خودکار** پروژه مجدداً با دستور `gradle :app:testDebugUnitTest --rerun-tasks --console=plain` اجرا شدند و فایل `test-reports/raw-test-execution-log.txt` به‌روزرسانی شد تا هم خروجی واقعی کنسول Gradle و هم خلاصه دقیق نتایج XML هر ۳۲ تست را نشان دهد:

| کلاس تست | فایل گزارش XML | تعداد `@Test` | زمان اجرا | وضعیت |
|---|---|---|---|---|
| `com.example.ChessChapterOneTest` | `TEST-com.example.ChessChapterOneTest.xml` | **23** | `0.830s` | **PASS (23/23)** |
| `com.example.ExampleRobolectricTest` | `TEST-com.example.ExampleRobolectricTest.xml` | **8** | `16.174s` | **PASS (8/8)** |
| `com.example.ExampleUnitTest` | `TEST-com.example.ExampleUnitTest.xml` | **1** | `0.001s` | **PASS (1/1)** |
| **مجموع کل** | — | **32** | `17.005s` | **PASS (32/32)** |

---

## ۵. شفاف‌سازی گزارش نصب و نحوه تولید اسکرین‌شات‌ها

1. **نحوه تولید اسکرین‌شات‌ها (`screenshots/`):**
   - تمامی ۵ اسکرین‌شات موجود در پوشه `screenshots/` (`01_main_sections_list.png` تا `05_bd032_section4_after_solve.png`) در حین اجرای تست‌های رابط کاربری با استفاده از **Robolectric** (`@GraphicsMode(GraphicsMode.Mode.NATIVE)`) تولید شده‌اند و پس از حذف متن‌های انگلیسی موقت، مجدداً بازتولید شده‌اند.
2. **وضعیت اجرای دستور `installDebug` در محیط کانتینر:**
   - دستور `installDebug` در محیط کانتینر ابری بیلد به علت **نبود دستگاه متصل (`com.android.builder.testing.api.DeviceException: No connected devices!`)** موفق نشده است.
3. **وضعیت نصب روی دستگاه فیزیکی و Streaming Emulator:**
   - هیچ‌گونه نصبی روی گوشی فیزیکی انجام نشده است.
   - نصب از طریق قابلیت **Streaming Emulator** یا سرویس مستقل **Google AI Studio** فقط در صورت مشاهده نتیجه واقعی توسط کاربر در محیط پیش‌نمایش تأیید می‌شود.
